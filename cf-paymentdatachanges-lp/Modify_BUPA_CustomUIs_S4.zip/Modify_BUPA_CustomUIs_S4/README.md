# Modify_BUPA_CustomUIs_S4
UI for Modify Business Partner Data in S/4 scenario

# How to create a new project branch (in WebIDE)
1. Clone this project (right-click on folder `workspace`, Git, Clone Repository)
2. Right click the newly created project, Git, create remote Branch
   - Source Branch: `origin / template`
   - Branch name: *your name*
3. Right click the project, Git, create local Branch
   - Source Branch: `origin /`*`your name`*
   - Branch name: *`your name`* (should be automatic)
4. Adapt README.md to reflect your project content (descriptive text)
5. Right click on project, New, Workflow Module
   - Module name: *`your name`*
   - Workflow Details: `dummy` <- not needed, will be removed
6. Delete the dummy workflow (right-click `workflows/dummy.workflow`, Delete, confirm)
7. Right click on your newly created folder, New -> Process Step, Process Template, or Process Variant.