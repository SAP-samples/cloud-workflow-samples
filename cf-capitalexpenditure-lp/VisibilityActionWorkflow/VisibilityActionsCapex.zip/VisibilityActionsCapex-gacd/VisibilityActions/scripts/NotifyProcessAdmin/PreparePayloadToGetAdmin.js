/************ Prepare Input Payload to Execute the Rule ****************/
var details = {
    "SubStatus": $.context.SubStatus
};

var rulePayload = {
    "RuleServiceId": "e8fd32caaaac41d0b239a2f4587c5ef6",
    "RuleServiceRevision": "2008",
    "Vocabulary": [
        {
            "ProcessSubStatus": details
        }
    ]
};

$.context.rulePayload = rulePayload;
