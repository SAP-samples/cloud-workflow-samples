
var workflowstartPayload={};
workflowstartPayload.definitionId=$.context.WorkflowDetails.definitionId;
var context = {};
 context.RequestId=$.context.RequestContext.RequestId;
 context.Title=$.context.RequestContext.Title;
 context.Requester=$.context.RequestContext.Requester;
 context.Investment=$.context.RequestContext.Investment;
 context.Sustainability=$.context.RequestContext.Sustainability;
 context.Attachments=$.context.RequestContext.Attachments;
 context.History = $.context.RequestContext.History;
 context.isTesting = true;
 context.isRestarted = true;
 context.prevWorkflowInstanceId = $.context.InstanceId;
workflowstartPayload.context = context;
$.context.StartPayload = workflowstartPayload;

var PatchPayload ={};
PatchPayload.status = "CANCELED";
$.context.InstanceId;
$.context.PatchPayload = PatchPayload;