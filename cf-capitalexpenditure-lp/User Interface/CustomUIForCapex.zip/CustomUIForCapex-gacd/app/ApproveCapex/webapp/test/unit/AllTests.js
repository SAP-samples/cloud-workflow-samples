sap.ui.define([
	"com/sap/bpm/ApproveCapex/test/unit/controller/App.controller"
], function () {
	"use strict";
});
