sap.ui.define([
	"com/sap/bpm/ReworkCapex/test/unit/controller/App.controller"
], function () {
	"use strict";
});
