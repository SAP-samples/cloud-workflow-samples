sap.ui.define([
	"com/sap/bpm/StartCapex/test/unit/controller/App.controller"
], function () {
	"use strict";
});
