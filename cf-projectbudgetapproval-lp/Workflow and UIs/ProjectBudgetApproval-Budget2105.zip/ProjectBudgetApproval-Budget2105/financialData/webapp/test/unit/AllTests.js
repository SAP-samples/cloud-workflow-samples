sap.ui.define([
	"com/budget/financialData/test/unit/controller/App.controller"
], function () {
	"use strict";
});
