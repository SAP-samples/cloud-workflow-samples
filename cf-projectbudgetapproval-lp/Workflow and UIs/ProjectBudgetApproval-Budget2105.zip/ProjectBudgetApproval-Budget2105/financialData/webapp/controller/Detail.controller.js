// @ts-nocheck
sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
  ],
  function (Controller, JSONModel, Fragment) {
    "use strict";

    return Controller.extend(
      "com.budget.financialData.controller.Detail",
      {
        onInit: function () {
          var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
          oRouter
            .getRoute("details")
            .attachPatternMatched(this._onDetailMatchedDetail, this);
        },
        _onDetailMatchedDetail: function (oEvent) {
          var data = sap.ui.getCore().getModel("csv").getData();
          var oModel = new JSONModel({});
          oModel.setData(data);
          this.getView().setModel(oModel, "csv");
        },
      }
    );
  }
);
