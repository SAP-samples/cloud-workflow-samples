
var ApproverComment ={};
ApproverComment.Approver = $.context.CurrentApproverGroup;
ApproverComment.Comment= $.context.ApproverComment;
if( $.context.ApproverComment == null)
  $.context.ApproverComment ="";
$.context.Comments.push(ApproverComment);
if($.context.approved == "Yes")
{
    ApproverComment.Decision ="Approved";
    $.context.ApproverComment="";
}
else 
{
     ApproverComment.Decision ="Rejected";
     $.context.currentStatus="Rejected";
}


