var result = $.context.RuleOutput.Result;
$.context.ApproverGroups= [];
var count = result[0].ApproverGroups.length;
var approverGroup={};
$.context.ApprovalRequired = false;
if (result.length > 0) {
    for(var i = 0 ; i < count ;i++)
    {    
        if(result[0].ApproverGroups[i].ApprovalRequired == true)
        {
            $.context.ApproverGroups.push(result[0].ApproverGroups[i].ApproverGroup);
            $.context.ApprovalRequired = true;
        }
    }
   
}
$.context.ApproverIndex = 0;
if($.context.ApproverGroups.length >0 )
  $.context.CurrentApproverGroup =$.context.ApproverGroups[$.context.ApproverIndex];
