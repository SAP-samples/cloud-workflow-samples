
var rulesPayload={};
var netAmount = 0;
var items = $.context.d;
var i = 0;
for (i = 0; i < items.length; i++) {
    netAmount += parseFloat(items[i].AmountInGlobalCurrency);
    items[i].ItemStatus = "Approve";
    items[i].ItemComments = "";
 }
var ruleInput ={
    TotalAmount: netAmount,
    GlobalCurrency: items[0].GlobalCurrency,
    ProjectID:$.context.metadata.project
}
$.context.metadata.TotalAmount = netAmount;
$.context.metadata.GlobalCurrency = items[0].GlobalCurrency;
$.context.RejectedCollection = [];
var rulesPayload = {
    "RuleServiceId": "6c8c049a8f60464989938cea25dc70d6",
    "RuleServiceRevision": "2105",
    "Vocabulary": [{ "BudgetRequest": ruleInput }]
};
$.context.Ruleinput = rulesPayload;

$.context.Comments = [];
$.context.currentStatus="In Approval";

