$.context.ApproverIndex += 1;
if($.context.ApproverGroups.length > $.context.ApproverIndex )
{
  $.context.CurrentApproverGroup =$.context.ApproverGroups[parseInt($.context.ApproverIndex)];
  $.context.ApprovalCompleted = false;
}
else
    $.context.ApprovalCompleted = true;