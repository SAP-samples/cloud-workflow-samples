
var ApproverComment ={};
ApproverComment.Approver = $.context.CurrentApproverGroup;
ApproverComment.Comment= $.context.ApproverComment;
if( $.context.ApproverComment == null)
  $.context.ApproverComment ="";
$.context.Comments.push(ApproverComment);
//calculate the net amount again

/*var i = 0;
var netAmount = 0;
var items = $.context.d;
for (i = 0; i < items.length; i++) {
    if( items.ItemStatus == "Approve")
    {
        netAmount += parseFloat(items[i].AmountInGlobalCurrency);
    }
    else if(items[i].ItemStatus == "Reject")
    {
        items[i].ItemStatus = "Rejected";
        var removed = items.splice(i, 1);
        array.push(removed[0]);
        $.context.RejectedCollection.push(removed[0]);
        i--;
        
    }
   
 }
 $.context.metadata.TotalAmount = netAmount;
 */
if($.context.approved == "Yes")
{
    ApproverComment.Decision ="Approved";
    $.context.ApproverComment="";
}
else 
{
     ApproverComment.Decision ="Rejected";
     $.context.currentStatus="Rejected";
}


