var payload = {};
payload["PlanDataAggrgnLvlFieldsString"] = "LedgerFiscalYear,GLAccount,PlanningCategory,GlobalCurrency,AmountInGlobalCurrency,FiscalPeriod,WBSElement,Project";
payload.to_FinPlanningEntryItemTP = {};
payload.to_FinPlanningEntryItemTP.results = $.context.d;
$.context.requestpayload = payload; 
$.context.currentStatus="Approved";
