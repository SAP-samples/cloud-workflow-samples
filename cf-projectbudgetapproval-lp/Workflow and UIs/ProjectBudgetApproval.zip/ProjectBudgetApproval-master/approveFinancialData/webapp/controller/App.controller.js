sap.ui.define([
        "sap/ui/core/mvc/Controller",
        "sap/m/MessageToast",
        "sap/ui/model/json/JSONModel",
         "sap/m/Dialog",
    	"sap/m/DialogType",
    "sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Label",
	"sap/m/TextArea"

	],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
	function (Controller, MessageToast, JSONModel, Dialog,DialogType, Button, ButtonType,
        Label, TextArea) {
		"use strict";
        var originalModel = new JSONModel();
		return Controller.extend("com.budget.approveFinancialData.controller.App", {
			onInit: function () {

               
            var originalModelData = this.byId("metadataTable").getModel().oData;
            var originalModelArrayData = JSON.parse(JSON.stringify(originalModelData)); 
            originalModel.setData(originalModelArrayData);

            // originalModel = this.byId("metadataTable").getModel();
            },
            formatAvailableToObjectState : function(bAvailable) {
            var status = "Error";
            if(bAvailable == "Approve")
            {
                status = "Success";
            }
           // console.log("status" + status);
			return status;
        },
        setRejectStatusForItems: function(reason) {
            var aIndices = this.byId("metadataTable").getSelectedItems();
            var sMsg = "";
            if (aIndices.length < 1) {
                sMsg = "no item selected";
                MessageToast.show(sMsg);
            }
            else
            {
                var i = 0;
                for (i = 0; i < aIndices.length; i++) {
                
                    aIndices[i]._getBindingContext().getObject().ItemStatus = "Reject"; 
                     aIndices[i]._getBindingContext().getObject().ItemComments = reason;

                }
             MessageToast.show("Reject Status Updated");
            }
            this.byId("metadataTable").getModel().refresh(true);
            this.byId("metadataTable").getModel().updateBindings(true);
            //this.getView().byId('metadataTable').rerender();
            this.byId("metadataTable").removeSelections(true);
            this.byId("metadataTable").rerender();
           // this.onSubmitDialogPress();
        },
        setApproveStatusForItems: function(reason) {
            var aIndices = this.byId("metadataTable").getSelectedItems();
             var sMsg = "";
            if (aIndices.length < 1) {
                sMsg = "no item selected";
                MessageToast.show(sMsg);
            }
            else
            {
                	var i = 0;
                    for (i = 0; i < aIndices.length; i++) {
                    
                        aIndices[i]._getBindingContext().getObject().ItemStatus = "Approve";
                         aIndices[i]._getBindingContext().getObject().ItemComments = reason;
                    }
                MessageToast.show("Approve Status Updated");
            }
            
            this.byId("metadataTable").getModel().refresh(true);
            this.byId("metadataTable").getModel().updateBindings(true);
            this.byId("metadataTable").removeSelections(true);

        },
		setApproveStatusForItem: function(evt) {
            evt.getSource().getBindingContext().getObject().ItemStatus = "Approve";
            this.byId("metadataTable").getModel().refresh(true);
            this.byId("metadataTable").getModel().updateBindings(true);
            this.byId("metadataTable").removeSelections(true);
        },
        setRejectStatusForItem: function(evt) {
            evt.getSource().getBindingContext().getObject().ItemStatus = "Reject";
            this.byId("metadataTable").getModel().refresh(true);
            this.byId("metadataTable").getModel().updateBindings(true);
            this.byId("metadataTable").removeSelections(true);
            this.byId("metadataTable").rerender();

        },
        onRejectItemsPress: function (evt) {
			if (!this.oSubmitDialog) {
				this.oSubmitDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: [
						new Label({
							text: "Do you want to reject these items?",
							labelFor: "rejectNote"
						}),
						new TextArea("rejectNote", {
							width: "100%",
							placeholder: "Add comment (required)",
							liveChange: function (oEvent) {
								var sText = oEvent.getParameter("value");
								this.oSubmitDialog.getBeginButton().setEnabled(sText.length > 0);
							}.bind(this)
						})
					],
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "OK",
						enabled: false,
						press: function () {
                            var sText = sap.ui.getCore().byId("rejectNote").getValue();
                            this.setRejectStatusForItems(sText);
							//MessageToast.show("Note is: " + sText);
							this.oSubmitDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oSubmitDialog.close();
						}.bind(this)
					})
				});
            }
           

			this.oSubmitDialog.open();
        },
        onApproveItemsPress: function (evt) {
			if (!this.oApproveDialog) {
				this.oApproveDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: [
						new Label({
							text: "Do you want to approve these items?",
							labelFor: "approveNote"
						}),
						new TextArea("approveNote", {
							width: "100%",
							placeholder: "Add comment (required)",
							liveChange: function (oEvent) {
								var sText = oEvent.getParameter("value");
								this.oApproveDialog.getBeginButton().setEnabled(sText.length > 0);
							}.bind(this)
						})
					],
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "OK",
						enabled: false,
						press: function () {
                            var sText = sap.ui.getCore().byId("approveNote").getValue();
                            this.setApproveStatusForItems(sText);
							//MessageToast.show("Note is: " + sText);
							this.oApproveDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oApproveDialog.close();
						}.bind(this)
					})
				});
            }
           

			this.oApproveDialog.open();
        },
        resetItems: function()
        {
            this.byId("metadataTable").setModel(this.getOriginalModel());
            this.byId("metadataTable").getModel().refresh(true);
            this.byId("metadataTable").getModel().updateBindings(true);
            this.byId("metadataTable").removeSelections(true);
        },
        resetItem:function(evt)
        {
            var oTable = this.byId("metadataTable"); 
            var item = evt.getSource().getBindingContext().getPath();
            var index = item.split('/')[2];
            var originalItem = originalModel.oData.d[index];
            evt.getSource().getBindingContext().getObject().itemStatus = originalItem.ItemStatus;
            evt.getSource().getBindingContext().getObject().itemComments = originalItem.ItemComments;
            evt.getSource().getBindingContext().getObject().AmountInGlobalCurrency = originalItem.AmountInGlobalCurrency;
            this.byId("metadataTable").getModel().refresh(true);
            this.byId("metadataTable").getModel().updateBindings(true);
            this.byId("metadataTable").removeSelections(true);
        },
         getOriginalModel:function()
        {
            var newModel = new JSONModel();
            var originalModelData = originalModel.oData;
            var originalModelArrayData = JSON.parse(JSON.stringify(originalModelData)); 
            newModel.setData(originalModelArrayData);
            return newModel;
        }
		});
	});
