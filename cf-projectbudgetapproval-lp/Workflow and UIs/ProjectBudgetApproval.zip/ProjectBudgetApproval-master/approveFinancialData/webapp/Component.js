// @ts-nocheck
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/budget/approveFinancialData/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("com.budget.approveFinancialData.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
            this.setModel(models.createDeviceModel(), "device");
            
            //Get Task Properties
            var startupParameters = this.getComponentData().startupParameters;
            this.setModel(startupParameters.taskModel, "task");
            var taskModel = startupParameters.taskModel;
            var taskData = taskModel.getData();
            var taskId = taskData.InstanceID;

            //Read Task Data
            var that = this;
            var contextModel = new sap.ui.model.json.JSONModel(this._getTaskInstancesBaseURL()+"/context");
            var contextData = contextModel.getData();

            contextModel.attachRequestCompleted(function () {
                contextData = contextModel.getData();
                console.log("------------")
                console.log(contextData);
                var processContext = {};
                processContext.context = contextData;
                processContext.context.task = {};
                processContext.context.task.Title = taskData.TaskTitle;
                processContext.context.task.Priority = taskData.Priority;
                processContext.context.task.Status = taskData.Status;

                if (taskData.Priority === "HIGH") {
                    processContext.context.task.PriorityState = "Warning";
                } else if (taskData.Priority === "VERY HIGH") {
                    processContext.context.task.PriorityState = "Error";
                } else {
                    processContext.context.task.PriorityState = "Success";
                }

                processContext.context.task.CreatedOn = taskData.CreatedOn.toDateString();

                // get task description and add it to the model
                startupParameters.inboxAPI.getDescription("NA", taskData.InstanceID).done(function (dataDescr) {
                    processContext.context.task.Description = dataDescr.Description;
                    contextModel.setProperty("/task/Description", dataDescr.Description);
                }).
                    fail(function (errorText) { });

                contextModel.setData(processContext.context);
                that.setModel(contextModel);

            });

           /* var oNegativeAction = {
                sBtnTxt: "Reject",
                onBtnPressed: function (e) {
                    var viewModel = that.getModel();
                    var contxt = viewModel.getData();
                    that._rejectTask(that.oComponentData.inboxHandle.attachmentHandle.detailModel.getData().InstanceID, "No")
                }
            };

            var oPositiveAction = {
                sBtnTxt: "Approve",
                onBtnPressed: function (e) {
                    var viewModel = that.getModel();
                    var contxt = viewModel.getData();
                    that._completeTask(that.oComponentData.inboxHandle.attachmentHandle.detailModel.getData().InstanceID, "Yes")
                }
            };*/
            var oSendAction = {
                sBtnTxt: "Send",
                onBtnPressed: function (e) {
                    var viewModel = that.getModel();
                    var contxt = viewModel.getData();
                    that._completeTask(that.oComponentData.inboxHandle.attachmentHandle.detailModel.getData().InstanceID, "Yes")
                }
            };
            /*startupParameters.inboxAPI.addAction({
                action: oNegativeAction.sBtnTxt,
                label: oNegativeAction.sBtnTxt,
                type: "Reject"
            }, oNegativeAction.onBtnPressed);

            startupParameters.inboxAPI.addAction({
                action: oPositiveAction.sBtnTxt,
                label: oPositiveAction.sBtnTxt,
                type: "Accept"
            }, oPositiveAction.onBtnPressed); */

             startupParameters.inboxAPI.addAction({
                action: oSendAction.sBtnTxt,
                label: oSendAction.sBtnTxt
            }, oSendAction.onBtnPressed);
        },
        _rejectTask: function (taskId, approvalStatus) {
            var comment = this.getModel().getData().ApproverComment;
            var token = this._fetchToken();
            var that = this;
            $.ajax({
                url: this._getTaskInstancesBaseURL(),
                method: "PATCH",
                contentType: "application/json",
                async: false,
                data: "{\"status\": \"COMPLETED\", \"context\": {\"approved\":\"" + approvalStatus + "\"},\"ApproverComment\":\"" + comment + "\"}}",
                headers: {
                    "X-CSRF-Token": token
                }
            });
            that._refreshTask();
        },
        _completeTask: function (taskId, approvalStatus) {
            var that = this;
            that.removeRejectedItems();
            var comment = this.getModel().getData().ApproverComment;
            var token = this._fetchToken();
             $.ajax({
                    url: this._getTaskInstancesBaseURL(),
                    method: "PATCH",
                    contentType: "application/json",
                    async: false,
                    data: "{\"status\": \"COMPLETED\", \"context\": {\"approved\":\"" + approvalStatus + "\",\"ApproverComment\":\"" + comment + "\"}}",
                    headers: {
                        "X-CSRF-Token": token
                    },
                    success: function (result, xhr, data) {
                        that._refreshTask();
                    }
                });

     
        }, 
        removeRejectedItems:function()
        {
           
            var oModel = this.getModel();
            var modelData = oModel.oData.d;
           
            var array = [];
            var emptyCommentsRejectedItems = [];
            var rejectedArray = [];

            var i = 0;
            for (i = 0; i < modelData.length; i++) 
            {
                if(modelData[i].ItemStatus == "Reject")
                {
                    if(modelData[i].ItemComment == "")
                    {
                        emptyCommentsRejectedItems.push(i);
                    }
                    rejectedArray.push(i);
                }
            }
            if(rejectedArray.length == modelData.length)
            {
                MessageToast.show("All items will be rejected and Status will be Completed ");
            
            }
            else if(emptyCommentsRejectedItems.length > 0)
            {
                 MessageToast.show("Comments are not maintained for the rejected items at indices " + emptyCommentsRejectedItems + "\nPlease try again");
                 return;
            }

        var i = 0;
        var netAmount = 0;
        //var items = $.context.d;
        for (i = 0; i < modelData.length; i++) {
                if(modelData[i].ItemStatus == "Approve")
                {
                    netAmount += parseFloat(modelData[i].AmountInGlobalCurrency);
                }
                else if(modelData[i].ItemStatus == "Reject")
                {
                    modelData[i].ItemStatus = "Rejected";
                    var removed = modelData.splice(i, 1);
                    array.push(removed[0]);
                    oModel.oData.RejectedCollection.push(removed[0]);
                    i--;
                    
                }
   
            }
            oModel.oData.metadata.TotalAmount = netAmount;
            this.getModel().refresh(true);
        },
     
        _fetchToken: function () {
            var token;
            $.ajax({
                url: this._getWorkflowRuntimeBaseURL()+"/xsrf-token",
                method: "GET",
                async: false,
                headers: {
                    "X-CSRF-Token": "Fetch",
                },
                success: function (result, xhr, data) {
                    token = data.getResponseHeader("X-CSRF-Token");
                }
            });
            return token;
        },

        _refreshTask: function () {
            this.getComponentData().startupParameters.inboxAPI.updateTask("NA", this.getTaskInstanceID());
            this.setBusy(false);
        },
        _getTaskInstancesBaseURL: function () {
         
              return this._getWorkflowRuntimeBaseURL() + "/task-instances/" + this.getTaskInstanceID();
        },
        
        _getWorkflowRuntimeBaseURL: function () {
            var componentName = this.getManifestEntry("/sap.app/id").replaceAll(".", "/");
             var componentPath= jQuery.sap.getModulePath(componentName);
                return componentPath + "/workflowruntime/v1";
        },
        
        getTaskInstanceID: function() {
            return this.getModel("task").getData().InstanceID;
        }


        
	});
});
