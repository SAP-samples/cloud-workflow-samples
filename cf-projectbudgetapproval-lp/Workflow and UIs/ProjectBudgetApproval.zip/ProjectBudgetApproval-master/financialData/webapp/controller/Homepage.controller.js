// @ts-nocheck
sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Fragment",
        "sap/m/MessageToast",
    ],
    // @ts-ignore
    function (Controller, JSONModel, Fragment, MessageToast) {
        "use strict";

        return Controller.extend(
            "com.budget.financialData.controller.Homepage",
            {
                onInit: function () { },
                // @ts-ignore
                onDownloadRequest: function (oEvent) {
                    var saveData = (function () {
                        var a = document.createElement("a");
                        document.body.appendChild(a);
                        // @ts-ignore
                        a.style = "display: none";
                        return function (fileName) {
                            var csvChar =
                                "CATEGORY,RYEAR,POPER,RBUKRS,PS_PSPID,PS_POSID,RACCT,KSL,RKCUR \
                \nPlan Category,General Ledger Fiscal Year,Posting Period,Company Code,Project Definition,Work Breakdown Structure Element (WBS Element),Account Number,Amount in Global Currency,Global Currency \
                \nX,X,X,X,X,,,,";
                            var blob = new Blob([csvChar], { type: "text/plain" });
                            var url = window.URL.createObjectURL(blob);
                            a.href = url;
                            a.download = fileName;
                            a.click();
                            window.URL.revokeObjectURL(url);
                        };
                    })();

                    saveData("test.csv");
                },
                onDownloadTemplatePress: function (oEvent) {
                    var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
                    var appPath = appId.replaceAll(".", "/");
                    var appModulePath = jQuery.sap.getModulePath(appPath);
                    var oA = document.createElement("a");
                    oA.href = appModulePath+"/data/TemplateForProjectBudgeting.csv";
                  //  oA.href = "/combudgetreworkfinancialData/data/TemplateForProjectPlanning.csv";
                    oA.style.display = "none";
                    document.body.appendChild(oA);
                    oA.click(function (event) {
                        event.preventDefault();
                    });
                    document.body.removeChild(oA);
                },
                onUpload: function (oEvent) {
                    this.getView().setBusy(true);
                    if (oEvent.getParameter("newValue") != "") {
                        var uploader = this.getView().byId("fileUploader");
                        var domref = uploader.getFocusDomRef();
                        var file = domref.files[0];
                        var reader = new FileReader();
                        reader.onload = function (oEvent) {
                            var strCSV = oEvent.target.result;
                            var { isValid, metadata, dataFinal } = this.refineCSV(
                                strCSV.split("\n")
                            );
                            if (isValid && dataFinal.length > 0) {
                                var oModel = new JSONModel({});
                                oModel.setData(metadata);
                                this.getView().setModel(oModel, "metadata");

                                oModel = new JSONModel({});
                                oModel.setData(dataFinal);
                                sap.ui.getCore().setModel(oModel, "csv");

                                this.getView().byId("link").setText("Preview List");
                                this.getView().byId("main").setVisible(true);
                                this.getView().setBusy(false);
                                this.getView().byId("import").setEnabled(true);
                            } else {
                                this.getView().byId("main").setVisible(false);
                                this.getView().byId("import").setEnabled(false);
                                this.getView().setBusy(false);
                                MessageToast.show("Invalid or empty CSV");
                            }
                        }.bind(this);
                        reader.readAsText(file);
                    }
                },
                refineCSV: function (data) {
                    // @ts-ignore
                    var planCategory = new Set();
                    // @ts-ignore
                    var fiscalYear = new Set();
                    // @ts-ignore
                    var project = new Set();
                    var dataFinal = [];
                    var isValid = true;
                    var metadata = [];
                    data.shift();
                    data.shift();
                    data.shift();

                    data.forEach((element) => {
                        if (element != "") {
                            var columns = element.split(",");
                            planCategory.add(columns[0]);
                            fiscalYear.add(columns[1]);
                            project.add(columns[3]);

                            try {
                                var jsonModel = {
                                    PlanningCategory: columns[0].trim(),
                                    LedgerFiscalYear: columns[1].trim(),
                                    FiscalPeriod: columns[2].trim(),
                                    Project: columns[3].trim(),
                                    WBSElement: columns[4].trim(),
                                    GLAccount: columns[5].trim(),
                                    AmountInGlobalCurrency: columns[6].trim(),
                                    GlobalCurrency: columns[7].trim(),
                                };

                                dataFinal.push(jsonModel);
                            } catch (e) {
                                isValid = false;
                            }
                        }
                    });

                    isValid = planCategory.size > 1 ? false : isValid;
                    isValid = fiscalYear.size > 1 ? false : isValid;
                    isValid = project.size > 1 ? false : isValid;

                    metadata.push({
                        name: "Plan Category",
                        value: planCategory.values().next().value,
                    });
                    metadata.push({
                        name: "G/L Fiscal Year",
                        value: fiscalYear.values().next().value,
                    });
                    metadata.push({
                        name: "Project Definition",
                        value: project.values().next().value,
                    });
                    return {
                        isValid,
                        metadata,
                        dataFinal,
                    };
                },
                // @ts-ignore
                onNav: function (oEvent) {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("details");
                },
                onTriggerDownloadTemplate: function (oEvent) {

                },
                  
                _getWorkflowRuntimeBaseURL: function () {
                    var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
                    var appPath = appId.replaceAll(".", "/");
                    var appModulePath = jQuery.sap.getModulePath(appPath);

                    return appModulePath + "/workflowruntime/v1";
                },
                 _refreshTask: function (taskId) {
                    this.getOwnerComponent().startupParameters.inboxAPI.updateTask("NA", taskId);
                  },

                onTriggerWorkflow: function (oEvent) {
                    this.getView().getBusy(true);
                    var jsonData = sap.ui.getCore().getModel("csv").getData();
                    var metadata = this.getView().getModel("metadata").getData();
                    var temp = {};
                    temp.d = jsonData;
                    temp.metadata = {}
                    temp.metadata["category"] = metadata[0].value;
                    temp.metadata["year"] = metadata[1].value;
                    temp.metadata["project"] = metadata[2].value;
                    temp.requestorEmail= sap.ushell.Container.getService("UserInfo").getUser().getEmail();
                    jsonData = { definitionId: "comsapbpmproejectbudgetapproval", context: temp };
                    //Start Workflow
                    $.ajax({
                        url: this._getWorkflowRuntimeBaseURL()+"/xsrf-token",
                        method: "GET",
                        headers: {
                            "X-CSRF-TOKEN": "fetch",
                        },
                        success: function (result, xhr, data) {
                            var token = data.getResponseHeader("X-CSRF-TOKEN");
                            if (token === null) {
                                this.getView().getBusy(false);
                                MessageToast.show("Error Triggering Workflow!");
                                return;
                            }
                            
                            $.ajax({
                                url: this._getWorkflowRuntimeBaseURL()+"/workflow-instances",
                                method: "POST",
                                data: JSON.stringify(jsonData),
                                headers: {
                                    "X-CSRF-TOKEN": token,
                                    "Content-Type": "application/json"
                                },
                                async: false,
                                success: function (oSuccess) {
                                    
                                    MessageToast.show("Successfully sent for approval");
                                    this.getView().byId("import").setEnabled(false)

                                }.bind(this),
                                error: function (oError) {
                                    this.getView().getBusy(false);
                                    MessageToast.show("Error Triggering Workflow");
                                }.bind(this)
                            }, this);
                        }.bind(this),
                        error: function (oError) {
                            this.getView().getBusy(false);
                            MessageToast.show("Error Triggering Workflow");
                        }.bind(this)

                    }, this);
                }
            }
        );
    }
);
