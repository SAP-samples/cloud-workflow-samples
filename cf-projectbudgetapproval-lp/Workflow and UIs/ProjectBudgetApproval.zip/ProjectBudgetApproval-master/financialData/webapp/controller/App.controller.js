// @ts-nocheck
sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  return Controller.extend("com.budget.financialData.controller.App", {
    onInit: function () {
    //   var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
    //   oRouter
    //     .getRoute("homepage")
    //     .attachPatternMatched(this._onObjectMatchedHome, this);
    //   oRouter
    //     .getRoute("details")
    //     .attachPatternMatched(this._onDetailMatchedDetail, this);
    },
    
    _onObjectMatchedHome: function (oEvent) {
      this.getView().byId("buttonBack").setVisible(false);
      this.getView().byId("textTitle").setText("Import Financial Plan Data");
    },
    _onDetailMatchedDetail: function (oEvent) {
      this.getView().byId("buttonBack").setVisible(true);
      this.getView().byId("textTitle").setText("Import Financial Plan Data");
    },
    onBack: function (oEvent) {
      var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
      var hash = oRouter.oHashChanger.hash;
      hash = hash.includes("sheet") ? "sheet" : hash;
      switch (hash) {
        case "details":
          oRouter.navTo("homepage");
          break;
        default:
          oRouter.navTo("homepage");
          break;
      }
    },
  });
});
