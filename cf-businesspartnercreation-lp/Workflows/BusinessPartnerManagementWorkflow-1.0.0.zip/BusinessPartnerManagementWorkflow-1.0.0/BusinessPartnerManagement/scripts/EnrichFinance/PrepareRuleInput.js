
$.context.CurrentStepName = "EnrichFinance";

var RuleInput = {
    "RuleServiceId": "ada4a55493c04211b5ea134f0cfe6f83",
    "RuleServiceRevision": "2104",
    "Vocabulary": [
        {
            "BusinessPartnerRequestDetails": {
                "Country": $.context.BPRequest.AddressData.Country,
                "Category": $.context.BPRequest.BusinessPartnerCategory,
                "StepName": $.context.CurrentStepName
            }
        }
    ]
}

$.context.GetProcessorRuleInput = RuleInput;
