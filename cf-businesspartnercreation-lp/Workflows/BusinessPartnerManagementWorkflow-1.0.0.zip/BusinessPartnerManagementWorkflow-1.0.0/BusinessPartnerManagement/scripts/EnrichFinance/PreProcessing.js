
$.context.isFinanceStepNotRequired = $.context.internal.isRework && !($.context.internal.reworkRequestDetails.isCompleteRework)
    && !($.context.internal.reworkRequestDetails.isFinanceRework);