function allKeysToUpperCase(obj) {
    var output = {};
    for (var i in obj) {
        if (Object.prototype.toString.apply(obj[i]) === '[object Object]') {
            output[i.toUpperCase()] = allKeysToUpperCase(obj[i]);
        } else {
            output[i.toUpperCase()] = obj[i];
        }
    }
    return output;
}

$.context.internal.setDefValRuleInput = {
    RuleServiceId: "969003dedff3424daedbea6ff93f7427",
    RuleServiceRevision: "2104",
    Vocabulary: [
        {
            I_BUSINESSPARTNER_S: allKeysToUpperCase($.context.internal.BPCreationPayload)
        }
    ]
}

