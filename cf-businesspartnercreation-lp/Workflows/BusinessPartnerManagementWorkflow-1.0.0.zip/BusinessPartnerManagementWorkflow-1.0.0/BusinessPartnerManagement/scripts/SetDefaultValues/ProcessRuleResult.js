
var oJsonFromRule = $.context.internal.setDefValRuleOutput.Result[0].I_BUSINESSPARTNER_S;
var oBPCreationPayload = $.context.internal.BPCreationPayload;

for (var i in oJsonFromRule) {
    for (var j in oBPCreationPayload) {
        if (i === j.toUpperCase()) {
            // if SEARCHTERM1 length > 20 we have to trim it
            // if (i === "SEARCHTERM1") {
            //     oBPCreationPayload[j] = oJsonFromRule[i].substring(0, 20);
            // } else {
            oBPCreationPayload[j] = oJsonFromRule[i];
            // }
        }
    }
}

$.context.internal.BPCreationPayload = oBPCreationPayload;