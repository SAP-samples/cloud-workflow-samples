
$.context.CurrentProcessorUserId = $.context.RequesterDetails.RequesterUserId;
$.context.CurrentProcessorName = $.context.RequesterDetails.RequesterFirstName + " " + $.context.RequesterDetails.RequesterLastName;
$.context.CurrentProcessorEmail = $.context.RequesterDetails.RequesterEmail;

$.context.CurrentStepName = "ReworkBasicData";

$.context.internal.isRework = true;

$.context.comments = "";