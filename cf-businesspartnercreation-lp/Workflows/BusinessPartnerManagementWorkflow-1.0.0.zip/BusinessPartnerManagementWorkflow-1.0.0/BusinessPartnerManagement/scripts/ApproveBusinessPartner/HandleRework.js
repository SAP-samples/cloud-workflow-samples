
$.context.CurrentProcessorUserId = $.context.RequesterDetails.RequesterUserId;
$.context.CurrentProcessorName = $.context.RequesterDetails.RequesterFirstName + " " + $.context.RequesterDetails.RequesterLastName;
$.context.CurrentProcessorEmail = $.context.RequesterDetails.RequesterEmail;

$.context.internal.isRework = true;

$.context.comments = "";

$.context.restartWorkflowContext = {
    definitionId: $.context.internal.initialDefinitionId,
    context: {
        RequestId: $.context.RequestId,
        BPRequest: $.context.BPRequest,
        RequesterDetails: $.context.RequesterDetails,
        History: $.context.History,
        BPName: $.context.BPName,
        processStatus: $.context.processStatus,
        CurrentStepName: "",
        internal: {
            isRework: $.context.internal.isRework,
            initialDefinitionId: $.context.internal.initialDefinitionId,
            reworkRequestDetails: $.context.internal.reworkRequestDetails,
            BPCreationResponse: $.context.internal.BPCreationResponse
        }

    }
}