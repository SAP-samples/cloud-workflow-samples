
var action = {
    "Id": $.usertasks.usertask3.last.processor,
    "StepName": "Basic Data Provisioning",
    "Status": $.context.processStatus,
    "Comments": $.context.comments
};

$.context.History.push(action);
$.context.comments = "";