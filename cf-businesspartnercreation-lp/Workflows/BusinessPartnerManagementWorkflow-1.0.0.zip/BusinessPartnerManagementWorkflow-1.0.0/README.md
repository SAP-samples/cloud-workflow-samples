# BusinessPartnerManagementWorkflow - Creating a new Business Partner in S4/HANA

* this project contains the process template (and workflow steps) for the BP creation
* project [CustomUIForBusinessPartnerManagement](https://github.tools.sap/iBPM-Live-Processes/CustomUIForBusinessPartnerManagement) contains the custom UIs
* project [VisibilityActionsBPCreation](https://github.tools.sap/iBPM-Live-Processes/VisibilityActionsBPCreation) contains the workflows used for Visibility actions
