
var action = {
    "Id": $.usertasks.usertask1.last.processor,
    "StepName": "Approval",
    "Status": $.context.processStatus,
    "Comments": $.context.comments
};

$.context.History.push(action);

$.context.internal.isRework = false;
