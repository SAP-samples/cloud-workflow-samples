
$.context.CurrentProcessorUserId = $.context.GetProcessorRuleOutput.Result[0].ProcessDetails.ProcessorUserId;
$.context.CurrentProcessorName = $.context.GetProcessorRuleOutput.Result[0].ProcessDetails.ProcessorName;
$.context.CurrentProcessorEmail = $.context.GetProcessorRuleOutput.Result[0].ProcessDetails.ProcessorEmail;

var dueDuration = $.context.GetProcessorRuleOutput.Result[0].ProcessDetails.DueDuration;
if (isNaN(dueDuration) || dueDuration < 0) {
    throw new Error("Value for DueDuration returned from rule needs to be a positive number, but was " + dueDuration);
}

var minutes = Math.max(0, Math.round(dueDuration * 24 * 60));

if (isNaN(minutes)) {
    throw new Error("Internal error calculating Due Date");
}
$.context.DueDuration = "PT" + minutes + "M"; // minutes may be >60 according to the standard

$.context.comments = "";