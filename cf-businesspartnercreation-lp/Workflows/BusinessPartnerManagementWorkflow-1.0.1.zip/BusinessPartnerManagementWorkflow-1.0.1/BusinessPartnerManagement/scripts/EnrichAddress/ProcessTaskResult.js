
var action = {
    "Id": $.usertasks.usertask1.last.processor,
    "StepName": "Address Data Provisioning",
    "Status": $.context.processStatus,
    "Comments": $.context.comments
};

$.context.History.push(action);
$.context.comments = "";