
$.context.isAddressStepNotRequired = $.context.internal.isRework && !($.context.internal.reworkRequestDetails.isCompleteRework)
    && !($.context.internal.reworkRequestDetails.isAddressRework);