# VisibilityActionsBPCreation
Visibility actions for Business Partner Creation process