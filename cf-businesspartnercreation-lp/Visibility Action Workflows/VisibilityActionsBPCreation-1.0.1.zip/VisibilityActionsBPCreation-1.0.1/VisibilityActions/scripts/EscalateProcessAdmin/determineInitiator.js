
var startedByUserId = $.info.startedBy; 
$.context.initiator = startedByUserId;
