var RuleInput = {
    "RuleServiceId": "2063a642047d49fd9ed83f69d5aa6cb0",
    "RuleServiceRevision": "2104",
    "Vocabulary": [
        {
            "ProcessSubStatus": {
                "SubStatus": $.context.SubStatus
            }
        }
    ]
}
$.context.GetProcessorRuleInput = RuleInput;