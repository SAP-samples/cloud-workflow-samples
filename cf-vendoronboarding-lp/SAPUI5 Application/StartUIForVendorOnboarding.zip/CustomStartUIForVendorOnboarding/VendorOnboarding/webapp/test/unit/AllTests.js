sap.ui.define([
	"com/sap/VendorOnboarding/test/unit/controller/App.controller"
], function () {
	"use strict";
});