sap.ui.define([
	"./BaseController",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessagePopover",
	"sap/m/MessageItem",
	"sap/m/Token",
	"sap/m/Label",
	"sap/m/ColumnListItem",
	"sap/m/SearchField",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, MessageToast, JSONModel, MessageBox, MessagePopover, MessageItem, Token, Label, ColumnListItem, SearchField,
	Filter, FilterOperator) {
	"use strict";
	var oMessagePopover;
	return BaseController.extend("com.sap.VendorOnboarding.controller.Vendoroboarding", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.VendorOnboarding.view.Vendoroboarding
		 */
		onInit: function () {
			this._oRouter = this.getRouter();
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
		    oThisController.oResourceModel = oThisController.getResourceModel("i18n");
			oThisController.getView().setModel(oMdlCommon);
			this._oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "Vendoroboarding") {

				
				}

			}, this);

			

			var oMessageTemplate = new MessageItem({
				type: "{type}",
				title: "{title}",
				description: "{description}",
				subtitle: "{subtitle}",
				activeTitle: true
			});

			oMessagePopover = new MessagePopover({
				items: {
					path: '/',
					template: oMessageTemplate

				}
			});
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.sap.VendorOnboarding.view.Vendoroboarding
		 */
		/*	onBeforeRendering: function () {
			

			},  */
         
         	/**
		 * Convenience method for removing all required Input validation Error.
		 * @public
		 * @returns Remove errors from value help dialog.
		 */
		onChange: function (oEvent) {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var oInput = oEvent.getSource();
		
		
				var	oResourceModel = oThisController.getResourceModel("i18n");
		    	var sSelectedInputErrorMsg = oInput.getValueStateText(),
			    sVendorFNameTitle = oResourceModel.getText("ERROR_MSG_VENDOR_FIRST_NAME"),
			    sVendorLNameTitle = oResourceModel.getText("ERROR_MSG_VENDOR_LAST_NAME"),
	        	sVendorTypeTitle = oResourceModel.getText("ERROR_MSG_VENDOR_TYPE");
		
			switch (sSelectedInputErrorMsg) {
			case "Requester Name is a required field(*)":
			var oMessageModel = oMessagePopover;
				var aDes = oMessageModel.getModel().getData();
				for (var i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						var index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
			
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
			
				break;
			case "Requester Employee ID is a required field(*)":
			 oMessageModel = oMessagePopover;
			 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
					 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;

			case  "Request Date & Time is a required field(*)":
			
				 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
			
					if (aDes === 0) {
						this.getView().byId("popover_btn").setVisible(false);
					}
				this.getView().byId("popover_btn").setText(aDes.length);		
				break;
				case  "Requester Contact Number is a required field(*)":
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
				
				
					case  "Requester Email is a required field(*)":
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
				
				
					case  "Invalid Requester Email":
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
				
				
				case  sVendorFNameTitle:
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
				
					case  sVendorLNameTitle:
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
					case  sVendorTypeTitle:
						
					
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				oMdlCommon = oThisController.getParentModel("mCommon");
			    if (oEvent.getSource().getProperty("valueState") === "Error") {
				oEvent.getSource().setProperty("valueState", "None");
				oEvent.getSource().setProperty("valueStateText", "");
			}
		
			var sSelectedItem = oEvent.getSource().getSelectedItem().getText();
			oMdlCommon.setProperty("/oVendorDetails/sVendorType", sSelectedItem);
				break;	
				case  "Account Group is a required field(*)":
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;		
				case  "Vendor Contact Number is a required field(*)":
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
				
				
					case   "Vendor Email is a required field(*)":
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
				
			
					case   "Invalid Email ID":
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
				
				
				
					case  "Vendor Confirm Email is a required field(*)":
					 oMessageModel = oMessagePopover;
				 aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
				
			
			    case  "Invalid Email ID To Confirm Email":
					 oMessageModel = oMessagePopover;
				     aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
			
				 case  "Confirm Email ID Doesn't Match":
					 oMessageModel = oMessagePopover;
				     aDes = oMessageModel.getModel().getData();
				for ( i = 0; i < aDes.length; i++) {
				
					if (aDes[i].title === sSelectedInputErrorMsg) {
						 index = aDes.indexOf(aDes[i]);
						if (index > -1) {
							aDes.splice(index, 1);
						}
					}

				}
				oMessageModel.getModel().setData(aDes);
				this.getView().byId("popover_btn").setText(aDes.length);
				break;	
				
			default:
			}
           if (oEvent.getSource().getProperty("valueState") === "Error") {

				oEvent.getSource().setProperty("valueState", "None");
				oEvent.getSource().setProperty("valueStateText", "");
			
				//Set Message Popover Button Visibility based on the length of the Array
				
					var sDataLength = aDes.length;
					this.getView().byId("popover_btn").setText(aDes.length);
					if (sDataLength === 0) {
						this.getView().byId("popover_btn").setVisible(false);
					} else {
						this.getView().byId("popover_btn").setText(aDes.length);
					}
			}

		},



		getResourceModel: function (sName) {
			return this.getOwnerComponent().getModel(sName).getResourceBundle();
		},

		/**
		 * Convenience method for all Input validation errors.
		 * @public
		 * @returns Validate all the required input fields.
		 */
		onPressRegister: function (oEvent) {
		

			var errorExist = false,
				errorData = [],
				oThisController = this,
				oMdlCommon = oThisController.getParentModel("mCommon"),
				oResourceModel = oThisController.getResourceModel("i18n");
				
			oThisController.oBusyDialog = new sap.m.BusyDialog();
			this.getView().byId("popover_btn").setVisible(false);
			oThisController.oBusyDialog.open();
			var requesterFields = ["sRequesterName", "sRequesterEmployeeId",
				"sRequestDateAndTime",
				"sRequesterContactNumber",
				"sRequesterEmail"
			];
			var requesterValue;
			for (var i = 0; i < requesterFields.length; i++) {
				requesterValue = oMdlCommon.getProperty("/" + "oRequesterDetails" + "/" + requesterFields[i]);
				if (requesterValue && requesterValue.trim() && requesterValue !== "" && requesterValue !== "undefined" && requesterValue !==
					"null") {
					oMdlCommon.setProperty("/" + "oRequesterDetails" + "/" + requesterFields[i] + "state", "None");
				} else {
					errorExist = true;
					if (requesterFields[i] === "sRequesterName") {
						errorData.push({
							type: "Error",
							title: "Requester Name is a required field(*)",
							subtitle: "Requester Name",
							description: "Please Enter Requester Name"
						});
						oMdlCommon.setProperty("/" + requesterFields[i] + "stateText", "Requester Name is a required field(*)");
					}
					if (requesterFields[i] === "sRequesterEmployeeId") {
						errorData.push({
							type: "Error",
							title: "Requester Employee ID is a required field(*)",
							subtitle: "Requester Employee ID",
							description: "Please Enter Requester Employee Id"
						});
						oMdlCommon.setProperty("/" + requesterFields[i] + "stateText", "Requester Employee ID is a required field(*)");
					}
					if (requesterFields[i] === "sRequestDateAndTime") {
						errorData.push({
							type: "Error",
							title: "Request Date & Time is a required field(*)",
							subtitle: "Request Date And Time",
							description: "Please Select Request Date & Time"
						});
						oMdlCommon.setProperty("/" + requesterFields[i] + "stateText", "Request Date & Time is a required field(*)");
					}
					if (requesterFields[i] === "sRequesterContactNumber") {
						errorData.push({
							type: "Error",
							title: "Requester Contact Number is a required field(*)",
							subtitle: "Requester Contact",
							description: "Please Enter Requester Contact Number"
						});
						oMdlCommon.setProperty("/" + requesterFields[i] + "stateText", "Requester Contact Number is a required field(*)");
					}
					if (requesterFields[i] === "sRequesterEmail") {
						errorData.push({
							type: "Error",
							title: "Requester Email is a required field(*)",
							subtitle: "Requester Email",
							description: "Please Enter Requester Email"
						});
						oMdlCommon.setProperty("/" + requesterFields[i] + "stateText", "Requester Email is a required field(*)");
					}

					oMdlCommon.setProperty("/" + requesterFields[i] + "state", "Error");

				}
			}

			var vendorFields = [
				"sVendorFName",
				
				"sVendorType",
				"sAccountGroup",
				"sVendorContactNumber",
				"sVendorEmail",
				"sVendorConfEmail"
			];
			var vendorValue;
			for ( i = 0; i < vendorFields.length; i++) {

				vendorValue = oMdlCommon.getProperty("/" + "oVendorDetails" + "/" + vendorFields[i]);
				if (vendorValue && vendorValue.trim() && vendorValue !== "" && vendorValue !== "undefined" && vendorValue !== "null") {
					oMdlCommon.setProperty("/" + "oVendorDetails" + "/" + vendorFields[i] + "state", "None");
				} else {
					errorExist = true;
					if (vendorFields[i] === "sVendorFName") {
					var sVendorFNameTitle = oResourceModel.getText("ERROR_MSG_VENDOR_FIRST_NAME"),
					     sVendorFNameSubtitle = oResourceModel.getText("ERROR_MSG_VENDOR_FIRST_NAME_SUBTITLE"),
					     sVendorFNameDescription = oResourceModel.getText("ERROR_MSG_VENDOR_FIRST_NAME_DESCRIPTION");
						errorData.push({
							type: "Error",
							title: sVendorFNameTitle,
							subtitle: sVendorFNameSubtitle ,
							description: sVendorFNameDescription
						});
						oMdlCommon.setProperty("/" + vendorFields[i] + "stateText", sVendorFNameTitle);

					}
			

					if (vendorFields[i] === "sVendorType") {
						var sVendorTypeTitle = oResourceModel.getText("ERROR_MSG_VENDOR_TYPE"),
					     sVendorTypeSubtitle = oResourceModel.getText("ERROR_MSG_VENDOR_TYPE_SUBTITLE"),
					     sVendorTypeDescription = oResourceModel.getText("ERROR_MSG_VENDOR_TYPE_DESCRIPTION");
						errorData.push({
							type: "Error",
							title: sVendorTypeTitle,
							subtitle: sVendorTypeSubtitle,
							description: sVendorTypeDescription
						});
						oMdlCommon.setProperty("/" + vendorFields[i] + "stateText", sVendorTypeTitle);
					}

					if (vendorFields[i] === "sAccountGroup") {
						errorData.push({
							type: "Error",
							title: "Account Group is a required field(*)",
							subtitle: "Account Group",
							description: "Please Enter Account Group"
						});
						oMdlCommon.setProperty("/" + vendorFields[i] + "stateText", "Account Group is a required field(*)");
					}

					if (vendorFields[i] === "sVendorContactNumber") {
						errorData.push({
							type: "Error",
							title: "Vendor Contact Number is a required field(*)",
							subtitle: "Vendor Contact",
							description: "Please Enter Vendor Contact Number"
						});
						oMdlCommon.setProperty("/" + vendorFields[i] + "stateText", "Vendor Contact Number is a required field(*)");
					}

					if (vendorFields[i] === "sVendorEmail") {
						errorData.push({
							type: "Error",
							title: "Vendor Email is a required field(*)",
							subtitle: "Vendor Email",
							description: "Please Enter Vendor Email"
						});                                      
						oMdlCommon.setProperty("/" + vendorFields[i] + "stateText", "Vendor Email is a required field(*)");
					}
					if (vendorFields[i] === "sVendorConfEmail") {
						errorData.push({
							type: "Error",
							title: "Vendor Confirm Email is a required field(*)",
							subtitle: "Confirm Email",
							description: "Please Enter Vendor Confirm Email"
						});
						oMdlCommon.setProperty("/" + vendorFields[i] + "stateText", "Vendor Confirm Email is a required field(*)");
					}
					oMdlCommon.setProperty("/" + vendorFields[i] + "state", "Error");

				}
			}

			// Email Validation
			var requesterEmail = oMdlCommon.getProperty("/oRequesterDetails/sRequesterEmail");
			var vendorEmail = oMdlCommon.getProperty("/oVendorDetails/sVendorEmail");
			var confirmMail = oMdlCommon.getProperty("/oVendorDetails/sVendorConfEmail");
			if (confirmMail && vendorEmail && confirmMail.toLowerCase() !== vendorEmail.toLowerCase()) {
				var errorDataTitle = oResourceModel.getText("msgTitleVendorConfirmEmail"),
					errorDataDes = oResourceModel.getText("msgDesVendorConfirmEmail");
				errorExist = true;
				errorData.push({
					type: "Error",
					title: errorDataTitle,
					description: errorDataDes
				});
				oMdlCommon.setProperty("/sVendorConfEmailstate", "Error");
				oMdlCommon.setProperty("/sVendorConfEmailstateText", errorDataTitle);
			}

			var mailregex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
			if (requesterEmail && !mailregex.test(requesterEmail)) {
				var invalidReqEmail = oResourceModel.getText("msgTitleInvalidReqstEmail");
				var invalidReqEmailDes = oResourceModel.getText("msgDesInvalidResqEmail");
				errorExist = true;
				errorData.push({
					type: "Error",
					title: invalidReqEmail,
					description: invalidReqEmailDes
				});
				oMdlCommon.setProperty("/sRequesterEmailstate", "Error");
				oMdlCommon.setProperty("/sRequesterEmailstateText", invalidReqEmail);
			}
			if (vendorEmail && !mailregex.test(vendorEmail)) {
		 errorDataTitle = oResourceModel.getText("msgTitleInvalidVendorEmail");
					errorDataDes = oResourceModel.getText("msgDesInvalidVendorEmail");
				errorExist = true;
				errorData.push({
					type: "Error",
					title: errorDataTitle,
					description: errorDataDes
				});
				oMdlCommon.setProperty("/sVendorEmailstate", "Error");
				oMdlCommon.setProperty("/sVendorEmailstateText", errorDataTitle);
			}

			if (confirmMail && !mailregex.test(confirmMail)) {
				errorDataTitle = oResourceModel.getText("msgTitleInvalidVendorConfirmEmail");
					errorDataDes = oResourceModel.getText("msgDesInvalidVendorConfirmEmail");
				errorExist = true;
				errorData.push({
					type: "Error",
					title: errorDataTitle,
					description: errorDataDes
				});
				oMdlCommon.setProperty("/sVendorConfEmailstate", "Error");
				oMdlCommon.setProperty("/sVendorConfEmailstateText", errorDataTitle);

			}

		

			if (errorExist) {
				var errorModel = new sap.ui.model.json.JSONModel();
				errorModel.setData(errorData);
				this.getView().byId("popover_btn").setText(errorData.length);
				oMessagePopover.setModel(errorModel);
				this.getView().setModel(errorModel);
				this.getView().byId("popover_btn").setVisible(true);
				oThisController.oBusyDialog.close();
				return;
			} else {

				oMdlCommon = oThisController.getParentModel("mCommon");
				this.goForRegistration();
			}

		},
			/**
		 * Convenience method for accessing the workflow service.
		 * @public
		 * @returns Get validation Id and start workflow instance.
		 */
		goForRegistration: function () {
			var oThisController = this;
			oThisController.getDefinitionId();
		},
		
			getDefinitionId: function () {
			// First get the CSRF token
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var sVendorType = oMdlCommon.getProperty("/oVendorDetails/sVendorType");
			var sAccountGroup = oMdlCommon.getProperty("/oVendorDetails/sAccountGroup");
			var oPayload = {
				"RuleServiceId": "9122562166ea480db34219f7e27ea5d2",
				"RuleServiceRevision": "2006",
				"Vocabulary": [{
					"ProcessVariantInput": {
						"AccountGroup": sAccountGroup,
						"VendorType": sVendorType
					}
				}]
			};
            var sUrl = oThisController._getBusinessRulesRuntimeBaseURL() + "/rules-service/v1/rules/xsrf-token";
			$.ajax({
				url: sUrl,
				method: "GET",
				headers: {
					"X-CSRF-Token": "Fetch"
				},
				success: function (result, xhr, data) {
					var bpmruletoken = data.getResponseHeader("X-CSRF-Token");
                    var sUrl = oThisController._getBusinessRulesRuntimeBaseURL() + "/rules-service/rest/v2/rule-services";
					//Then invoke the business rules service via public API
					$.ajax({
						url: sUrl,
						method: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload),
						async: false,
						headers: {
							"X-CSRF-Token": bpmruletoken
						},
						success: function (result1, xhr1, data1) {
							if (result1.Result.length === 0) {
								//info: the output from rules will be wrapped in result1 object, you can 
								// access this json object to get the output variable.
								MessageBox.warning("DefinitionId is not available.");
								return;
							} else {
							oMdlCommon.setProperty("/sDefinitionId", result1.Result[0].ProcessVariantList[0].VariantId);
							 oThisController.fetchToken();	
							}
						},
						error: function (jqXHR, textStatus, errorThrown) {
							MessageBox.error("Error occurred while accessing Configure Business Rules.");
							return;
						}
					});
				},
				error: function (iXHR, textStatus, errorThrown) {
					MessageBox.error("Error occured while fetching Business Rules access token. /n/" + "Error:" + " " + errorThrown);
					return;
				}
			});
		},

/**
		 * Convenience method for accessing the workflow service.
		 * @public
		 * @returns start workflow instance.
		 */
		fetchToken: function () {
            var oThisController = this;
            var sUrl = oThisController._getWorkflowRuntimeBaseURL() + "/xsrf-token";
			// @ts-ignore
			$.ajax({
				url: sUrl,
				method: "GET",
				headers: {

					"X-CSRF-Token": "Fetch"
				},
				success: function (result, xhr, data) {

					// After retrieving the xsrf token successfully
					var workflowtoken = data.getResponseHeader("X-CSRF-Token");

					// Values entered by the user stored in the payload and push to the server.
				     	oThisController.startInstance(workflowtoken);

				},
				error: function (jqXHR, textStatus, errorThrown) {

					//MessageBox.error("Error occurred while fetching work-flow access token.");
					var sErrorText = oThisController.getMessage("WORKFLOW_ACCESS_TOKEN_ERROR");
					MessageBox.error(sErrorText + "\n Error:" + errorThrown + ".");
					oThisController.oBusyDialog.close();
					return;

				}
			});
		},

		startInstance: function (workflowtoken) {

			var oThisController = this,
                oMdlCommon = oThisController.getParentModel("mCommon");
            var sUrl = oThisController._getWorkflowRuntimeBaseURL() + "/workflow-instances";
			var sDifinitionId = oMdlCommon.getProperty("/sDefinitionId");
			var Data2 = {
				"definitionId": sDifinitionId,
				"context": {
					"sRequestId": oMdlCommon.getProperty("/oRequesterDetails/sRequestId"),
					"sRequesterName": oMdlCommon.getProperty("/oRequesterDetails/sRequesterName"),
					"sRequesterEmployeeId": oMdlCommon.getProperty("/oRequesterDetails/sRequesterEmployeeId"),
					"sRequestDateAndTime": oMdlCommon.getProperty("/oRequesterDetails/sRequestDateAndTime"),
					"sRequesterContactNumber": oMdlCommon.getProperty("/oRequesterDetails/sRequesterContactNumber"),
					"sRequesterEmail": oMdlCommon.getProperty("/oRequesterDetails/sRequesterEmail"),
					"sVendorFName": oMdlCommon.getProperty("/oVendorDetails/sVendorFName"),
					"sVendorLName": oMdlCommon.getProperty("/oVendorDetails/sVendorLName"),
					"sVendorType": oMdlCommon.getProperty("/oVendorDetails/sVendorType"),
					"sAccountGroup": oMdlCommon.getProperty("/oVendorDetails/sAccountGroup"),
					"sVendorContactNumber": oMdlCommon.getProperty("/oVendorDetails/sVendorContactNumber"),
					"sVendorEmail": oMdlCommon.getProperty("/oVendorDetails/sVendorEmail")
				}
			};

			// @ts-ignore
			$.ajax({
				url: sUrl,
				method: "POST",
				dataType: "json",
				crossDomain: false,
				contentType: "application/json",
				data: JSON.stringify(Data2),
				cache: true,
				headers: { // pass the xsrf token retrieved earlier
					"X-CSRF-Token": workflowtoken
				},
				success: function (odata) {
					oMdlCommon.setProperty("/oEnable/sInput", false);
					oMdlCommon.setProperty("/oEnable/bRegister", false);
					var currRequestId = oMdlCommon.getProperty("/oRequesterDetails/sRequestId");
					oThisController.oBusyDialog.close();
					oMdlCommon.refresh(true);
					MessageBox.success("Vendor creation request " + currRequestId + " submitted.");
				},
				error: function (jqXHR, textStatus, errorThrown) {
					var sErrorText = oThisController.getMessage("WORKFLOW_SERVICE_ERROR");
					MessageBox.error(sErrorText + "\n Error:" + errorThrown + ".");
					oThisController.oBusyDialog.close();
					return;
				}
			});
		},

		handleMessagePopoverPress: function (oEvent) {
			oMessagePopover.openBy(oEvent.getSource());
		},
		
		onValueHelpRequested: function (oEvent) {
			var sInputField = oEvent.getSource().data().inputCustomData;
			if (sInputField === "aAccountGroup") {
				var oMdlCommon = this.getParentModel("mCommon");
				//	oMdlCommon.setProperty("/oNewVendor/AccountGroup", "");
				var aCols = oMdlCommon.getData().oAccountGroup.cols;
				var sAccountGroupPayload = {
					"RuleServiceId": "1dfa74c6f0404b429302fbf3d09e4521",
					"Vocabulary": [{
						"AccountGroupInput": {
							"AccountGroup": ""
						}
					}]
				};
				this.onCallBusinessRule(aCols, sInputField, sAccountGroupPayload);
			}
		},
		
		/**
		 * @purpose Call Business Rule API
		 * @param1 oColumns -- Columns Data to the table
		 * @param2 sInputName -- Selected Key(Custom Data)
		 * @param3 oPayload -- Business Rule API Call Payload Data
		 */
		
		
		onCallBusinessRule: function (oColumns, sInputName, oPayload) {
			var oThisController = this;

			var oMdlCommon = oThisController.getParentModel("mCommon");
			oThisController.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputName);
			oMdlCommon.setProperty("/" + sInputName, []);
            // First get the CSRF token
            var sUrl = oThisController._getBusinessRulesRuntimeBaseURL() + "/rules-service/v1/rules/xsrf-token";
			$.ajax({
				url: sUrl,
				method: "GET",
				headers: {
					"X-CSRF-Token": "Fetch"
				},
				success: function (result, xhr, data) {
					var token = data.getResponseHeader("X-CSRF-Token");
                    var sUrl = oThisController._getBusinessRulesRuntimeBaseURL() + "/rules-service/rest/v2/workingset-rule-services";
					//Then invoke the business rules service via public API
					$.ajax({
						url: sUrl,
						method: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload),
						async: false,
						headers: {
							"X-CSRF-Token": token
						},

						success: function (result1, xhr1, data1) {
							var oInputData = "/" + sInputName;
							oMdlCommon.setProperty(oInputData, result1.Result[0].AccountGroupList);
							oThisController.fnCreateFragment(oMdlCommon, oColumns, oInputData);
						}
					});
				}
			});
		},

		fnCreateFragment: function (oMdlCommon, oColumns, oInputData) {
			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");
			if (sSelectedInput === "aAccountGroup") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "AccountGroup");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "AccountGroup");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "");
				oMdlCommon.setProperty("/oDialog/sTitle", "Account Group");
			}
			this._oBasicSearchField = new SearchField({
				showSearchButton: false
			});
		    if (!this._oValueHelpDialog) {
			    this._oValueHelpDialog = sap.ui.xmlfragment("com.sap.VendorOnboarding.fragments.BusinessValueHelp", this);
			    this.getView().addDependent(this._oValueHelpDialog);
            }
			// Filter Configuration 
			var oFilterBar = this._oValueHelpDialog.getFilterBar();
			oFilterBar.setFilterBarExpanded(false);
			oFilterBar.setBasicSearch(this._oBasicSearchField);

			// Binding  Data to the Table 
			this._oValueHelpDialog.getTableAsync().then(function (oTable) {
				oTable.setModel(oMdlCommon);
				var oNewModel = new JSONModel();
				oNewModel.setData({
					cols: oColumns
				});
				oTable.setModel(oNewModel, "columns");
				if (oTable.bindRows) {
					oTable.bindAggregation("rows", oInputData);
				}
				if (oTable.bindItems) {
					oTable.bindAggregation("items", oInputData, function () {
						return new ColumnListItem({
							cells: oColumns.map(function (column) {
								return new Label({
									text: "{" + column.template + "}"
								});
							})
						});
					});
				}
				this._oValueHelpDialog.update();
			}.bind(this));
			this.closeBusyDialog();
			this._oValueHelpDialog.open();
		},

		onValueHelpOkPress: function (oEvent) {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var aTokens = oEvent.getParameter("tokens");
			var text = aTokens[0].getText();
			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");
			if (sSelectedInput === "aAccountGroup") {
				oMdlCommon.setProperty("/oVendorDetails/sAccountGroup", text);
				var errorExist = oMdlCommon.getProperty("/sAccountGroupstate");
				if (errorExist === "Error") {
					oMdlCommon.setProperty("/sAccountGroupstate", "None");
					oMdlCommon.setProperty("/sAccountGroupstateText", "");
					var oMessageModel = oMessagePopover;
					var aDes = oMessageModel.getModel().getData();
					for (var i = 0; i < aDes.length; i++) {
						if (aDes[i].title === "Account Group is a required field(*)") {
							var index = aDes.indexOf(aDes[i]);
							if (index > -1) {
								aDes.splice(index, 1);
							}
						}
					}

					oMessageModel.getModel().setData(aDes);
					var sDataLength = aDes.length;
					this.getView().byId("popover_btn").setText(aDes.length);
					if (sDataLength === 0) {
						this.getView().byId("popover_btn").setVisible(false);
					} else {
						this.getView().byId("popover_btn").setText(aDes.length);
					}
				}
			}
			this._oValueHelpDialog.close();
		},
		onValueHelpCancelPress: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			oMdlCommon.setProperty("/oVendorDetails/sAccountGroup", "");
			this._oValueHelpDialog.close();
			oMdlCommon.refresh();
		},
		onValueHelpAfterClose: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");	
			if (this._oValueHelpDialog) {
   	        this._oValueHelpDialog.destroy();
         	this._oValueHelpDialog = null; // make it falsy so that it can be created next time
             }
			oMdlCommon.refresh();	
		},
		onFilterBarSearch: function (oEvent) {
			var sSearchQuery = this._oBasicSearchField.getValue(),
				aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}
				return aResult;
			}, []);

			aFilters.push(new Filter({
				filters: [
					new Filter({
						path: "NumberRange",
						operator: FilterOperator.Contains,
						value1: sSearchQuery
					}),
					new Filter({
						path: "AccountGroup",
						operator: FilterOperator.Contains,
						value1: sSearchQuery
					}),
					new Filter({
						path: "Name",
						operator: FilterOperator.Contains,
						value1: sSearchQuery
					})
				],
				and: false
			}));

			this._filterTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterTable: function (oFilter) {
			var oValueHelpDialog = this._oValueHelpDialog;

			oValueHelpDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				oValueHelpDialog.update();
			});
		},
        onSelectVendor: function(oEvent){
		var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var	oResourceModel = oThisController.getResourceModel("i18n");
	     	var sVendorTypeTitle = oResourceModel.getText("ERROR_MSG_VENDOR_TYPE");

			var sSelectedItem = oEvent.getSource().getSelectedItem().getText();
			oMdlCommon.setProperty("/oVendorDetails/sVendorType", sSelectedItem);
			var errorExist = oMdlCommon.getProperty("/sVendorTypestate");
            if (errorExist === "Error") {
                oMdlCommon.setProperty("/sVendorTypestate", "None");
                oMdlCommon.setProperty("/sVendorTypestateText", "");
                var oMessageModel = oMessagePopover;
                var aDes = oMessageModel.getModel().getData();
                for (var i = 0; i < aDes.length; i++) {

                    if (aDes[i].title === sVendorTypeTitle) {
                        var index = aDes.indexOf(aDes[i]);
                        if (index > -1) {
                            aDes.splice(index, 1);
                        }
                    }
                }
                oMessageModel.getModel().setData(aDes);
                var sDataLength = aDes.length;
                this.getView().byId("popover_btn").setText(aDes.length);
                if (sDataLength === 0) {
                    this.getView().byId("popover_btn").setVisible(false);
                } else {
                    this.getView().byId("popover_btn").setText(aDes.length);
                }
            }
        },
        _getAppModulePath: function (){
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            return jQuery.sap.getModulePath(appPath);
        },
        _getWorkflowRuntimeBaseURL: function () {
            return `${this._getAppModulePath()}/workflowruntime/v1`;
        },
        _getBusinessRulesRuntimeBaseURL: function () {
            return `${this._getAppModulePath()}/bpmrulesruntime`;
        }
	});
});