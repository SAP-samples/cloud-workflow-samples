sap.ui.define([
	"./BaseController",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessagePopover",
	"sap/m/MessageItem",
	"sap/m/Token",
	"sap/m/Label",
	"sap/m/ColumnListItem",
	"sap/m/SearchField",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"

], function (BaseController, MessageToast, JSONModel, MessageBox, MessagePopover, MessageItem, Token, Label, ColumnListItem, SearchField,
	Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.sap.VendorOnboarding.controller.App", {
		onInit: function () {
			
			
				var oThisController = this;
		     
		     	oThisController.fnInitializeApp();
				oThisController.getContentDensityClass();
		}

	
		/*	onAfterRendering: function () {

				

			},  */
	
		/*	onBeforeRendering: function () {

			
			},  */

	

		
		/**
		 * @purpose Message from Resource Bundle 
		 * @param1 pMessage -- String-Property of Resource Bundle
		 * @param2 aParametrs -- Array-Parameters
		 */
		

	});
});