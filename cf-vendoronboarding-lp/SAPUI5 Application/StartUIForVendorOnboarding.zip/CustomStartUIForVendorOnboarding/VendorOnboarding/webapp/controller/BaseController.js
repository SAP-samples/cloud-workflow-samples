sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessagePopover",
	"sap/m/MessageItem",
	"sap/m/Token",
	"sap/m/Label",
	"sap/m/ColumnListItem",
	"sap/m/SearchField",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"

], function (Controller, UIComponent, MessageToast, JSONModel, MessageBox, MessagePopover, MessageItem, Token, Label, ColumnListItem,
	SearchField,
	Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.sap.VendorOnboarding.controller.BaseController", {

		fnInitializeApp: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var sRootPath = jQuery.sap.getModulePath("com.sap.VendorOnboarding");
			oMdlCommon.attachRequestCompleted(function (oEvent) {
				
				var requestId = Math.floor(Date.now() / 1000);
				oMdlCommon.setProperty("/oRequesterDetails/sRequestId", requestId);
				oMdlCommon.refresh();
			});
			oMdlCommon.loadData(sRootPath + "/model/Property.json", null, false);
			

		},
	/**
		 * Convenience method for accessing the parent model.
		 * @public
		 * @returns Parent JSON Model "mCommon" defined in manifest
		 */
		getParentModel: function (sName) {
			var oMdl = this.getOwnerComponent().getModel(sName);
			oMdl.setSizeLimit(100000);
			if (!oMdl) {
				oMdl = new JSONModel({});
				this.setParentModel(oMdl, sName);
			}
			return oMdl;
		},

		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},
		
			/**
		 * Convenience method for accessing the ContentDesityClass.
		 * @public
		 * @returns Content Density Class, defined in the component.js
		 */
		getContentDensityClass: function () {
			var oThisController = this;
			oThisController.getView().addStyleClass(oThisController.getOwnerComponent().getContentDensityClass());
		},
		
	     /**
		 * Convenience method for accessing the Busy Indicator Dialog
		 * @public
		 * @returns Busy Indicator Dialog
		 */
		 
		_BusyDialog: new sap.m.BusyDialog({
			busyIndicatorDelay: 0 //,
		}),

 /**
		 * Convenience method for accessing the Busy Indicator Dialog
		 * @public
		 * @returns Open Busy Indicator Dialog
		 */
		openBusyDialog: function () {
			if (this._BusyDialog) {
				this._BusyDialog.open();
			} else {
				this._BusyDialog = new sap.m.BusyDialog({
					busyIndicatorDelay: 0
				});
				this._BusyDialog.open();
			}
		},
 /**
		 * Convenience method for accessing the Busy Indicator Dialog
		 * @public
		 * @returns Close Busy Indicator Dialog
		 */
		closeBusyDialog: function () {
			if (this._BusyDialog) {
				this._BusyDialog.close();
			}
		},

		//	@ Methos to get text from i!8n Model
		getMessage: function (pMessage, aParametrs) {
			// read msg from i18n model
			var sMsg = "";
			var oMdlI18n = this.getOwnerComponent().getModel("i18n");
			if (oMdlI18n) {
				this._oBundle = oMdlI18n.getResourceBundle();
			} else {
				this._oBundle = null;
				return sMsg;
			}

			if (aParametrs && aParametrs.length) {
				sMsg = this._oBundle.getText(pMessage, aParametrs);
			} else {
				sMsg = this._oBundle.getText(pMessage);
			}

			return sMsg;
		}



	});

});