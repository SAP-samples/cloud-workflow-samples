sap.ui.define([
	"com/sap/VendorRegistration/test/unit/controller/App.controller"
], function () {
	"use strict";
});