sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/m/Label",
	"sap/m/ColumnListItem",
	"sap/m/SearchField",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"

], function (Controller, JSONModel, MessageBox, Token, Label, ColumnListItem, SearchField, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.sap.PurchasingVendor.controller.App", {
		onInit: function () {
			var oThisController = this;
			var	oMdlCommon = oThisController.getParentModel("mCommon");
			var	sRootPath = jQuery.sap.getModulePath("com.sap.PurchasingVendor");
			oMdlCommon.attachRequestCompleted(function (oEvent) {
				oMdlCommon.refresh();
			});
			oMdlCommon.loadData(sRootPath + "/model/Property.json", null, false);
			oThisController.getContentDensityClass();

		},
		/**
		 * Convenience method fo setting the context data on common model.
		 * @public
		 * @param 
		 * @returns Read context data to be displayed in UI input fields.
		 */
		onAfterRendering: function () {

			var oComponent = this.getOwnerComponent();
			var oTaskModel = oComponent.getModel("oModel");
			var oThisController = this,
				oMdlCommon = oThisController.getParentModel("mCommon");

			var oTaskData = oTaskModel.getData();

			oMdlCommon.setProperty("/oBasicDetails", oTaskData);

		},

		showMessage: function (pMessage, pMsgTyp, pHandler) {

			if (pMessage.trim().length === 0) {
				return;
			}

			if (["A", "E", "I", "W"].indexOf(pMsgTyp) === -1) {
				sap.m.MessageToast.show(pMessage);
			} else {
				var sIcon = "";
				var sTitle = "";

				switch (pMsgTyp) {
				case 'W':
					sIcon = "WARNING";
					sTitle = "Warning";
					break;
				case 'E':
					sIcon = "ERROR";
					break;
				case 'I':
					sIcon = "INFORMATION";
					sTitle = "Information";
					break;
				case 'A':
					sIcon = "NONE";
					break;
				default:
				}
				MessageBox.show(pMessage, {
					icon: sIcon,
					title: sTitle,
					onClose: pHandler,
					styleClass: "sapUiSizeCompact"
				});
			}
		},
		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getParentModel: function (sName) {
			var oMdl = this.getOwnerComponent().getModel(sName);
			oMdl.setSizeLimit(999);
			if (!oMdl) {
				oMdl = new JSONModel({});
				this.setParentModel(oMdl, sName);
			}
			return oMdl;
		},

		/**
		 * Convenience method for adding a new row in the partner table
		 * @public
		 * @returns  {Object}- aAddPartner Array
		 */

		onPressAddPartner: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var oNewPartner = oMdlCommon.getProperty("/oPurchasingData");
			var oRow = {
				"sPartner": "",
				"sName": "",
				"sNumber": "",
				"sName1": ""

			};
			oNewPartner.aAddPartner.push(oRow);
			oMdlCommon.setProperty("/oPurchasingData", oNewPartner);
		},
		/**
		 * Convenience method for deleting selected row.
		 * @public
		 * @returns  Remove {Object}- aAddPartner Array
		 */
		onHandleDelete: function (oEvent) {
			var oThisController = this;
			oThisController.openBusyDialog();

			var oMdlcommon = oThisController.getParentModel("mCommon");
			var bindingContext = oEvent.getSource().getBindingContext("mCommon");
			var deleteRecord = bindingContext.getObject();
			var aAddPartner = oMdlcommon.getProperty("/oPurchasingData/aAddPartner");

			if (aAddPartner.length > 1) {
				for (var i = 0; i < aAddPartner.length; i++) {
					if (aAddPartner[i] == deleteRecord) {
						//	pop this._data.Products[i] 
						var oRemoved = aAddPartner.splice(i, 1); //removing 1 record from i th index.

						oMdlcommon.setProperty("/oPurchasingData/aAddPartner", aAddPartner);
						oThisController.closeBusyDialog();
						oMdlcommon.refresh();
						sap.m.MessageToast.show(JSON.stringify(oRemoved[0]) + " " + "is removed.");
						break; //quit the loop
					}
				}
			} else {
				oThisController.showMessage(oThisController.getMessage("RESTRICTION"), "I");
				oThisController.closeBusyDialog();

			}

		},

		openBusyDialog: function () {
			if (this._BusyDialog) {
				this._BusyDialog.open();
			} else {
				this._BusyDialog = new sap.m.BusyDialog({
					busyIndicatorDelay: 0
				});
				this._BusyDialog.open();
			}
		},

		closeBusyDialog: function () {
			if (this._BusyDialog) {
				this._BusyDialog.close();
			}
		},
		/**
		 * @purpose Message from Resource Bundle 
		 * @param1 pMessage -- String-Property of Resource Bundle
		 * @param2 aParametrs -- Array-Parameters
		 */
		getMessage: function (pMessage, aParametrs) {
			// read msg from i18n model
			var sMsg = "";
			var oMdlI18n = this.getOwnerComponent().getModel("i18n");
			if (oMdlI18n) {
				this._oBundle = oMdlI18n.getResourceBundle();
			} else {
				this._oBundle = null;
				return sMsg;
			}

			if (aParametrs && aParametrs.length) {
				sMsg = this._oBundle.getText(pMessage, aParametrs);
			} else {
				sMsg = this._oBundle.getText(pMessage);
			}

			return sMsg;
		},
		/**
		 * Convenience method to access the business rule services for value help.
		 * @public
		 * @param 
		 * @returns Open value help dialog based on the custom data defined on the input fields.
		 */
		onValueHelpRequested: function (oEvent) {
			var sInputField = oEvent.getSource().data().inputCustomData;
			var oMdlCommon;
			var aCols;
			var sUrl;
			var bindingContext = oEvent.getSource().getBindingContext("mCommon");
			var oThisController = this;

			switch (sInputField) {
			case "TermsOfPayment":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oTermsOfPayment.cols;
				var oTermsOfPaymentPayload = {
					"RuleServiceId": "5f694b01c6fe407982169bd7092b3c49",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oTermsOfPaymentPayload);

				break;

			case "PurchasingGroup":
				sUrl = "/PurchasingGroup";
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oPurchasingGroup.cols;
				this.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputField);

				/*   @Param sInputField a custom Data set on xml input field.
				    Access Iflow services by passing param sInputField.  */
				this.fnGetLookupCpiData(sInputField, aCols, sUrl);

				break;

			case "PartnerFunctions":

				oThisController.sSelectedObject = bindingContext.getObject();
				sUrl = "/PartnerFunctions";
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oPartnerFunctions.cols;
				this.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputField);

				/*   @Param sInputField a custom Data set on xml input field.
				     Access Iflow services by passing param sInputField.  */

				this.fnGetLookupCpiData(sInputField, aCols, sUrl);
				break;

			case "PricingDateControl":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oPricingDateControl.cols;
				var oPricingDateControlPayload = {
					"RuleServiceId": "898151370a674c13bca77a523cc0f668",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oPricingDateControlPayload);

				break;

			case "ShippingConditions":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oShippingConditions.cols;
				var oShippingConditionsPayload = {
					"RuleServiceId": "3726273992704d14a011ff7658f58395",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oShippingConditionsPayload);

				break;

			case "Incoterms":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oIncoterms.cols;
				var oIncotermsPayload = {
					"RuleServiceId": "9cd17da11c0d48e798eef02f9b7bcb09",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oIncotermsPayload);

				break;

			case "OfficeOfEntry":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oOfficeOfEntry.cols;
				var oOfficeOfEntryPayload = {
					"RuleServiceId": "13d809c37323482fb6c83ed67a64a39b",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oOfficeOfEntryPayload);

				break;

			case "OrderCurrency":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oOrderCurrency.cols;
				var oOrderCurrencyPayload = {
					"RuleServiceId": "5cbc0a064cb1495f8ad37057c580a02f",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oOrderCurrencyPayload);

				break;

			case "PartnerNumber":
				oThisController.sSelectedObject = bindingContext.getObject();

				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oPartnerNumber.cols;
				var oPartnerNumberPayload = {
					"RuleServiceId": "b7a4604380e743bf9e578d0e247081c1",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oPartnerNumberPayload);

				break;

			case "PurchaseOrganization":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oPurchaseOrganization.cols;
				var oPurchaseOrganizationPayload = {
					"RuleServiceId": "86ae83f2385f47c398cc76c75d62765f",
					"Vocabulary": [{
						"PurchasingGroupInput": {
							"PurchasingGroup": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oPurchaseOrganizationPayload);

				break;

			case "ModeOfTrnsprtBorder":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oModeOfTrnsprtBorder.cols;
				var oModeOfTrnsprtBorderPayload = {
					"RuleServiceId": "8d9b3e6e184f4c8c91ddb34d0727cfd4",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oModeOfTrnsprtBorderPayload);

				break;

			}

		},
		/**
		 * Convenience method to call business rule API
		 * @public
		 * @param1  oColumns- All columns in the value help dialog table.
		 * @param2  sInputName- Find the selected input field based on the custom input data.
		 * @param3  oPayLoad-  Payload for calling business rule API
		 * @returns  Table row data.
		 */
		onCallBusinessRule: function (oColumns, sInputName, oPayload) {
			var oThisController = this;

			var oMdlCommon = oThisController.getParentModel("mCommon");
			oThisController.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputName);
			oMdlCommon.setProperty("/" + sInputName, []);
            // First get the CSRF token
            var sUrl = oThisController._getBusinessRulesRuntimeBaseURL() + "/v1/rules/xsrf-token";
			$.ajax({
				url: sUrl,
				method: "GET",
				headers: {
					"X-CSRF-Token": "Fetch"
				},
				success: function (result, xhr, data) {
					var token = data.getResponseHeader("X-CSRF-Token");

                    //Then invoke the business rules 
                    var sUrl = oThisController._getBusinessRulesRuntimeBaseURL() + "/rest/v2/workingset-rule-services";
					$.ajax({
						url: sUrl,
						method: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload),
						async: false,
						headers: {
							"X-CSRF-Token": token
						},

						success: function (result1, xhr1, data1) {
							var oInputData = "/" + sInputName;
							switch (sInputName) {
							case "TermsOfPayment":
								oMdlCommon.setProperty(oInputData, result1.Result[0].TermsOfPaymentList);
								break;
							case "PricingDateControl":
								oMdlCommon.setProperty(oInputData, result1.Result[0].PricingDateControlList);
								break;

							case "ShippingConditions":
								oMdlCommon.setProperty(oInputData, result1.Result[0].ShippingConditionsList);
								break;

							case "Incoterms":
								oMdlCommon.setProperty(oInputData, result1.Result[0].IncotermsList);
								break;
							case "OfficeOfEntry":
								oMdlCommon.setProperty(oInputData, result1.Result[0].OfficeOfEntryList);
								break;
							case "OrderCurrency":
								oMdlCommon.setProperty(oInputData, result1.Result[0].OrderCurrencyList);
								break;
							case "PartnerNumber":
								oMdlCommon.setProperty(oInputData, result1.Result[0].NumberList);
								break;
							case "PurchaseOrganization":
								oMdlCommon.setProperty(oInputData, result1.Result[0].PurchasingGroupList);
								break;

							case "ModeOfTrnsprtBorder":
								oMdlCommon.setProperty(oInputData, result1.Result[0].ModeOfTransportList);
								break;

							default:
							}

							oThisController.fnCreateFragment(oMdlCommon, oColumns, oInputData);

						},
						error: function (jqXHR, textStatus, errorThrown) {
							oThisController.showMessage(oThisController.getMessage("BUSINESS_RULE_ERROR"), "E");
							//	MessageBox.error("Error occurred while accessing Configure Business Rules.\n Error:" + errorThrown);
						}
					});
				},
				error: function (jqXHR, textStatus, errorThrown) {
					//	oMdlCommon.setProperty("/oError/serviceError", true);
					//	MessageBox.error("Error occurred while fetching access token.\n Error:" + errorThrown);

					oThisController.showMessage(oThisController.getMessage("ACCESS_TOKEN_ERROR"), "E");

				}
			});
		},

		/**
		 * Convenience method to open value help dialog
		 * @public
		 * @param1  oColumns- All columns in the value help dialog table.
		 * @param2  sInputName- Find the selected input field based on the custom input data.
		 * @param3  sUrl-  URL to call the CPI services.
		 * @returns  Open value help dialog.
		 */
		fnGetLookupCpiData: function (sInputName, oColumns, sUrl) {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			oThisController.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputName);
			oMdlCommon.setProperty("/" + sInputName, []);
            
            var url = oThisController._getCPIRulesRuntimeBaseURL() + sUrl;
			$.ajax({
				type: "GET",
				contentType: "application/json",
				url: url,
				dataType: "json",
				success: function (data, textStatus, jqXHR) {

					var oInputData = "/" + sInputName;
					oMdlCommon.setProperty(oInputData, data["RFC_READ_TABLE.Response"].DATA.item);
					oThisController.fnCreateFragment(oMdlCommon, oColumns, oInputData);
				}
			});
		},
		/**
		 * Convenience method to open value help dialog
		 * @public
		 * @param1  oColumns- All columns in the value help dialog table.
		 * @param2  sInputName- Find the selected input field based on the custom input data.
		 * @param3  oMdlCommon-  'mCommon' common data model.
		 * @returns  Open value help dialog.
		 */
		fnCreateFragment: function (oMdlCommon, oColumns, oInputData) {

			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");
			if (sSelectedInput === "TermsOfPayment") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "PaymentTerms");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "OwnExplanation");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "PaymentTerms");
				oMdlCommon.setProperty("/oDialog/sTitle", "Terms Of Payment");

			}
			if (sSelectedInput === "PurchasingGroup") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Purchasing Group");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "PurchasingGroup");
				oMdlCommon.setProperty("/oDialog/sTitle", "Purchasing Group");
			}

			if (sSelectedInput === "PartnerFunctions") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Partner");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "PartnerFunction");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "");
				oMdlCommon.setProperty("/oDialog/sTitle", "Partner Functions");
			}
			if (sSelectedInput === "PricingDateControl") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "ShortDescription");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "PricingDateControl");
				oMdlCommon.setProperty("/oDialog/sTitle", "Pricing Date Control");
			}
			if (sSelectedInput === "ShippingConditions") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "ShippingConditions");
				oMdlCommon.setProperty("/oDialog/sTitle", "Shipping Conditions");
			}
			if (sSelectedInput === "Incoterms") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Incoterms");
				oMdlCommon.setProperty("/oDialog/sTitle", "Incoterms");
			}
			if (sSelectedInput === "OfficeOfEntry") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "CustomsOffice");
				oMdlCommon.setProperty("/oDialog/sTitle", "Office Of Entry");
			}
			if (sSelectedInput === "OrderCurrency") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "ShortDescription");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "OrderCurrency");
				oMdlCommon.setProperty("/oDialog/sTitle", "Order Currency");
			}
			if (sSelectedInput === "PartnerNumber") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "VendorNumber");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "");
				oMdlCommon.setProperty("/oDialog/sTitle", "Business Partner Number");
			}
			if (sSelectedInput === "PurchaseOrganization") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "PurchasingGroupDescription");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "PurchasingGroup");
				oMdlCommon.setProperty("/oDialog/sTitle", "Purchase Organization");
			}

			if (sSelectedInput === "ModeOfTrnsprtBorder") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "ModeOfTransport");
				oMdlCommon.setProperty("/oDialog/sTitle", "Foreign Trade Transport Mode");
			}

			this._oBasicSearchField = new SearchField({
				showSearchButton: false
			});

			this._oValueHelpDialog = sap.ui.xmlfragment("com.sap.PurchasingVendor.fragments.BusinessValueHelp", this);
			this.getView().addDependent(this._oValueHelpDialog);

			var oFilterBar = this._oValueHelpDialog.getFilterBar();
			//	oFilterBar.setFilterBarExpanded(false);
			oFilterBar.setBasicSearch(this._oBasicSearchField);

			this._oValueHelpDialog.getTableAsync().then(function (oTable) {
				oTable.setModel(oMdlCommon);

				var oNewModel = new JSONModel();
				oNewModel.setData({
					cols: oColumns
				});
				oTable.setModel(oNewModel, "columns");

				if (oTable.bindRows) {
					oTable.bindAggregation("rows", oInputData);
				}

				if (oTable.bindItems) {

					oTable.bindAggregation("items", oInputData, function () {
						return new ColumnListItem({
							cells: oColumns.map(function (column) {
								return new Label({
									text: "{" + column.template + "}"
								});
							})
						});
					});
				}
				this._oValueHelpDialog.update();
			}.bind(this));

			this._oValueHelpDialog.open();

		},
		/**
		 * Convenience method to filter table data.
		 * @public
		 * @param  oEvent- Get Property 'selectionSet'
		 * @returns  Filter table data based on given values.
		 */
		onFilterBarSearch: function (oEvent) {

			var sSearchQuery = this._oBasicSearchField.getValue(),
				aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getValue()) {

					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			var oMdlCommon = this.getParentModel("mCommon"),
				sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");
			switch (sSelectedInput) {
			case 'TermsOfPayment':
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "OwnExplanation",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "PaymentTerms",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;
			case 'PartnerFunctions':
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "PartnerFunction",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "UniqueMasterData",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "HigherLevelPartnerFunction",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;
			case 'PurchasingGroup':
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "PurchasingGroup",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "PricingDateControl":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "PricingDateControl",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "ShortDescription",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "ShippingConditions":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "ShippingConditions",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "Incoterms":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "Incoterms",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "OfficeOfEntry":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CountryKey",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CustomsOffice",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "OrderCurrency":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "OrderCurrency",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "ShortDescription",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "PartnerNumber":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "VendorNumber",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "PurchaseOrganization":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "PurchasingGroupDescription",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "PurchasingGroup",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "ModeOfTrnsprtBorder":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "Country",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "ModeOfTransport",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			default:
			}

			this._filterTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterTable: function (oFilter) {
			var oValueHelpDialog = this._oValueHelpDialog;

			oValueHelpDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				oValueHelpDialog.update();
			});
		},
		/**
		 * Convenience method to select key and description value
		 * @public
		 * @param  oEvent- Get the existing token.
		 * @returns  capture key and description value in token.
		 */
		onValueHelpOkPress: function (oEvent) {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");

			var aTokens = oEvent.getParameter("tokens");
			var text = aTokens[0].getText();
			var key = aTokens[0].getKey();
			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");

			if (sSelectedInput === "TermsOfPayment") {

				var sTermsOfPaymentError = oMdlCommon.getProperty("/sTermsOfPaymentstate");
				if (sTermsOfPaymentError === "Error") {
					oMdlCommon.setProperty("/sTermsOfPaymentstate", "None");
					oMdlCommon.setProperty("/sTermsOfPaymentstateText", "");
				}

				oMdlCommon.setProperty("/oPurchasingData/sTermsOfPayment", key);
				oMdlCommon.setProperty("/oPurchasingData/sTermsOfPaymentKey", text);
			}

			if (sSelectedInput === "PurchasingGroup") {

				var sPurchasingGroupError = oMdlCommon.getProperty("/sPurchasingGroupstate");
				if (sPurchasingGroupError === "Error") {
					oMdlCommon.setProperty("/sPurchasingGroupstate", "None");
					oMdlCommon.setProperty("/sPurchasingGroupstateText", "");
				}

				oMdlCommon.setProperty("/oPurchasingData/sPurchasingGroup", key);
				oMdlCommon.setProperty("/oPurchasingData/sPurchasingGroupKey", text);

			}
			if (sSelectedInput === "PartnerFunctions") {

				oThisController.sSelectedObject.sPartner = text;
			}
			if (sSelectedInput === "PartnerNumber") {
				oThisController.sSelectedObject.sNumber = text;
				//	oMdlCommon.setProperty("/oPurchasingData/aAddPartner/0/sNumber", text);
			}
			if (sSelectedInput === "PricingDateControl") {
				oMdlCommon.setProperty("/oPurchasingData/sPricingDateControl", key);
				oMdlCommon.setProperty("/oPurchasingData/sPricingDateControlKey", text);
			}
			if (sSelectedInput === "ShippingConditions") {
				oMdlCommon.setProperty("/oPurchasingData/sShippingConditions", key);
				oMdlCommon.setProperty("/oPurchasingData/sShippingConditionsKey", text);

			}
			if (sSelectedInput === "Incoterms") {

				var sIncotermsError = oMdlCommon.getProperty("/sIncotermsstate");
				if (sIncotermsError === "Error") {
					oMdlCommon.setProperty("/sIncotermsstate", "None");
					oMdlCommon.setProperty("/sIncotermsstateText", "");
				}

				oMdlCommon.setProperty("/oPurchasingData/sIncoterms", key);
				oMdlCommon.setProperty("/oPurchasingData/sIncotermsKey", text);

			}
			if (sSelectedInput === "OfficeOfEntry") {
				oMdlCommon.setProperty("/oPurchasingData/sOfficeOfEntry", key);
				oMdlCommon.setProperty("/oPurchasingData/sOfficeOfEntryKey", text);
			}

			if (sSelectedInput === "OrderCurrency") {

				var sOrderCurrency = oMdlCommon.getProperty("/sOrderCurrencystate");
				if (sOrderCurrency === "Error") {
					oMdlCommon.setProperty("/sOrderCurrencystate", "None");
					oMdlCommon.setProperty("/sOrderCurrencystateText", "");
				}
				oMdlCommon.setProperty("/oPurchasingData/sOrderCurrency", key);
				oMdlCommon.setProperty("/oPurchasingData/sOrderCurrencyKey", text);
			}

			if (sSelectedInput === "PurchaseOrganization") {

				var sPurchaseOrganization = oMdlCommon.getProperty("/sPurchaseOrganizationstate");
				if (sPurchaseOrganization === "Error") {
					oMdlCommon.setProperty("/sPurchaseOrganizationstate", "None");
					oMdlCommon.setProperty("/sPurchaseOrganizationstateText", "");
				}
				oMdlCommon.setProperty("/oPurchasingData/sPurchaseOrganization", key);
				oMdlCommon.setProperty("/oPurchasingData/sPurchaseOrganizationKey", text);
			}

			if (sSelectedInput === "ModeOfTrnsprtBorder") {
				oMdlCommon.setProperty("/oPurchasingData/sModeOfTrnsprtBorder", key);
				oMdlCommon.setProperty("/oPurchasingData/sModeOfTrnsprtBorderKey", text);

			}

			this._oValueHelpDialog.close();
		},

		/**
		 * Convenience method to close existing value help dialog.
		 * @public
		 * @returns  Set property 'null' for selected key and description.
		 */

		onValueHelpCancelPress: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");
			if (sSelectedInput === "TermsOfPayment") {
				oMdlCommon.setProperty("/oPurchasingData/sTermsOfPayment", "");
				oMdlCommon.setProperty("/oPurchasingData/sTermsOfPaymentKey", "");
			}

			if (sSelectedInput === "PurchasingGroup") {
				/*  uText = text.substring(0, text.length - 3);
		        textUpdated = uText.trim();  */
				oMdlCommon.setProperty("/oPurchasingData/sPurchasingGroup", "");
			}
			if (sSelectedInput === "PartnerFunctions") {
				/*  uText = text.substring(0, text.length - 3);
		        textUpdated = uText.trim();  */
				//	oMdlCommon.setProperty("/oPurchasingData/aAddPartner/0/sPartner", "");
				oThisController.sSelectedObject.sPartner = "";
			}

			if (sSelectedInput === "PricingDateControl") {
				oMdlCommon.setProperty("/oPurchasingData/sPricingDateControl", "");
				oMdlCommon.setProperty("/oPurchasingData/sPricingDateControlKey", "");
			}

			if (sSelectedInput === "ShippingConditions") {
				oMdlCommon.setProperty("/oPurchasingData/sShippingConditions", "");
				oMdlCommon.setProperty("/oPurchasingData/sShippingConditionsKey", "");
			}

			if (sSelectedInput === "Incoterms") {
				oMdlCommon.setProperty("/oPurchasingData/sIncoterms", "");
				oMdlCommon.setProperty("/oPurchasingData/sIncotermsKey", "");
			}

			if (sSelectedInput === "OfficeOfEntry") {
				oMdlCommon.setProperty("/oPurchasingData/sOfficeOfEntry", "");
			}
			if (sSelectedInput === "OrderCurrency") {
				var sOrderCurrency = oMdlCommon.getProperty("/sOrderCurrencystate");
				if (sOrderCurrency) {
					oMdlCommon.setProperty("/sOrderCurrencystate", "None");
					oMdlCommon.setProperty("/sOrderCurrencystateText", "");
				}
				oMdlCommon.setProperty("/oPurchasingData/sOrderCurrency", "");
			}

			if (sSelectedInput === "PartnerNumber") {
				// oMdlCommon.setProperty("/oPurchasingData/aAddPartner/0/sNumber", "");
				oThisController.sSelectedObject.sNumber = "";
			}
			if (sSelectedInput === "PurchaseOrganization") {

				var sPurchaseOrganization = oMdlCommon.getProperty("/sPurchaseOrganizationstate");
				if (sPurchaseOrganization === "Error") {
					oMdlCommon.setProperty("/sPurchaseOrganizationstate", "None");
					oMdlCommon.setProperty("/sPurchaseOrganizationstateText", "");
				}
				oMdlCommon.setProperty("/oPurchasingData/sPurchaseOrganization", "");
			}
			if (sSelectedInput === "ModeOfTrnsprtBorder") {
				oMdlCommon.setProperty("/oPurchasingData/sModeOfTrnsprtBorder", "");
			}

			this._oValueHelpDialog.close();
			oMdlCommon.refresh();
		},
		/**
		 * Convenience method to destroy the existing value help dialog.
		 * @public
		 * @returns  Destroy the value help dialog and set property 'null'
		 */
		onValueHelpAfterClose: function () {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			if (this._oValueHelpDialog) {
				this._oValueHelpDialog.destroy();
				this._oValueHelpDialog = null; // make it falsy so that it can be created next time
			}
			oMdlCommon.refresh();
		},
		/**
		 * Convenience method to change the 'valueState' & 'valueStateText' property of inputs.
		 * @public
		 * @param  oEvent- Get property 'valueState'
		 * @returns set 'valueState' & 'valueStateText' property of an input.
		 */
		onLiveChange: function (oEvent) {

			var errorExist = oEvent.getSource().getProperty("valueState");
			if (errorExist === "Error") {

				oEvent.getSource().setProperty("valueState", "None");
				oEvent.getSource().setProperty("valueStateText", "");

			}
		},
		/**
		 * Convenience method for getting the ContentDensity Class.
		 * @public
		 * @param 
		 * @returns set a sapui5 predefined class on view before loading.
		 */
		getContentDensityClass: function () {
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
        },
        _getAppModulePath: function (){
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            return jQuery.sap.getModulePath(appPath);
        },
        _getBusinessRulesRuntimeBaseURL: function () {
            return `${this._getAppModulePath()}/bpmrulesruntime/rules-service`;
        },
        _getCPIRulesRuntimeBaseURL: function () {
            return `${this._getAppModulePath()}/CPI_Dest/http`;
        }

	});
});