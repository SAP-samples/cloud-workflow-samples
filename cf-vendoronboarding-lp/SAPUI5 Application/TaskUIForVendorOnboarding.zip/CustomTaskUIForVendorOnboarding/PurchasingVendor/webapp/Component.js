sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/sap/PurchasingVendor/model/models",
    "sap/m/MessageBox"
], function (UIComponent, Device, models, MessageBox) {
    "use strict";

    return UIComponent.extend("com.sap.PurchasingVendor.Component", {

        metadata: {
            manifest: "json"
        },

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
        init: function () {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // enable routing
            this.getRouter().initialize();

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            // get task data
            var startupParameters = this.getComponentData().startupParameters;
            this.setModel(startupParameters.taskModel, "task");

            // read process context & bind it to the view's model
            var that = this;
            var contextModel = new sap.ui.model.json.JSONModel(that._getTaskInstancesBaseURL() + "/context");

            contextModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
            this.setModel(contextModel);
            this.setModel(contextModel, "oModel");

            var oPositiveAction = {
                sBtnTxt: "Submit",
                onBtnPressed: function () {
                    var model = that.getModel();
                    model.refresh(true);
                    var processContext = model.getData();
                    that._triggerComplete(
                        processContext,
                        that.getTaskInstanceID(),
                        true,
                        jQuery.proxy(that._refreshTask, that));
                }
            };

            startupParameters.inboxAPI.addAction(
                {
                    action: oPositiveAction.sBtnTxt,
                    label: oPositiveAction.sBtnTxt,
                    type: "Accept"
                },
                oPositiveAction.onBtnPressed);
        },

        _triggerComplete: function (processContext,
            taskId, approvalStatus,
            refreshTask) {
            var mCommon = this.getModel("mCommon");
            var that = this;
            var bError = mCommon.getProperty("/bError");
            that._BusyDialog = new sap.m.BusyDialog({
                busyIndicatorDelay: 6
            });

            that._BusyDialog.open();

            var oMandatoryFields = [
                "sPurchaseOrganization",
                "sOrderCurrency"

            ];
            var sFieldValue;
            for (var i = 0; i < oMandatoryFields.length; i++) {
                sFieldValue = mCommon.getProperty("/" + "oPurchasingData" + "/" + oMandatoryFields[i]);
                if (sFieldValue && sFieldValue.trim() && sFieldValue !== "" && sFieldValue !== "undefined" && sFieldValue !==
                    "null") {
                    mCommon.setProperty("/" + "oPurchasingData" + "/" + oMandatoryFields[i] + "state", "None");

                } else {
                    mCommon.setProperty("/bError", true);
                    if (oMandatoryFields[i] === "sPurchaseOrganization") {

                        mCommon.setProperty("/" + oMandatoryFields[i] + "stateText", "Purchasing Organization Required(*)");
                    }
                    if (oMandatoryFields[i] === "sOrderCurrency") {

                        mCommon.setProperty("/" + oMandatoryFields[i] + "stateText", "Order Currency Required(*)");
                    }

                    mCommon.setProperty("/" + oMandatoryFields[i] + "state", "Error");
                }

            }
            bError = mCommon.getProperty("/bError");
            if (bError) {

                mCommon.setProperty("/bError", false);
                MessageBox.error("A validation error has occured. Complete your input first");
                that._BusyDialog.close();
            } else {
                var sUrl = that._getBusinessRulesRuntimeBaseURL() + "/v1/rules/xsrf-token";
                var a1 = $.ajax({
                    url: sUrl,
                    method: "GET",
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {
                        var token = data.getResponseHeader("X-CSRF-Token");
                        var sAccountGroup = mCommon.getProperty("/oBasicDetails/sAccountGroup");
                        var sVendorType = mCommon.getProperty("/oBasicDetails/sVendorType");
                        var sCountry = mCommon.getProperty("/oBasicDetails/sCountry");
                        var oPayload = {
                            "RuleServiceId": "b65b33f90a6b475d9f60bccc282e3a12",
                            "RuleServiceRevision": "2006",
                            "Vocabulary": [{
                                "ValidationInput": {
                                    "VendorType": sVendorType,
                                    "AccountGroup": sAccountGroup,
                                    "CountryKey": sCountry
                                }
                            }]
                        };
                        //Invoke Business Rules
                        var sUrl = that._getBusinessRulesRuntimeBaseURL() + "/rest/v2/rule-services";
                        $.ajax({
                            url: sUrl,
                            method: "POST",
                            contentType: "application/json",
                            data: JSON.stringify(oPayload),
                            async: false,
                            headers: {
                                "X-CSRF-Token": token
                            },

                            success: function (result1, xhr1, data1) {
                                that._BusyDialog.close();

                                var oResultData = result1.Result[0].AdditionalValidationList;

                                for (var i = 0; i < oResultData.length; i++) {

                                    var sFieldId = oResultData[i].FieldID;
                                    switch (sFieldId) {
                                        case "IdTermsOfPayment":

                                            var sTermsOfPayment = mCommon.getProperty("/oPurchasingData/sTermsOfPayment");
                                            if (!sTermsOfPayment) {
                                                mCommon.setProperty("/bError", true);
                                                var sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sTermsOfPaymentstate", "Error");
                                                mCommon.setProperty("/sTermsOfPaymentstateText", sErrorDes);
                                            }
                                            break;
                                        case "IdIncoterms":

                                            var sIncoterms = mCommon.getProperty("/oPurchasingData/sIncoterms");
                                            if (!sIncoterms) {

                                                mCommon.setProperty("/bError", true);
                                                sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sIncotermsstate", "Error");
                                                mCommon.setProperty("/sIncotermsstateText", sErrorDes);
                                            }
                                            break;
                                        case "IdPurchasingGroup":

                                            var sPurchasingGroup = mCommon.getProperty("/oPurchasingData/sPurchasingGroup");
                                            if (!sPurchasingGroup) {
                                                mCommon.setProperty("/bError", true);
                                                sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sPurchasingGroupstate", "Error");
                                                mCommon.setProperty("/sPurchasingGroupstateText", sErrorDes);
                                            }
                                            break;
                                        case "IdPlannedDelivery":
                                            var sPlannedDelivTime = mCommon.getProperty("/oPurchasingData/sPlannedDelivTime");
                                            if (!sPlannedDelivTime) {
                                                mCommon.setProperty("/bError", true);
                                                sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sPlannedDelivTimestate", "Error");
                                                mCommon.setProperty("/sPlannedDelivTimestateText", sErrorDes);
                                            }
                                            break;
                                        default:
                                    }
                                }
                            },
                            error: function (jqXHR, textStatus, errorThrown) {
                                that._BusyDialog.close();
                            }
                        });
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        that._BusyDialog.close();
                    }
                }),
                    a2 = a1.then(function () {
                        bError = mCommon.getProperty("/bError");
                        if (bError) {
                            mCommon.setProperty("/bError", false);
                            MessageBox.error("A validation error has occured. Complete your input first");
                            that._BusyDialog.close();
                        } else {
                            var sUrl = that._getWorkflowRuntimeBaseURL() + "/xsrf-token";
                            $.ajax({
                                url: sUrl,
                                method: "GET",
                                headers: {
                                    "X-CSRF-Token": "Fetch"
                                },
                                success: function (result, xhr, data) {
                                    var token = data.getResponseHeader("X-CSRF-Token");
                                    var oBasicData;
                                    oBasicData = {
                                        context: {
                                            "sPurchaseOrganization": mCommon.getProperty("/oPurchasingData/sPurchaseOrganization"),
                                            "sPurchaseOrganizationKey": mCommon.getProperty("/oPurchasingData/sPurchaseOrganizationKey"),
                                            "sOrderCurrency": mCommon.getProperty("/oPurchasingData/sOrderCurrency"),
                                            "sOrderCurrencyKey": mCommon.getProperty("/oPurchasingData/sOrderCurrencyKey"),
                                            "sTermsOfPayment": mCommon.getProperty("/oPurchasingData/sTermsOfPayment"),
                                            "sTermsOfPaymentKey": mCommon.getProperty("/oPurchasingData/sTermsOfPaymentKey"),
                                            "sIncoterms": mCommon.getProperty("/oPurchasingData/sIncoterms"),
                                            "sIncotermsKey": mCommon.getProperty("/oPurchasingData/sIncotermsKey"),
                                            "sMinimumOrderValue": mCommon.getProperty("/oPurchasingData/sMinimumOrderValue"),
                                            "sSchemaGroupVendor": mCommon.getProperty("/oPurchasingData/sSchemaGroupVendor"),
                                            "sPricingDateControl": mCommon.getProperty("/oPurchasingData/sPricingDateControl"),
                                            "sPricingDateControlKey": mCommon.getProperty("/oPurchasingData/sPricingDateControlKey"),
                                            "sOrderOptimRest": mCommon.getProperty("/oPurchasingData/sOrderOptimRest"),
                                            "sABCIndicator": mCommon.getProperty("/oPurchasingData/sABCIndicator"),
                                            "sModeOfTrnsprtBorder": mCommon.getProperty("/oPurchasingData/sModeOfTrnsprtBorder"),
                                            "sModeOfTrnsprtBorderKey": mCommon.getProperty("/oPurchasingData/sModeOfTrnsprtBorderKey"),
                                            "sOfficeOfEntry": mCommon.getProperty("/oPurchasingData/sOfficeOfEntry"),
                                            "sOfficeOfEntryKey": mCommon.getProperty("/oPurchasingData/sOfficeOfEntryKey"),
                                            "sSortCriterion": mCommon.getProperty("/oPurchasingData/sSortCriterion"),
                                            "sPROACTControlProf": mCommon.getProperty("/oPurchasingData/sPROACTControlProf"),
                                            "sShippingConditions": mCommon.getProperty("/oPurchasingData/sShippingConditions"),
                                            "sShippingConditionsKey": mCommon.getProperty("/oPurchasingData/sShippingConditionsKey"),
                                            "sPurchasingGroup": mCommon.getProperty("/oPurchasingData/sPurchasingGroup"),
                                            "sPurchasingGroupKey": mCommon.getProperty("/oPurchasingData/sPurchasingGroupKey"),
                                            "sPlannedDelivTime": mCommon.getProperty("/oPurchasingData/sPlannedDelivTime"),
                                            "sConfirmationControl": mCommon.getProperty("/oPurchasingData/sConfirmationControl"),
                                            "sUnitOfMeasureGrp": mCommon.getProperty("/oPurchasingData/sUnitOfMeasureGrp"),
                                            "sRoundingProfile": mCommon.getProperty("/oPurchasingData/sRoundingProfile"),
                                            "sPriceMarkingAgreed": mCommon.getProperty("/oPurchasingData/sPriceMarkingAgreed"),
                                            "sServLevel": mCommon.getProperty("/oPurchasingData/sServLevel"),
                                            "sAccWithVendor": mCommon.getProperty("/oPurchasingData/sAccWithVendor"),
                                            "aAddPartner": mCommon.getProperty("/oPurchasingData/aAddPartner")
                                        },
                                        "status": "COMPLETED"
                                    };
                                    var iTimeoutId = setTimeout(function () {
                                        that._BusyDialog.close();
                                    }.bind(this), 4000);
                                    var sUrl = that._getTaskInstancesBaseURL();
                                    $.ajax({
                                        url: sUrl,
                                        method: "PATCH",
                                        contentType: "application/json",
                                        data: JSON.stringify(oBasicData),
                                        headers: {
                                            "X-CSRF-Token": token
                                        },
                                        success: refreshTask
                                    });
                                }
                            });
                        }
                    });
            }
        },

        _refreshTask: function () {
            var taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
            this.getComponentData().startupParameters.inboxAPI.updateTask("NA", taskId);
        },
        getContentDensityClass: function () {
            if (!this._sContentDensityClass) {
                if (!sap.ui.Device.support.touch) {
                    this._sContentDensityClass = "sapUiSizeCompact";
                } else {
                    this._sContentDensityClass = "sapUiSizeCozy";
                }
            }
            return this._sContentDensityClass;
        },
        _getAppModulePath: function () {
            var appId = this.getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            return jQuery.sap.getModulePath(appPath);
        },
        _getWorkflowRuntimeBaseURL: function () {
            return `${this._getAppModulePath()}/workflowruntime/v1`;
        },
        _getBusinessRulesRuntimeBaseURL: function () {
            return `${this._getAppModulePath()}/bpmrulesruntime/rules-service`;
        },
        _getTaskInstancesBaseURL: function () {
            return this._getWorkflowRuntimeBaseURL() + "/task-instances/" + this.getTaskInstanceID();
        },
        getTaskInstanceID: function () {
            return this.getModel("task").getData().InstanceID;
        }

    });
});