# CustomUIForVendorOnboaring
Tak UI and start UI used in Vendor Onboarding live process package - developed by Incture Technologies.