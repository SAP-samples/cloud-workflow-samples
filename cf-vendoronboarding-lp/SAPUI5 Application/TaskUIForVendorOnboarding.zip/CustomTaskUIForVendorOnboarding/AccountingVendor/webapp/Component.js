sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/sap/AccountingVendor/model/models",
    "sap/m/MessageBox"
], function (UIComponent, Device, models, MessageBox) {
    "use strict";

    return UIComponent.extend("com.sap.AccountingVendor.Component", {

        metadata: {
            manifest: "json"
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // enable routing
            this.getRouter().initialize();

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            //Get resource Model

            var oMdlI18n = this.getModel("i18n");
            if (oMdlI18n) {
                this._oBundle = oMdlI18n.getResourceBundle();
            }

            // get task data
            var startupParameters = this.getComponentData().startupParameters;
            this.setModel(startupParameters.taskModel, "task");

            // read process context & bind it to the view's model
            var that = this;
            var contextModel = new sap.ui.model.json.JSONModel(that._getTaskInstancesBaseURL() + "/context");

            contextModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
            this.setModel(contextModel);
            this.setModel(contextModel, "oModel");

            // Implementation for the confirm action
            var oPositiveAction = {
                sBtnTxt: "Submit",
                onBtnPressed: function () {
                    var model = that.getModel();
                    model.refresh(true);
                    var processContext = model
                        .getData();
                    // Get the equipment list as a JSON string

                    // Call a local method to perform further action
                    that
                        ._triggerComplete(
                            processContext,
                            that.getTaskInstanceID(),
                            true,
                            jQuery.proxy(that._refreshTask, that));
                }
            };

            // Add 'Confirm' action to the task
            startupParameters.inboxAPI
                .addAction({
                    action: oPositiveAction.sBtnTxt,
                    label: oPositiveAction.sBtnTxt,
                    type: "Accept"
                    // Set the onClick function
                },
                    oPositiveAction.onBtnPressed);

        },

        // This method is called when the confirm button is click by the end user
        _triggerComplete: function (processContext, taskId, approvalStatus, refreshTask) {
            var mCommon = this.getModel("mCommon");
            var that = this;
            var bError = mCommon.getProperty("/bError");
            that._BusyDialog = new sap.m.BusyDialog({
                busyIndicatorDelay: 6
            });

            that._BusyDialog.open();
            var oMandatoryFields = [
                "sCompanyCode"

            ];
            var sFieldValue;
            for (var i = 0; i < oMandatoryFields.length; i++) {
                sFieldValue = mCommon.getProperty("/" + "oAccountingVendor" + "/" + oMandatoryFields[i]);
                if (sFieldValue && sFieldValue.trim() && sFieldValue !== "" && sFieldValue !== "undefined" && sFieldValue !==
                    "null") {
                    mCommon.setProperty("/" + "oAccountingVendor" + "/" + oMandatoryFields[i] + "state", "None");
                } else {
                    mCommon.setProperty("/bError", true);
                    if (oMandatoryFields[i] === "sCompanyCode") {

                        mCommon.setProperty("/" + oMandatoryFields[i] + "stateText", "Company Code Required (*)");
                    }

                    mCommon.setProperty("/" + oMandatoryFields[i] + "state", "Error");
                }

            }
            bError = mCommon.getProperty("/bError");
            if (bError) {
                mCommon.setProperty("/bError", false);
                MessageBox.error("A validation error has occured. Complete your input first");
                that._BusyDialog.close();
            } else {
                var sUrl = that._getBusinessRulesRuntimeBaseURL() + "/v1/rules/xsrf-token";
                var a1 = $.ajax({
                    url: sUrl,
                    method: "GET",
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {

                        var token = data.getResponseHeader("X-CSRF-Token");
                        var sAccountGroup = mCommon.getProperty("/oBasicDetails/sAccountGroup");
                        var sVendorType = mCommon.getProperty("/oBasicDetails/sVendorType");
                        var sCountry = mCommon.getProperty("/oBasicDetails/sCountry");
                        var oPayload = {
                            "RuleServiceId": "b65b33f90a6b475d9f60bccc282e3a12",
                            "RuleServiceRevision": "2006",
                            "Vocabulary": [{
                                "ValidationInput": {
                                    "VendorType": sVendorType,
                                    "AccountGroup": sAccountGroup,
                                    "CountryKey": sCountry
                                }
                            }]
                        };
                        var sUrl = that._getBusinessRulesRuntimeBaseURL() + "/rest/v2/rule-services";
                        //Then invoke the business rules
                        $.ajax({
                            url: sUrl,
                            method: "POST",
                            contentType: "application/json",
                            data: JSON.stringify(oPayload),
                            async: false,
                            headers: {
                                "X-CSRF-Token": token
                            },

                            success: function (result1, xhr1, data1) {
                                var oResultData = result1.Result[0].AdditionalValidationList;
                                for (var i = 0; i < oResultData.length; i++) {
                                    var sFieldId = oResultData[i].FieldID;
                                    switch (sFieldId) {
                                        case "IdGLReconciliationAccount":
                                            var sReconAccount = mCommon.getProperty("/oAccountingVendor/sReconAccount");
                                            if (!sReconAccount) {
                                                mCommon.setProperty("/bError", true);
                                                var sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sReconAccountstate", "Error");
                                                mCommon.setProperty("/sReconAccountstateText", sErrorDes);
                                            }
                                            break;
                                        case "IdHeadOffice":
                                            var sHeadOffice = mCommon.getProperty("/oAccountingVendor/sHeadOffice");
                                            if (!sHeadOffice) {
                                                mCommon.setProperty("/bError", true);
                                                sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sHeadOfficestate", "Error");
                                                mCommon.setProperty("/sHeadOfficestateText", sErrorDes);
                                            }
                                            break;
                                        case "IdWithholdingTaxCode":
                                            var sWTaxCode = mCommon.getProperty("/oAccountingVendor/sWTaxCode");
                                            if (!sWTaxCode) {
                                                mCommon.setProperty("/bError", true);
                                                sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sWTaxCodeState", "Error");
                                                mCommon.setProperty("/sWTaxCodestateText", sErrorDes);
                                            }
                                            break;
                                        case "IdWithholdingTaxCountryKey":
                                            var sWHTaxCountry = mCommon.getProperty("/oAccountingVendor/sWHTaxCountry");
                                            if (!sWHTaxCountry) {
                                                mCommon.setProperty("/bError", true);
                                                sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sWHTaxCountryState", "Error");
                                                mCommon.setProperty("/sWHTaxCountrystateText", sErrorDes);
                                            }
                                            break;
                                        case "IdAlternativePayeeAccountNumber":
                                            var sAlternatPayee = mCommon.getProperty("/oAccountingVendor/sAlternatPayee");
                                            if (!sAlternatPayee) {
                                                mCommon.setProperty("/bError", true);
                                                sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sAlternatPayeestate", "Error");
                                                mCommon.setProperty("/sAlternatPayeestateText", sErrorDes);
                                            }
                                            break;
                                        case "IdHouseBank":
                                            var sHouseBank = mCommon.getProperty("/oAccountingVendor/sHouseBank");
                                            if (!sHouseBank) {
                                                mCommon.setProperty("/bError", true);
                                                sErrorDes = oResultData[i].Message;
                                                mCommon.setProperty("/sHouseBankstate", "Error");
                                                mCommon.setProperty("/sHouseBankstateText", sErrorDes);
                                            }
                                            break;
                                        default:

                                    }

                                }
                            },
                            error: function (jqXHR, textStatus, errorThrown) {

                                that._BusyDialog.close();

                            }
                        });
                    },
                    error: function (jqXHR, textStatus, errorThrown) {

                        that._BusyDialog.close();

                    }
                }),

                    a2 = a1.then(function () {

                        bError = mCommon.getProperty("/bError");
                        if (bError) {

                            mCommon.setProperty("/bError", false);
                            MessageBox.error("A validation error has occured. Complete your input first");
                            that._BusyDialog.close();
                        } else {
                            var sUrl = that._getWorkflowRuntimeBaseURL() + "/xsrf-token";
                            $.ajax({
                                // Call workflow API to get the xsrf token
                                url: sUrl,
                                method: "GET",
                                headers: {
                                    "X-CSRF-Token": "Fetch"
                                },
                                success: function (
                                    result, xhr,
                                    data) {
                                    var token = data.getResponseHeader("X-CSRF-Token");
                                    var oBasicData;

                                    oBasicData = {

                                        context: {
                                            "sCompanyCode": mCommon.getProperty("/oAccountingVendor/sCompanyCode"),
                                            "sCompanyCodeKey": mCommon.getProperty("/oAccountingVendor/sCompanyCodeKey"),
                                            "sReconAccount": mCommon.getProperty("/oAccountingVendor/sReconAccount"),
                                            "sReconAccountKey": mCommon.getProperty("/oAccountingVendor/sReconAccountKey"),
                                            "sShortKey": mCommon.getProperty("/oAccountingVendor/sShortKey"),
                                            "sCashManagementGroup": mCommon.getProperty("/oAccountingVendor/sCashManagementGroup"),
                                            "sCashManagementGroupKey": mCommon.getProperty("/oAccountingVendor/sCashManagementGroupKey"),
                                            "sHeadOffice": mCommon.getProperty("/oAccountingVendor/sHeadOffice"),
                                            "sAccountingAuthorization": mCommon.getProperty("/oAccountingVendor/sAccountingAuthorization"),
                                            "sReleaseGroup": mCommon.getProperty("/oAccountingVendor/sReleaseGroup"),
                                            "sReleaseGroupKey": mCommon.getProperty("/oAccountingVendor/sReleaseGroupKey"),
                                            "sMinorityIndic": mCommon.getProperty("/oAccountingVendor/sMinorityIndic"),
                                            "sCertificationDate": mCommon.getProperty("/oAccountingVendor/sCertificationDate"),
                                            "sInterestIndic": mCommon.getProperty("/oAccountingVendor/sInterestIndic"),
                                            "sLastKeyDate": mCommon.getProperty("/oAccountingVendor/sLastKeyDate"),
                                            "sInterestCycle": mCommon.getProperty("/oAccountingVendor/sInterestCycle"),
                                            "sInterestCycleKey": mCommon.getProperty("/oAccountingVendor/sInterestCycleKey"),
                                            "sLastInterestRun": mCommon.getProperty("/oAccountingVendor/sLastInterestRun"),
                                            "sWTaxCode": mCommon.getProperty("/oAccountingVendor/sWTaxCode"),
                                            "sWTaxCodeKey": mCommon.getProperty("/oAccountingVendor/sWTaxCodeKey"),
                                            "sRecipientType": mCommon.getProperty("/oAccountingVendor/sRecipientType"),
                                            "sExemptionNumber": mCommon.getProperty("/oAccountingVendor/sExemptionNumber"),
                                            "sWHTaxCountry": mCommon.getProperty("/oAccountingVendor/sWHTaxCountry"),
                                            "sValidUntil": mCommon.getProperty("/oAccountingVendor/sValidUntil"),
                                            "sExmptAuthority": mCommon.getProperty("/oAccountingVendor/sExmptAuthority"),
                                            "sExmptAuthorityKey": mCommon.getProperty("/oAccountingVendor/sExmptAuthorityKey"),
                                            "sPreviousAccountNumber": mCommon.getProperty("/oAccountingVendor/sPreviousAccountNumber"),
                                            "sPersonnelNumber": mCommon.getProperty("/oAccountingVendor/sPersonnelNumber"),
                                            "sActivityCode": mCommon.getProperty("/oAccountingVendor/sActivityCode"),
                                            "sDistrType": mCommon.getProperty("/oAccountingVendor/sDistrType"),
                                            "sPaytTerms": mCommon.getProperty("/oAccountingVendor/sPaytTerms"),
                                            "sPaytTermsKey": mCommon.getProperty("/oAccountingVendor/sPaytTermsKey"),
                                            "sPaymentDataToleranceGroup": mCommon.getProperty("/oAccountingVendor/sPaymentDataToleranceGroup"),
                                            "sPaymentDataToleranceGroupKey": mCommon.getProperty("/oAccountingVendor/sPaymentDataToleranceGroupKey"),
                                            "sChkCashingTime": mCommon.getProperty("/oAccountingVendor/sChkCashingTime"),
                                            "sPaymentMethods": mCommon.getProperty("/oAccountingVendor/sPaymentMethods"),
                                            "sPaymentMethodsKey": mCommon.getProperty("/oAccountingVendor/sPaymentMethodsKey"),
                                            "sPaymentBlock": mCommon.getProperty("/oAccountingVendor/sPaymentBlock"),
                                            "sPaymentBlockKey": mCommon.getProperty("/oAccountingVendor/sPaymentBlockKey"),
                                            "sAlternatPayee": mCommon.getProperty("/oAccountingVendor/sAlternatPayee"),
                                            "sHouseBank": mCommon.getProperty("/oAccountingVendor/sHouseBank"),
                                            "sBExchlimit": mCommon.getProperty("/oAccountingVendor/sBExchlimit"),
                                            "sGroupingKey": mCommon.getProperty("/oAccountingVendor/sGroupingKey"),
                                            "sGroupingKeyKey": mCommon.getProperty("/oAccountingVendor/sGroupingKeyKey"),
                                            "sToleranceGroup": mCommon.getProperty("/oAccountingVendor/sToleranceGroup"),
                                            "sToleranceGroupKey": mCommon.getProperty("/oAccountingVendor/sToleranceGroupKey"),
                                            "sPrepayment": mCommon.getProperty("/oAccountingVendor/sPrepayment"),
                                            "sPrepaymentKey": mCommon.getProperty("/oAccountingVendor/sPrepaymentKey"),
                                            "sDunnProcedure": mCommon.getProperty("/oAccountingVendor/sDunnProcedure"),
                                            "sDunnProcedureKey": mCommon.getProperty("/oAccountingVendor/sDunnProcedureKey"),
                                            "sDunningBlock": mCommon.getProperty("/oAccountingVendor/sDunningBlock"),
                                            "sDunningBlockKey": mCommon.getProperty("/oAccountingVendor/sDunningBlockKey"),
                                            "sDunnRecipient": mCommon.getProperty("/oAccountingVendor/sDunnRecipient"),
                                            "sDunnRecipientKey": mCommon.getProperty("/oAccountingVendor/sDunnRecipientKey"),
                                            "sLegalDunnProc": mCommon.getProperty("/oAccountingVendor/sLegalDunnProc"),
                                            "sLastDunned": mCommon.getProperty("/oAccountingVendor/sLastDunned"),
                                            "sDunningLevel": mCommon.getProperty("/oAccountingVendor/sDunningLevel"),
                                            "sDunningClerk": mCommon.getProperty("/oAccountingVendor/sDunningClerk"),
                                            "sDunningClerkKey": mCommon.getProperty("/oAccountingVendor/sDunningClerkKey"),
                                            "sDunningDataGroupingKey": mCommon.getProperty("/oAccountingVendor/sDunningDataGroupingKey"),
                                            "sDunningDataGroupingKeyKey": mCommon.getProperty("/oAccountingVendor/sDunningDataGroupingKeyKey"),
                                            "sAcctgClerk": mCommon.getProperty("/oAccountingVendor/sAcctgClerk"),
                                            "sAcctgClerkKey": mCommon.getProperty("/oAccountingVendor/sAcctgClerkKey"),
                                            "sAcctWVendor": mCommon.getProperty("/oAccountingVendor/sAcctWVendor"),
                                            "sClerkAtVendor": mCommon.getProperty("/oAccountingVendor/sClerkAtVendor"),
                                            "sActClkTelNo": mCommon.getProperty("/oAccountingVendor/sActClkTelNo"),
                                            "sClerkFax": mCommon.getProperty("/oAccountingVendor/sClerkFax"),
                                            "sClrkInternet": mCommon.getProperty("/oAccountingVendor/sClrkInternet"),
                                            "sAccountMemo": mCommon.getProperty("/oAccountingVendor/sAccountMemo")

                                        },
                                        "status": "COMPLETED"
                                    };
                                    var iTimeoutId = setTimeout(function () {
                                        that._BusyDialog.close();
                                    }.bind(this), 4000);
                                    var sUrl = that._getTaskInstancesBaseURL();
                                    $.ajax({
                                        url: sUrl,
                                        method: "PATCH",
                                        contentType: "application/json",
                                        data: JSON.stringify(oBasicData),
                                        headers: {
                                            "X-CSRF-Token": token
                                        },
                                        success: refreshTask
                                    });

                                }

                            });

                        }
                    });
            }

        },
        // Request Inbox to refresh the control once the task is completed
        _refreshTask: function () {
            var taskId = this.getTaskInstanceID()
            this.getComponentData().startupParameters.inboxAPI.updateTask("NA", taskId);
        },
        getContentDensityClass: function () {
            if (!this._sContentDensityClass) {
                if (!sap.ui.Device.support.touch) {
                    this._sContentDensityClass = "sapUiSizeCompact";
                } else {
                    this._sContentDensityClass = "sapUiSizeCozy";
                }
            }
            return this._sContentDensityClass;
        },
        _getAppModulePath: function () {
            var appId = this.getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            return jQuery.sap.getModulePath(appPath);
        },
        _getWorkflowRuntimeBaseURL: function () {
            return `${this._getAppModulePath()}/workflowruntime/v1`;
        },
        _getBusinessRulesRuntimeBaseURL: function () {
            return `${this._getAppModulePath()}/bpmrulesruntime/rules-service`;
        },
        _getTaskInstancesBaseURL: function () {
            return this._getWorkflowRuntimeBaseURL() + "/task-instances/" + this.getTaskInstanceID();
        },
        getTaskInstanceID: function () {
            return this.getModel("task").getData().InstanceID;
        }
    });
});