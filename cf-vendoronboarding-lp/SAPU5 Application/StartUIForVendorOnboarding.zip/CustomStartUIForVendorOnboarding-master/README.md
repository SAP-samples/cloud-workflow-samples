# CustomStartUIVendorOnboarding
SAPUI5 app to start the vendor onboarding process
