sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/m/Label",
	"sap/m/ColumnListItem",
	"sap/m/SearchField",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, MessageBox, Token, Label, ColumnListItem, SearchField, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.sap.AccountingVendor.controller.App", {
		onInit: function () {
			this.getContentDensityClass();

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var sRootPath = jQuery.sap.getModulePath("com.sap.AccountingVendor");
			oMdlCommon.attachRequestCompleted(function (oEvent) {
				oMdlCommon.refresh();
			});
			oMdlCommon.loadData(sRootPath + "/model/Property.json", null, false);
		},
		/**
		 * Convenience method fo setting the context data on common model.
		 * @public
		 * @param 
		 * @returns Read context data to be displayed in UI input fields.
		 */
		onBeforeRendering: function () {
			var oComponent = this.getOwnerComponent();
			var oTaskModel = oComponent.getModel("oModel");
			var oThisController = this,
				oMdlCommon = oThisController.getParentModel("mCommon");
			var oTaskData = oTaskModel.getData();
			oMdlCommon.setProperty("/oBasicDetails", oTaskData);

		},
		/**
		 * Convenience method for getting the ContentDensity Class.
		 * @public
		 * @param 
		 * @returns set a sapui5 predefined class on view before loading.
		 */
		getContentDensityClass: function () {
			var oThisController = this;
			oThisController.getView().addStyleClass(oThisController.getOwnerComponent().getContentDensityClass());
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getParentModel: function (sName) {
			var oMdl = this.getOwnerComponent().getModel(sName);
			if (!oMdl) {
				oMdl = new JSONModel({});
				this.setParentModel(oMdl, sName);
			}
			return oMdl;
		},

		openBusyDialog: function () {
			if (this._BusyDialog) {
				this._BusyDialog.open();
			} else {
				this._BusyDialog = new sap.m.BusyDialog({
					busyIndicatorDelay: 0
				});
				this._BusyDialog.open();
			}
		},

		closeBusyDialog: function () {
			if (this._BusyDialog) {
				this._BusyDialog.close();
			}
		},

		/**
		 * @purpose Message from Resource Bundle 
		 * @param1 pMessage -- String-Property of Resource Bundle
		 * @param2 aParametrs -- Array-Parameters
		 */
		getMessage: function (pMessage, aParametrs) {
			// read msg from i18n model
			var sMsg = "";
			var oMdlI18n = this.getOwnerComponent().getModel("i18n");
			if (oMdlI18n) {
				this._oBundle = oMdlI18n.getResourceBundle();
			} else {
				this._oBundle = null;
				return sMsg;
			}

			if (aParametrs && aParametrs.length) {
				sMsg = this._oBundle.getText(pMessage, aParametrs);
			} else {
				sMsg = this._oBundle.getText(pMessage);
			}

			return sMsg;
		},
		showMessage: function (pMessage, pMsgTyp, pHandler) {

			if (pMessage.trim().length === 0) {
				return;
			}

			if (["A", "E", "I", "W"].indexOf(pMsgTyp) === -1) {
				sap.m.MessageToast.show(pMessage);
			} else {
				var sIcon = "";
				var sTitle = "";

				switch (pMsgTyp) {
				case 'W':
					sIcon = "WARNING";
					sTitle = "Warning";

					break;
				case 'E':
					sIcon = "ERROR";
					sTitle = "Error";

					break;
				case 'I':
					sIcon = "INFORMATION";
					sTitle = "Information";
					break;
				case 'A':
					sIcon = "NONE";
					break;
				default:
				}
				MessageBox.show(pMessage, {
					icon: sIcon,
					title: sTitle,
					onClose: pHandler,
					styleClass: "sapUiSizeCompact"
				});
			}
		},
		/**
		 * Convenience method to access the business rule services for value help.
		 * @public
		 * @param 
		 * @returns Open value help dialog based on the custom data defined on the input fields.
		 */
		onValueHelpRequested: function (oEvent) {
			var sInputField = oEvent.getSource().data().inputCustomData;
			var oMdlCommon;
			var aCols;
			var oThisController = this;

			switch (sInputField) {
			case "CashManagementGroup":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oCashManagementGroup.cols;
				var oCashManagementGroupPayload = {
					"RuleServiceId": "c9239a7851734a9dad1ded0328f05ffc",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
				     Calling business rule service by passing param sInputField.  */
				this.onCallBusinessRule(aCols, sInputField, oCashManagementGroupPayload);
				break;

			case "DunnProcedure":
				oMdlCommon = this.getParentModel("mCommon");

				aCols = oMdlCommon.getData().oDunnProcedure.cols;
				var oDunnProcedurePayload = {

					"RuleServiceId": "f48ce046fe8440b09329e48373850813",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
			     Calling business rule service by passing param sInputField.  */

				this.onCallBusinessRule(aCols, sInputField, oDunnProcedurePayload);
				break;

			case "GroupingKey":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oGroupingKey.cols;
				var oGroupingKeyPayload = {

					"RuleServiceId": "eae8d68e0f9e4739b0540c03e3feadb9",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
			     Calling business rule service by passing param sInputField.  */

				this.onCallBusinessRule(aCols, sInputField, oGroupingKeyPayload);

				break;

			case "Prepayment":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oPrepayment.cols;
				var oPrepaymentPayload = {
					"RuleServiceId": "98b50a725d674b8080004c624e2c43b8",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
			     Calling business rule service by passing param sInputField.  */

				this.onCallBusinessRule(aCols, sInputField, oPrepaymentPayload);
				break;

			case "DunnRecipient":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oDunnRecipient.cols;
				var oDunnRecipientPayload = {
					"RuleServiceId": "2bf03928ec30470b938416da727bafbc",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
			     Calling business rule service by passing param sInputField.  */

				this.onCallBusinessRule(aCols, sInputField, oDunnRecipientPayload);
				break;

			case "ReleaseGroup":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oReleaseGroup.cols;
				var oReleaseGroupPayload = {
					"RuleServiceId": "ec683d1a0fee45e9b6b2fa7d5f76021e",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
			     Calling business rule service by passing param sInputField.  */

				this.onCallBusinessRule(aCols, sInputField, oReleaseGroupPayload);
				break;

			case "ExemptionAuthority":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oExemptionAuthority.cols;
				var oExemptionAuthorityPayload = {
					"RuleServiceId": "e419bb9e666d41b2b44a43e02334d0dc",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
			     Calling business rule service by passing param sInputField.  */

				this.onCallBusinessRule(aCols, sInputField, oExemptionAuthorityPayload);
				break;

			case "PaymentBlock":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oPaymentBlock.cols;
				var oPaymentBlockPayload = {
					"RuleServiceId": "a464f6c7bd0c4f7782577ffb638bbef7",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};
				/*   @Param sInputField a custom Data set on xml input field.
			     Calling business rule service by passing param sInputField.  */

				this.onCallBusinessRule(aCols, sInputField, oPaymentBlockPayload);

				break;

			case "DunningBlock":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oDunningBlock.cols;
				var oDunningBlockPayload = {
					"RuleServiceId": "1599d993a5554423902fdca122c9d4fa",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oDunningBlockPayload);

				break;

			case "AccountingClerk":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oAccountingClerk.cols;
				var oAccountingClerkPayload = {
					"RuleServiceId": "7289d443ec184b0daca793e71bc22e49",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oAccountingClerkPayload);
				break;

			case "Reconciliation":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oReconciliation.cols;
				var oReconciliationPayload = {
					"RuleServiceId": "0d75837e14b6449095804487056f522d",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oReconciliationPayload);
				break;

			case "CompanyCode":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oCompanyCode.cols;
				var oCompanyCodePayload = {
					"RuleServiceId": "458ccbd75cf04994b4290396012fb416",
					"Vocabulary": [{
						"CompanyCodeInput": {
							"CompanyCode": ""
						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oCompanyCodePayload);
				break;

			case "ToleranceGroup":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oToleranceGroup.cols;

				var sCompanyCode = oMdlCommon.getProperty("/oAccountingVendor/sCompanyCode");

				if (sCompanyCode) {
					var oToleranceGroupPayload = {
						"RuleServiceId": "974920ad91d04c349f6f0daf983c445a",
						"Vocabulary": [{
							"ToleranceGroupInput": {
								"CompanyCode": sCompanyCode
							}
						}]
					};
					/*   @Param sInputField a custom Data set on xml input field.
					     Calling business rule service by passing param sInputField.  */
					this.onCallBusinessRule(aCols, sInputField, oToleranceGroupPayload);
				} else {

					oThisController.showMessage(oThisController.getMessage("PRESELECT_COMPANYCODE"), "W");
				}

				break;

			case "DunningDataGroupingKey":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oDunningDataGroupingKey.cols;
				var oDunningDataGroupingKeyPayload = {
					"RuleServiceId": "5a3345d68caa455094f89baac8212dc4",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oDunningDataGroupingKeyPayload);
				break;

			case "PaymentTerms":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oPaymentTerms.cols;
				var oPaymentTermsPayload = {
					"RuleServiceId": "9778e20d763248b19403ad00dbea138c",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oPaymentTermsPayload);
				break;

				//  ###################   Passing HardCodded Value of country ckey
			case "WithholdingTaxCode":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oWithholdingTaxCode.cols;
				var oWithholdingTaxCodePayload = {
					"RuleServiceId": "46e77b1cc9444e5b83cc4c6b47ee9963",
					"Vocabulary": [{
						"WithholdingTaxCodeInput": {
							"WithholdingTaxCountryKey": "AU"

						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oWithholdingTaxCodePayload);
				break;

			case "InterestCycle":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oInterestCycle.cols;
				var oInterestCyclePayload = {
					"RuleServiceId": "c61ec515298742eea48222afd68f460f",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oInterestCyclePayload);
				break;
			case "InvoiceToleranceGroup":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oInvoiceToleranceGroup.cols;
				sCompanyCode = oMdlCommon.getProperty("/oAccountingVendor/sCompanyCode");
				if (sCompanyCode) {
					var oInvoiceToleranceGroupayload = {
						"RuleServiceId": "223763e6625e4a0c8e764350bbcc03e9",
						"Vocabulary": [{
							"ToleranceGroupInvInput": {
								"CompanyCode": sCompanyCode

							}
						}]
					};

					this.onCallBusinessRule(aCols, sInputField, oInvoiceToleranceGroupayload);
				} else {

					oThisController.showMessage(oThisController.getMessage("PRESELECT_COMPANYCODE"), "W");
				}
				break;

			case "DunningClerk":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oDunningClerk.cols;
				var oDunningClerkPayload = {
					"RuleServiceId": "936f0909d64f45a18017d861c9cd4686",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oDunningClerkPayload);
				break;

			case "PaymentMethods":
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oPaymentMethods.cols;

				var oPaymentMethodspayload = {
					"RuleServiceId": "42eb02a4226447a1b3b201b13f46295f",
					"Vocabulary": [{
						"Input": {
							"Input": ""
						}
					}]
				};

				this.onCallBusinessRule(aCols, sInputField, oPaymentMethodspayload);

				break;

			default:
			}

		},

		/**
		 * Convenience method to call business rule API
		 * @public
		 * @param1  oColumns- All columns in the value help dialog table.
		 * @param2  sInputName- Find the selected input field based on the custom input data.
		 * @param3  oPayLoad-  Payload for calling business rule API
		 * @returns  Table row data.
		 */

		onCallBusinessRule: function (oColumns, sInputName, oPayload) {
			var oThisController = this;

			var oMdlCommon = oThisController.getParentModel("mCommon");
			oThisController.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputName);
			oMdlCommon.setProperty("/" + sInputName, []);
			// First get the CSRF token
			$.ajax({
				url: "/comsapAccountingVendor/bpmrulesruntime/rules-service/v1/rules/xsrf-token",
				method: "GET",
				headers: {
					"X-CSRF-Token": "Fetch"
				},
				success: function (result, xhr, data) {
					var token = data.getResponseHeader("X-CSRF-Token");

					//Then invoke the business rules service via public API
					$.ajax({
						url: "/comsapAccountingVendor/bpmrulesruntime/rules-service/rest/v2/workingset-rule-services",
						method: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload),
						async: false,
						headers: {
							"X-CSRF-Token": token
						},

						success: function (result1, xhr1, data1) {

							var oInputData = "/" + sInputName;
							switch (sInputName) {
							case "CashManagementGroup":
								oMdlCommon.setProperty(oInputData, result1.Result[0].CashManagementGroupList);
								break;
							case "DunnProcedure":
								oMdlCommon.setProperty(oInputData, result1.Result[0].DunningProcedureList);
								break;

							case "GroupingKey":
								oMdlCommon.setProperty(oInputData, result1.Result[0].GroupingKeyList);
								break;
							case "Prepayment":
								oMdlCommon.setProperty(oInputData, result1.Result[0].PrepaymentList);
								break;
							case "DunnRecipient":
								oMdlCommon.setProperty(oInputData, result1.Result[0].DunningRecipientList);
								break;
							case "ReleaseGroup":
								oMdlCommon.setProperty(oInputData, result1.Result[0].ReleaseGroupList);
								break;
							case "ExemptionAuthority":
								oMdlCommon.setProperty(oInputData, result1.Result[0].ExemptionAuthorityList);
								break;
							case "PaymentBlock":
								oMdlCommon.setProperty(oInputData, result1.Result[0].PaymentBlockList);
								break;
							case "DunningBlock":
								oMdlCommon.setProperty(oInputData, result1.Result[0].DunningBlockList);
								break;
							case "AccountingClerk":
								oMdlCommon.setProperty(oInputData, result1.Result[0].AccountingClerkList);
								break;
							case "WithholdingTaxCode":
								oMdlCommon.setProperty(oInputData, result1.Result[0].WithholdingTaxCodeList);
								break;
							case "Reconciliation":
								oMdlCommon.setProperty(oInputData, result1.Result[0].ReconciliationList);
								break;
							case "CompanyCode":
								oMdlCommon.setProperty(oInputData, result1.Result[0].CompanyCodeList);
								break;
							case "ToleranceGroup":

								if (result1.Result.length === 0) {
									var sCompanyCode = oMdlCommon.getProperty("/oAccountingVendor/sCompanyCode");
									var sErrorText = oThisController.getMessage("NO_RESULT_FOUND_COMPANY");
									MessageBox.error(sErrorText + " " + sCompanyCode + ".");
									return;
								} else {
									oMdlCommon.setProperty(oInputData, result1.Result[0].ToleranceGroupList);
								}

								break;

							case "DunningDataGroupingKey":
								oMdlCommon.setProperty(oInputData, result1.Result[0].DunningDataGroupingKeyList);
								break;

							case "PaymentTerms":
								oMdlCommon.setProperty(oInputData, result1.Result[0].PaymentTermsList);
								break;

							case "InterestCycle":
								oMdlCommon.setProperty(oInputData, result1.Result[0].InterestCycleList);
								break;

							case "InvoiceToleranceGroup":

								if (result1.Result.length === 0) {
									sCompanyCode = oMdlCommon.getProperty("/oAccountingVendor/sCompanyCode");
									sErrorText = oThisController.getMessage("NO_RESULT_FOUND_COMPANY");
									MessageBox.error(sErrorText + " " + sCompanyCode + ".");
									return;
								} else {

									oMdlCommon.setProperty(oInputData, result1.Result[0].ToleranceGroupInvList);
								}
								break;

							case "DunningClerk":
								oMdlCommon.setProperty(oInputData, result1.Result[0].DunningClerkList);
								break;

							case "PaymentMethods":

								oMdlCommon.setProperty(oInputData, result1.Result[0].PaymentMethodList);

								break;

							default:
							}

							oThisController.fnCreateFragment(oMdlCommon, oColumns, oInputData);

						},
						error: function (jqXHR, textStatus, errorThrown) {
							oThisController.showMessage(oThisController.getMessage("BUSINESS_RULE_ERROR"), "E");
							//	MessageBox.error("Error occurred while accessing Configure Business Rules.\n Error:" + errorThrown);
						}

					});
				},
				error: function (jqXHR, textStatus, errorThrown) {
					//	oMdlCommon.setProperty("/oError/serviceError", true);
					//	MessageBox.error("Error occurred while fetching access token.\n Error:" + errorThrown);

					oThisController.showMessage(oThisController.getMessage("ACCESS_TOKEN_ERROR"), "E");

				}
			});
		},

		/**
		 * Convenience method to open value help dialog
		 * @public
		 * @param1  oColumns- All columns in the value help dialog table.
		 * @param2  sInputName- Find the selected input field based on the custom input data.
		 * @param3  oMdlCommon-  'mCommon' common data model.
		 * @returns  Open value help dialog.
		 */
		fnCreateFragment: function (oMdlCommon, oColumns, oInputData) {

			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");
			if (sSelectedInput === "CashManagementGroup") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "PlanningGroup");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "PlanningGroup");
				oMdlCommon.setProperty("/oDialog/sTitle", "Cash Management Group");
			}
			if (sSelectedInput === "DunnProcedure") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Procedure");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Name");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Procedure");
				oMdlCommon.setProperty("/oDialog/sTitle", "Dunning Procedure");
			}
			if (sSelectedInput === "GroupingKey") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "GroupingKey");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Text");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "GroupingKey");
				oMdlCommon.setProperty("/oDialog/sTitle", "Grouping Key");
			}

			if (sSelectedInput === "Prepayment") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Prepayment");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Prepayment");
				oMdlCommon.setProperty("/oDialog/sTitle", "Prepayment");
			}
			if (sSelectedInput === "DunnRecipient") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Vendor");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Name1");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Vendor");
				oMdlCommon.setProperty("/oDialog/sTitle", "Dunning Recipient Account Number ");
			}
			if (sSelectedInput === "ReleaseGroup") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "ReleaseGroup");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "ApprovalGroupName");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "ApprovalGroup");
				oMdlCommon.setProperty("/oDialog/sTitle", "Release Group");
			}

			if (sSelectedInput === "ExemptionAuthority") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Exemption Authority");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "ShortDescription");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "ExemptionAuthority");
				oMdlCommon.setProperty("/oDialog/sTitle", "Exemption Authority");
			}
			if (sSelectedInput === "PaymentBlock") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Payment Block");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "BlockIndicator");
				oMdlCommon.setProperty("/oDialog/sTitle", "Payment Block");
			}
			if (sSelectedInput === "DunningBlock") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Dunning Block");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Text");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Block");
				oMdlCommon.setProperty("/oDialog/sTitle", "Dunning Block");
			}

			if (sSelectedInput === "AccountingClerk") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Accounting Clerk");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "NameOfAccountingClerk");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Clerk");
				oMdlCommon.setProperty("/oDialog/sTitle", "Accounting Clerk");
			}

			if (sSelectedInput === "Reconciliation") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Reconciliation");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "GLAccountNumber");
				oMdlCommon.setProperty("/oDialog/sTitle", "GL Reconciliation Account");
			}
			if (sSelectedInput === "CompanyCode") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Company Code");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "CompanyName");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "CompanyCode");
				oMdlCommon.setProperty("/oDialog/sTitle", "Company Code");
			}
			if (sSelectedInput === "ToleranceGroup") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "NameOfToleranceGroup");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "ToleranceGroup");
				oMdlCommon.setProperty("/oDialog/sTitle", "Tolerance Group");
			}
			if (sSelectedInput === "DunningDataGroupingKey") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Text");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "GroupingKey");
				oMdlCommon.setProperty("/oDialog/sTitle", "Grouping Key (DunningData)");
			}
			if (sSelectedInput === "WithholdingTaxCode") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "WithholdingTaxCode");
				oMdlCommon.setProperty("/oDialog/sTitle", "Withholding Tax Code");
			}

			if (sSelectedInput === "PaymentTerms") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "OwnExplanation");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "PaymentTerms");
				oMdlCommon.setProperty("/oDialog/sTitle", "Payment Terms Key");
			}
			if (sSelectedInput === "InterestCycle") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "ShortDescription");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "InterestCycle");
				oMdlCommon.setProperty("/oDialog/sTitle", "Interest Cycle");
			}
			if (sSelectedInput === "InvoiceToleranceGroup") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "ToleranceGroup");
				oMdlCommon.setProperty("/oDialog/sTitle", "Tolerance Group (Invoice)");
			}

			if (sSelectedInput === "DunningClerk") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "NameOfAccountingClerk");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Clerk");
				oMdlCommon.setProperty("/oDialog/sTitle", "Dunning Clerk");
			}

			if (sSelectedInput === "PaymentMethods") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "PaymentMethods");
				oMdlCommon.setProperty("/oDialog/sTitle", "Payment Methods");
			}

			this._oBasicSearchField = new SearchField({
				showSearchButton: false
			});
			this._oValueHelpDialog = sap.ui.xmlfragment("com.sap.AccountingVendor.fragments.BusinessValueHelp", this);
			this.getView().addDependent(this._oValueHelpDialog);

			var oFilterBar = this._oValueHelpDialog.getFilterBar();
			//	oFilterBar.setFilterBarExpanded(false);
			oFilterBar.setBasicSearch(this._oBasicSearchField);

			this._oValueHelpDialog.getTableAsync().then(function (oTable) {
				oTable.setModel(oMdlCommon);

				var oNewModel = new JSONModel();
				oNewModel.setData({
					cols: oColumns
				});
				oTable.setModel(oNewModel, "columns");

				if (oTable.bindRows) {
					oTable.bindAggregation("rows", oInputData);
				}

				if (oTable.bindItems) {

					oTable.bindAggregation("items", oInputData, function () {
						return new ColumnListItem({
							cells: oColumns.map(function (column) {
								return new Label({
									text: "{" + column.template + "}"
								});
							})
						});
					});
				}
				this._oValueHelpDialog.update();
			}.bind(this));

			this._oValueHelpDialog.open();

		},

		/**
		 * Convenience method to select key and description value
		 * @public
		 * @param  oEvent- Get the existing token.
		 * @returns  capture key and description value in token.
		 */

		onValueHelpOkPress: function (oEvent) {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");

			var aTokens = oEvent.getParameter("tokens");
			var text = aTokens[0].getText();
			var key = aTokens[0].getKey();
			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");
			if (sSelectedInput === "CashManagementGroup") {
				oMdlCommon.setProperty("/oAccountingVendor/sCashManagementGroup", key);
				oMdlCommon.setProperty("/oAccountingVendor/sCashManagementGroupKey", text);
			}
			if (sSelectedInput === "DunnProcedure") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunnProcedure", key);
				oMdlCommon.setProperty("/oAccountingVendor/sDunnProcedureKey", text);

			}

			if (sSelectedInput === "GroupingKey") {
				oMdlCommon.setProperty("/oAccountingVendor/sGroupingKey", key);
				oMdlCommon.setProperty("/oAccountingVendor/sGroupingKeyKey", text);
			}

			if (sSelectedInput === "Prepayment") {
				oMdlCommon.setProperty("/oAccountingVendor/sPrepayment", key);
				oMdlCommon.setProperty("/oAccountingVendor/sPrepaymentKey", text);
			}
			if (sSelectedInput === "DunnRecipient") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunnRecipient", key);

				oMdlCommon.setProperty("/oAccountingVendor/sDunnRecipientKey", text);
			}
			if (sSelectedInput === "ReleaseGroup") {
				oMdlCommon.setProperty("/oAccountingVendor/sReleaseGroup", key);
				oMdlCommon.setProperty("/oAccountingVendor/sReleaseGroupKey", text);

			}

			if (sSelectedInput === "ExemptionAuthority") {
				oMdlCommon.setProperty("/oAccountingVendor/sExmptAuthority", key);
				oMdlCommon.setProperty("/oAccountingVendor/sExmptAuthorityKey", text);
			}
			if (sSelectedInput === "PaymentBlock") {
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentBlock", key);

				oMdlCommon.setProperty("/oAccountingVendor/sPaymentBlockKey", text);
			}
			if (sSelectedInput === "DunningBlock") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunningBlock", key);
				oMdlCommon.setProperty("/oAccountingVendor/sDunningBlockKey", text);
			}

			if (sSelectedInput === "AccountingClerk") {
				oMdlCommon.setProperty("/oAccountingVendor/sAcctgClerk", key);

				oMdlCommon.setProperty("/oAccountingVendor/sAcctgClerkKey", text);
			}

			if (sSelectedInput === "WithholdingTaxCode") {
				oMdlCommon.setProperty("/oAccountingVendor/sWTaxCode", key);
				oMdlCommon.setProperty("/oAccountingVendor/sWTaxCodeKey", text);
			}

			if (sSelectedInput === "Reconciliation") {
				var sReconAccountstate = oMdlCommon.getProperty("/sReconAccountstate");
				if (sReconAccountstate === "Error") {
					oMdlCommon.setProperty("/sReconAccountstate", "None");
					oMdlCommon.setProperty("/sReconAccountstateText", "");
				}

				oMdlCommon.setProperty("/oAccountingVendor/sReconAccount", key);
				oMdlCommon.setProperty("/oAccountingVendor/sReconAccountKey", text);
			}
			if (sSelectedInput === "CompanyCode") {

				var sCompanyCodeState = oMdlCommon.getProperty("/sCompanyCodestate");
				if (sCompanyCodeState === "Error") {
					oMdlCommon.setProperty("/sCompanyCodestate", "None");
					oMdlCommon.setProperty("/sCompanyCodestateText", "");
				}
				oMdlCommon.setProperty("/oAccountingVendor/sCompanyCode", key);
				oMdlCommon.setProperty("/oAccountingVendor/sCompanyCodeKey", text);

			}
			if (sSelectedInput === "ToleranceGroup") {
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentDataToleranceGroup", key);
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentDataToleranceGroupKey", text);

			}
			if (sSelectedInput === "DunningDataGroupingKey") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunningDataGroupingKey", key);
				oMdlCommon.setProperty("/oAccountingVendor/sDunningDataGroupingKeyKey", text);

			}
			if (sSelectedInput === "PaymentTerms") {
				oMdlCommon.setProperty("/oAccountingVendor/sPaytTerms", key);
				oMdlCommon.setProperty("/oAccountingVendor/sPaytTermsKey", text);
			}
			if (sSelectedInput === "InterestCycle") {
				oMdlCommon.setProperty("/oAccountingVendor/sInterestCycle", key);
				oMdlCommon.setProperty("/oAccountingVendor/sInterestCycleKey", text);

			}
			if (sSelectedInput === "InvoiceToleranceGroup") {
				oMdlCommon.setProperty("/oAccountingVendor/sToleranceGroup", key);
				oMdlCommon.setProperty("/oAccountingVendor/sToleranceGroupKey", text);
			}
			if (sSelectedInput === "DunningClerk") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunningClerk", key);

				oMdlCommon.setProperty("/oAccountingVendor/sDunningClerkKey", text);
			}

			if (sSelectedInput === "PaymentMethods") {
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentMethods", key);
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentMethodsKey", text);

			}

			this._oValueHelpDialog.close();
		},

		/**
		 * Convenience method to close existing value help dialog.
		 * @public
		 * @returns  Set property 'null' for selected key and description.
		 */
		onValueHelpCancelPress: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");

			if (sSelectedInput === "CashManagementGroup") {
				oMdlCommon.setProperty("/oAccountingVendor/sCashManagementGroup", "");
				oMdlCommon.setProperty("/oAccountingVendor/sCashManagementGroupKey", "");

			}
			if (sSelectedInput === "DunnProcedure") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunnProcedure", "");
				oMdlCommon.setProperty("/oAccountingVendor/sDunnProcedureKey", "");
			}

			if (sSelectedInput === "GroupingKey") {
				oMdlCommon.setProperty("/oAccountingVendor/sGroupingKey", "");
				oMdlCommon.setProperty("/oAccountingVendor/sGroupingKeyKey", "");
			}

			if (sSelectedInput === "Prepayment") {
				oMdlCommon.setProperty("/oAccountingVendor/sPrepayment", "");
				oMdlCommon.setProperty("/oAccountingVendor/sPrepaymentKey", "");
			}
			if (sSelectedInput === "DunnRecipient") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunnRecipient", "");
				oMdlCommon.setProperty("/oAccountingVendor/sDunnRecipientKey", "");
			}
			if (sSelectedInput === "ReleaseGroup") {
				oMdlCommon.setProperty("/oAccountingVendor/sReleaseGroup", "");
				oMdlCommon.setProperty("/oAccountingVendor/sReleaseGroupKey", "");

			}

			if (sSelectedInput === "ExemptionAuthority") {
				oMdlCommon.setProperty("/oAccountingVendor/sExmptAuthority", "");
				oMdlCommon.setProperty("/oAccountingVendor/sExmptAuthorityKey", "");
			}
			if (sSelectedInput === "PaymentBlock") {
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentBlock", "");
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentBlockKey", "");
			}

			if (sSelectedInput === "DunningBlock") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunningBlock", "");
				oMdlCommon.setProperty("/oAccountingVendor/sDunningBlockKey", "");
			}

			if (sSelectedInput === "AccountingClerk") {
				oMdlCommon.setProperty("/oAccountingVendor/sAcctgClerk", "");
				oMdlCommon.setProperty("/oAccountingVendor/sAcctgClerkKey", "");
			}
			if (sSelectedInput === "WithholdingTaxCode") {
				oMdlCommon.setProperty("/oAccountingVendor/sWTaxCode", "");
				oMdlCommon.setProperty("/oAccountingVendor/sWTaxCodeKey", "");

			}
			if (sSelectedInput === "Reconciliation") {
				oMdlCommon.setProperty("/oAccountingVendor/sReconAccount", "");
				oMdlCommon.setProperty("/oAccountingVendor/sReconAccountKey", "");

			}

			if (sSelectedInput === "CompanyCode") {

				var sCompanyCodeState = oMdlCommon.getProperty("/sCompanyCodestate");
				if (sCompanyCodeState === "Error") {
					oMdlCommon.setProperty("/sCompanyCodestate", "None");
					oMdlCommon.setProperty("/sCompanyCodestateText", "");
				}
				oMdlCommon.setProperty("/oAccountingVendor/sCompanyCode", "");
				oMdlCommon.setProperty("/oAccountingVendor/sCompanyCodeKey", "");
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentDataToleranceGroup", "");
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentDataToleranceGroupKey", "");
				oMdlCommon.setProperty("/oAccountingVendor/sToleranceGroup", "");
				oMdlCommon.setProperty("/oAccountingVendor/sToleranceGroupKey", "");

			}

			if (sSelectedInput === "ToleranceGroup") {
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentDataToleranceGroup", "");
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentDataToleranceGroupKey", "");
			}

			if (sSelectedInput === "DunningDataGroupingKey") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunningDataGroupingKey", "");
				oMdlCommon.setProperty("/oAccountingVendor/sDunningDataGroupingKeyKey", "");
			}
			if (sSelectedInput === "PaymentTerms") {
				oMdlCommon.setProperty("/oAccountingVendor/sPaytTerms", "");
				oMdlCommon.setProperty("/oAccountingVendor/sPaytTermsKey", "");
			}
			if (sSelectedInput === "InterestCycle") {
				oMdlCommon.setProperty("/oAccountingVendor/sInterestCycle", "");
				oMdlCommon.setProperty("/oAccountingVendor/sInterestCycleKey", "");

			}
			if (sSelectedInput === "InvoiceToleranceGroup") {
				oMdlCommon.setProperty("/oAccountingVendor/sToleranceGroup", "");
				oMdlCommon.setProperty("/oAccountingVendor/sToleranceGroupKey", "");
			}
			if (sSelectedInput === "DunningClerk") {
				oMdlCommon.setProperty("/oAccountingVendor/sDunningClerk", "");
				oMdlCommon.setProperty("/oAccountingVendor/sDunningClerkKey", "");
			}
			if (sSelectedInput === "PaymentMethods") {
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentMethods", "");
				oMdlCommon.setProperty("/oAccountingVendor/sPaymentMethodsKey", "");
			}

			this._oValueHelpDialog.close();
			oMdlCommon.refresh();
		},
		/**
		 * Convenience method to filter table data.
		 * @public
		 * @param  oEvent- Get Property 'selectionSet'
		 * @returns  Filter table data based on given values.
		 */
		onFilterBarSearch: function (oEvent) {

			var oMdlCommon = this.getParentModel("mCommon"),
				sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");
			var sSearchQuery = this._oBasicSearchField.getValue(),
				aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getValue()) {

					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			switch (sSelectedInput) {
			case "CashManagementGroup":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "PlanningGroup",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "ShortText",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "DunnProcedure":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "Procedure",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Name",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "GroupingKey":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "GroupingKey",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Text",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "Prepayment":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "Prepayment",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "DunnRecipient":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "DunnRecipient",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Country",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "City",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}), new Filter({
							path: "Vendor",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "SearchTerm",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Name1",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "ReleaseGroup":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "ApprovalGroup",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "ApprovalGroupName",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "ExemptionAuthority":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "ExemptionAuthority",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "ShortDescription",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;
			case "PaymentBlock":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "BlockIndicator",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "DunningBlock":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "Block",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Text",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "AccountingClerk":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "NameOfAccountingClerk",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CompanyCode",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Clerk",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;

			case "Reconciliation":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "GLAccountNumber",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;
			case "CompanyCode":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "CompanyName",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "City",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CompanyCode",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Currency",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
				break;
			case "ToleranceGroup":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "ToleranceGroup",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "NameOfToleranceGroup",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;
			case "DunningDataGroupingKey":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "GroupingKey",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Text",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;
			case "WithholdingTaxCode":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "WithholdingTaxCode",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "PaymentTerms":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "OwnExplanation",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "PaymentTerms",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "InterestCycle":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "InterestCycle",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "ShortDescription",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;
			case "InvoiceToleranceGroup":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "ToleranceGroup",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "DunningClerk":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "NameOfAccountingClerk",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CompanyCode",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Clerk",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			case "PaymentMethods":
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "IsIncomingOrOutgoing",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CountryKey",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "PaymentMethods",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
				break;

			default:
			}

			this._filterTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterTable: function (oFilter) {
			var oValueHelpDialog = this._oValueHelpDialog;

			oValueHelpDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				oValueHelpDialog.update();
			});
		},
		/**
		 * Convenience method to destroy the existing value help dialog.
		 * @public
		 * @returns  Destroy the value help dialog and set property 'null'
		 */
		onValueHelpAfterClose: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			if (this._oValueHelpDialog) {
				this._oValueHelpDialog.destroy();
				this._oValueHelpDialog = null; // make it falsy so that it can be created next time
			}
			oMdlCommon.refresh();

		},
		/**
		 * Convenience method to change the 'valueState' & 'valueStateText' property of inputs.
		 * @public
		 * @param  oEvent- Get property 'valueState'
		 * @returns set 'valueState' & 'valueStateText' property of an input.
		 */
		onLiveChange: function (oEvent) {

			var errorExist = oEvent.getSource().getProperty("valueState");
			if (errorExist === "Error") {

				oEvent.getSource().setProperty("valueState", "None");
				oEvent.getSource().setProperty("valueStateText", "");

			}
		}

	});
});