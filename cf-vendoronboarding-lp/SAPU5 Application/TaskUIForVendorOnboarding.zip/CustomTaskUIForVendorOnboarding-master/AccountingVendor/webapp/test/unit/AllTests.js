sap.ui.define([
	"com/sap/AccountingVendor/test/unit/controller/App.controller"
], function () {
	"use strict";
});