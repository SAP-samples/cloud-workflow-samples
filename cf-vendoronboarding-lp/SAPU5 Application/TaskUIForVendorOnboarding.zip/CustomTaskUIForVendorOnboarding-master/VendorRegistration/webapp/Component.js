sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/sap/VendorRegistration/model/models",
	"sap/m/MessageBox"
], function (UIComponent, Device, models, MessageBox) {
	"use strict";

	return UIComponent.extend("com.sap.VendorRegistration.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			// get task data
			var startupParameters = this
				.getComponentData().startupParameters;
			var taskModel = startupParameters.taskModel;
			var taskData = taskModel.getData();
			var taskId = taskData.InstanceID;

			// read process context & bind it to
			// the view's model
			var that = this;
			var contextModel = new sap.ui.model.json.JSONModel(
				"/comsapVendorRegistration/workflowruntime/v1/task-instances/" + taskId + "/context");

			var contextData = contextModel
				.getData();

			this.setModel(contextModel, "oModel");

			contextModel
				.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.setModel(contextModel);

			// Implementation for the confirm
			// action
			// Implementation for the confirm
			// action
			var oPositiveAction = {
				sBtnTxt: "Submit",
				onBtnPressed: function () {
					var model = that.getModel();
					model.refresh(true);
					var processContext = model
						.getData();
					// Get the equipment list as
					// a JSON string

					// Call a local method to
					// perform further action
					that
						._triggerComplete(
							processContext,
							that.oComponentData.inboxHandle.attachmentHandle.detailModel
							.getData().InstanceID,
							true,
							jQuery
							.proxy(
								// Call
								// a
								// local
								// method
								// to
								// refresh
								// the
								// task
								// list
								// in
								// My
								// Inbox
								that._refreshTask,
								that));
				}
			};

			// Add 'Confirm' action to the task
			startupParameters.inboxAPI
				.addAction({
						// confirm is a
						// positive
						// action
						action: oPositiveAction.sBtnTxt,
						label: oPositiveAction.sBtnTxt,
						type: "Accept"
							// Set the onClick
							// function
					},
					oPositiveAction.onBtnPressed);

		},

		// This method is called when the
		// confirm button is click by the end
		// user
		/*	_accessBusinessRuleApi: function () {
			
				var mCommon = this.getModel('mCommon');
		},  */

		_triggerComplete: function (processContext,
			taskId, approvalStatus,
			refreshTask) {

			var mCommon = this.getModel("mCommon");
			var that = this;
			var bError = mCommon.getProperty("/bError");
			that._BusyDialog = new sap.m.BusyDialog({
				busyIndicatorDelay: 0
			});

			that._BusyDialog.open();

			var oMandatoryFields = [
				"sLanguage",
				"sCity",
				"sCountry"
			];
			var requesterValue;
			for (var i = 0; i < oMandatoryFields.length; i++) {
				requesterValue = mCommon.getProperty("/" + "oBasicDetails" + "/" + oMandatoryFields[i]);
				if (requesterValue && requesterValue.trim() && requesterValue !== "" && requesterValue !== "undefined" && requesterValue !==
					"null") {
					mCommon.setProperty("/" + "oBasicDetails" + "/" + oMandatoryFields[i] + "state", "None");

				} else {
					mCommon.setProperty("/bError", true);
					if (oMandatoryFields[i] === "sLanguage") {

						mCommon.setProperty("/" + oMandatoryFields[i] + "stateText", "Language is a required field (*)");
					}
					if (oMandatoryFields[i] === "sCity") {

						mCommon.setProperty("/" + oMandatoryFields[i] + "stateText", "City is a required field (*)");
					}
					if (oMandatoryFields[i] === "sCountry") {

						mCommon.setProperty("/" + oMandatoryFields[i] + "stateText", "Country is a required field (*)");
					}
					mCommon.setProperty("/" + oMandatoryFields[i] + "state", "Error");
				}

			}
			bError = mCommon.getProperty("/bError");
			if (bError) {

				mCommon.setProperty("/bError", false);
				MessageBox.error("A validation error has occured. Complete your input first");
				that._BusyDialog.close();
			} else {

				var a1 = $.ajax({
						url: "/comsapVendorRegistration/bpmrulesruntime/rules-service/v1/rules/xsrf-token",
						method: "GET",
						headers: {
							"X-CSRF-Token": "Fetch"
						},
						success: function (result, xhr, data) {

							var token = data.getResponseHeader("X-CSRF-Token");
							var sAccountGroup = mCommon.getProperty("/oBasicDetails/sAccountGroup");
							var sVendorType = mCommon.getProperty("/oBasicDetails/sVendorType");
							var sCountry = mCommon.getProperty("/oBasicDetails/sCountry");

							var oPayload = {
								"RuleServiceId": "b65b33f90a6b475d9f60bccc282e3a12",
								"RuleServiceRevision": "2006",
								"Vocabulary": [{
									"ValidationInput": {
										"VendorType": sVendorType,
										"AccountGroup": sAccountGroup,
										"CountryKey": sCountry
									}
								}]
							};
							//Then invoke the business rules service via public API
							$.ajax({
								url: "/comsapVendorRegistration/bpmrulesruntime/rules-service/rest/v2/rule-services",
								method: "POST",
								contentType: "application/json",
								data: JSON.stringify(oPayload),
								async: false,
								headers: {
									"X-CSRF-Token": token
								},

								success: function (result1, xhr1, data1) {
									that._BusyDialog.close();
									var oResultData = result1.Result[0].AdditionalValidationList;

									for (var i = 0; i < oResultData.length; i++) {

										var sFieldId = oResultData[i].FieldID;
										switch (sFieldId) {
										case "IdPostalCode":

											var sZipCode = mCommon.getProperty("/oBasicDetails/sZipCode");
											if (!sZipCode) {
												mCommon.setProperty("/bError", true);
												var sErrorDes = oResultData[i].Message;
												mCommon.setProperty("/sZipCodestate", "Error");
												mCommon.setProperty("/sZipCodestateText", sErrorDes);
											}
											break;
										case "IdTaxJurisdiction":

											var sTaxJur = mCommon.getProperty("/oBasicDetails/sTaxJur");
											if (!sTaxJur) {
												mCommon.setProperty("/bError", true);
												sErrorDes = oResultData[i].Message;
												mCommon.setProperty("/sTaxJurstate", "Error");
												mCommon.setProperty("/sTaxJurstateText", sErrorDes);
											}
											break;
										case "IdCustomer":

											var sCustomer = mCommon.getProperty("/oBasicDetails/sCustomer");
											if (!sCustomer) {
												mCommon.setProperty("/bError", true);
												sErrorDes = oResultData[i].Message;
												mCommon.setProperty("/sCustomerstate", "Error");
												mCommon.setProperty("/sCustomerstateText", sErrorDes);
											}
											break;
										case "IdVATregistrationNumber":

											var sVATRegNo = mCommon.getProperty("/oBasicDetails/sVATRegNo");
											if (!sVATRegNo) {
												mCommon.setProperty("/bError", true);
												sErrorDes = oResultData[i].Message;
												mCommon.setProperty("/sVATRegNostate", "Error");
												mCommon.setProperty("/sVATRegNostateText", sErrorDes);
											}
											break;

										case "IdAlternativePayeeAccountNumber":

											var sAlternativePayee = mCommon.getProperty("/oBasicDetails/sAlternativePayee");
											if (!sAlternativePayee) {
												mCommon.setProperty("/bError", true);
												sErrorDes = oResultData[i].Message;
												mCommon.setProperty("/sAlternativePayeestate", "Error");
												mCommon.setProperty("/sAlternativePayeestateText", sErrorDes);
											}
											break;

										default:
										}

									}

								},
								error: function (jqXHR, textStatus, errorThrown) {

									that._BusyDialog.close();

								}
							});
						},
						error: function (jqXHR, textStatus, errorThrown) {

							that._BusyDialog.close();

						}
					}),

					a2 = a1.then(function () {

						bError = mCommon.getProperty("/bError");
						if (bError) {

							mCommon.setProperty("/bError", false);
							MessageBox.error("A validation error has occured. Complete your input first");
							that._BusyDialog.close();
						} else {

							$.ajax({
								// Call workflow API to
								// get the xsrf token
								url: "/comsapVendorRegistration/workflowruntime/v1/xsrf-token",
								method: "GET",
								headers: {
									"X-CSRF-Token": "Fetch"
								},
								success: function (
									result, xhr,
									data) {

									// After retrieving
									// the xsrf token
									// successfully
									var token = data
										.getResponseHeader("X-CSRF-Token");
									var oBasicData;
									// form the
									// context that
									// will be
									// updated -
									// approval
									// status and
									// the equipment
									// list

									oBasicData = {

										context: {
											"sVendorType": mCommon.getProperty("/oBasicDetails/sVendorType"),
											"sAccountGroup": mCommon.getProperty("/oBasicDetails/sAccountGroup"),
											"sTitle": mCommon.getProperty("/oBasicDetails/sTitle"),

											"sVendorName": mCommon.getProperty("/oBasicDetails/sVendorName"),
											"sVendorName2": mCommon.getProperty("/oBasicDetails/sVendorName2"),
											"sVendorName3": mCommon.getProperty("/oBasicDetails/sVendorName3"),
											"sVendorName4": mCommon.getProperty("/oBasicDetails/sVendorName4"),
											"sSearchTerms": mCommon.getProperty("/oBasicDetails/sSearchTerms"),

											"sLanguage": mCommon.getProperty("/oBasicDetails/sLanguage"),
											"sLanguageKey": mCommon.getProperty("/oBasicDetails/sLanguageKey"),
											"sStreet1": mCommon.getProperty("/oBasicDetails/sStreet1"),
											"sHouseNumber": mCommon.getProperty("/oBasicDetails/sHouseNumber"),

											"sZipCode": mCommon.getProperty("/oBasicDetails/sZipCode"),
											"sCity": mCommon.getProperty("/oBasicDetails/sCity"),
											"sCountry": mCommon.getProperty("/oBasicDetails/sCountry"),
											"sCountryKey": mCommon.getProperty("/oBasicDetails/sCountryKey"),
											"sRegion": mCommon.getProperty("/oBasicDetails/sRegion"),
											"sRegionKey": mCommon.getProperty("/oBasicDetails/sRegionKey"),
											"sTaxJur": mCommon.getProperty("/oBasicDetails/sTaxJur"),
											"sSuppl": mCommon.getProperty("/oBasicDetails/sSuppl"),
											"sDistrict": mCommon.getProperty("/oBasicDetails/sDistrict"),

											"sPOBox": mCommon.getProperty("/oBasicDetails/sPOBox"),
											"sPostalCode": mCommon.getProperty("/oBasicDetails/sPostalCode"),
											"sOtherCountry": mCommon.getProperty("/oBasicDetails/sOtherCountry"),
											"sOtherCity": mCommon.getProperty("/oBasicDetails/sOtherCity"),
											"sVendorEmail": mCommon.getProperty("/oBasicDetails/sVendorEmail"),
											"sVendorContact": mCommon.getProperty("/oBasicDetails/sVendorContact"),
											"sSubsidiary": mCommon.getProperty("/oBasicDetails/sSubsidiary"),
											"sFax": mCommon.getProperty("/oBasicDetails/sFax"),

											"sCustomer": mCommon.getProperty("/oBasicDetails/sCustomer"),
											"sCustomerKey": mCommon.getProperty("/oBasicDetails/sCustomerKey"),

											"sAuthorization": mCommon.getProperty("/oBasicDetails/sAuthorization"),
											"sTradingPartner": mCommon.getProperty("/oBasicDetails/sTradingPartner"),
											"sTradingPartnerKey": mCommon.getProperty("/oBasicDetails/sTradingPartnerKey"),

											"sCorporateGroup": mCommon.getProperty("/oBasicDetails/sCorporateGroup"),
											"sTaxOffice": mCommon.getProperty("/oBasicDetails/sTaxOffice"),

											"sFiscalAddress": mCommon.getProperty("/oBasicDetails/sFiscalAddress"),
											"sTaxType": mCommon.getProperty("/oBasicDetails/sTaxType"),

											"sRepName": mCommon.getProperty("/oBasicDetails/sRepName"),

											"sVATRegNo": mCommon.getProperty("/oBasicDetails/sVATRegNo"),
											"sTypeOfIndustry": mCommon.getProperty("/oBasicDetails/sTypeOfIndustry"),
											"sTaxBase": mCommon.getProperty("/oBasicDetails/sTaxBase"),

											"sTaxNumber": mCommon.getProperty("/oBasicDetails/sTaxNumber"),
											"sSocInsCode": mCommon.getProperty("/oBasicDetails/sSocInsCode"),
											"sTypeOfBusiness": mCommon.getProperty("/oBasicDetails/sTypeOfBusiness"),
											"sTaxNumberType": mCommon.getProperty("/oBasicDetails/sTaxNumberType"),

											"sTaxNumber1": mCommon.getProperty("/oBasicDetails/sTaxNumber1"),
											"sTaxNumber2": mCommon.getProperty("/oBasicDetails/sTaxNumber2"),

											"sLocationNumber": mCommon.getProperty("/oBasicDetails/sLocationNumber"),
											"sLocationNumber2": mCommon.getProperty("/oBasicDetails/sLocationNumber2"),
											"sCarFreightGroup": mCommon.getProperty("/oBasicDetails/sCarFreightGroup"),
											"sServAgntProcGrp": mCommon.getProperty("/oBasicDetails/sServAgntProcGrp"),
											"sStatGrService": mCommon.getProperty("/oBasicDetails/sStatGrService"),
											"sPODRelevant": mCommon.getProperty("/oBasicDetails/sPODRelevant"),
											"sActualQMSys": mCommon.getProperty("/oBasicDetails/sActualQMSys"),
											"sTransportZone": mCommon.getProperty("/oBasicDetails/sTransportZone"),

											"sCheckDigit": mCommon.getProperty("/oBasicDetails/sCheckDigit"),
											"sCredInfoNo": mCommon.getProperty("/oBasicDetails/sCredInfoNo"),
											"sSCAC": mCommon.getProperty("/oBasicDetails/sSCAC"),
											"sQMSystemTo": mCommon.getProperty("/oBasicDetails/sQMSystemTo"),
											"sLastExtReview": mCommon.getProperty("/oBasicDetails/sLastExtReview"),
											"sIndustry": mCommon.getProperty("/oBasicDetails/sIndustry"),
											"sTrainStation": mCommon.getProperty("/oBasicDetails/sTrainStation"),

											"sDateOfBirth": mCommon.getProperty("/oBasicDetails/sDateOfBirth"),
											"sPlaceOfBirth": mCommon.getProperty("/oBasicDetails/sPlaceOfBirth"),
											"sGender": mCommon.getProperty("/oBasicDetails/sGender"),
											"sProfession": mCommon.getProperty("/oBasicDetails/sProfession"),

											"aAddBankDetails": mCommon.getProperty("/oBasicDetails/aAddBankDetails"),

											"sAlternativePayee": mCommon.getProperty("/oBasicDetails/sAlternativePayee"),

											"sDMEIndicator": mCommon.getProperty("/oBasicDetails/sDMEIndicator"),
											"sDMEIndicatorKey": mCommon.getProperty("/oBasicDetails/sDMEIndicatorKey"),

											"sInstructionKey": mCommon.getProperty("/oBasicDetails/sInstructionKey"),
											"sInstructionKeyKey": mCommon.getProperty("/oBasicDetails/sInstructionKeyKey"),

											"sISRNumber": mCommon.getProperty("/oBasicDetails/sISRNumber"),

											"aAddContactPersons": mCommon.getProperty("/oBasicDetails/aAddContactPersons")

										},
										"status": "COMPLETED"
											/**	,
												"status": "InProgress",
												"subject": "string",
												"description": "string",
												"recipientUsers": "string",
												"recipientGroups": "string",
												"processor": "string",
												"dueDate": "2020-06-08T06:01:51.243Z",
												"priority": "VERY_HIGH" **/
									};
									var iTimeoutId = setTimeout(function () {
										that._BusyDialog.close();
									}.bind(this), 5000);
									$.ajax({
										// Call
										// workflow
										// API
										// to
										// complete
										// the
										// task
										url: "/comsapVendorRegistration/workflowruntime/v1/task-instances/" + taskId,
										method: "PATCH",
										contentType: "application/json",
										// pass
										// the
										// updated
										// context
										// to
										// the
										// API
										data: JSON.stringify(oBasicData),
										headers: {
											// pass
											// the
											// xsrf
											// token
											// retrieved
											// earlier
											"X-CSRF-Token": token
										},
										// refreshTask
										// needs
										// to
										// be
										// called
										// on
										// successful
										// completion
										success: refreshTask

									});

								}

							});

						}
					});

			}

		},

		// Request Inbox to refresh the control
		// once the task is completed
		_refreshTask: function () {

			var taskId = this
				.getComponentData().startupParameters.taskModel
				.getData().InstanceID;
			this.getComponentData().startupParameters.inboxAPI
				.updateTask("NA", taskId);

		},

		getContentDensityClass: function () {
			if (!this._sContentDensityClass) {
				if (!sap.ui.Device.support.touch) {
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		}

	});
});