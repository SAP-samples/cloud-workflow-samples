sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/m/Label",
	"sap/m/ColumnListItem",
	"sap/m/SearchField",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, MessageBox, Token, Label, ColumnListItem, SearchField, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.sap.VendorRegistration.controller.App", {
		onInit: function () {
			var oThisController = this,
				oMdlCommon = oThisController.getParentModel("mCommon"),
				sRootPath = jQuery.sap.getModulePath("com.sap.VendorRegistration");
			oMdlCommon.attachRequestCompleted(function (oEvent) {
				oMdlCommon.refresh();
			});
			oMdlCommon.loadData(sRootPath + "/model/Property.json", null, false);

			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		},

		/**
		 * Convenience method fo setting the context data on common model.
		 * @public
		 * @param 
		 * @returns Read context data to be displayed in UI input fields.
		 */
		onAfterRendering: function () {

			var oComponent = this.getOwnerComponent();
			var oTaskModel = oComponent.getModel("oModel");
			var oThisController = this,
				oMdlCommon = oThisController.getParentModel("mCommon");

			var sTaskVendorFName = oTaskModel.getData().sVendorFName;
			var sTaskVendorLName = oTaskModel.getData().sVendorLName;
			var sTaskVendorName = sTaskVendorFName + " " + sTaskVendorLName;
			var sTaskVendorType = oTaskModel.getData().sVendorType;
			var sTaskVendorContact = oTaskModel.getData().sVendorContactNumber;
			var sTaskVendorEmail = oTaskModel.getData().sVendorEmail;
			var sTaskAccountGroup = oTaskModel.getData().sAccountGroup;

			oMdlCommon.setProperty("/oBasicDetails/sVendorType", sTaskVendorType);
			oMdlCommon.setProperty("/oBasicDetails/sVendorName", sTaskVendorName);
			oMdlCommon.setProperty("/oBasicDetails/sVendorEmail", sTaskVendorEmail);

			oMdlCommon.setProperty("/oBasicDetails/sVendorContact", sTaskVendorContact);
			oMdlCommon.setProperty("/oBasicDetails/sAccountGroup", sTaskAccountGroup);

		},

		openBusyDialog: function () {
			if (this._BusyDialog) {
				this._BusyDialog.open();
			} else {
				this._BusyDialog = new sap.m.BusyDialog({
					busyIndicatorDelay: 0
				});
				this._BusyDialog.open();
			}
		},

		closeBusyDialog: function () {
			if (this._BusyDialog) {
				this._BusyDialog.close();
			}
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */

		getParentModel: function (sName) {
			var oMdl = this.getOwnerComponent().getModel(sName);
			oMdl.setSizeLimit(100000);
			if (!oMdl) {
				oMdl = new JSONModel({});
				this.setParentModel(oMdl, sName);
			}
			return oMdl;
		},

		onTitleSelect: function (oEvent) {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");

			var sSelectedItem = oEvent.getSource().getSelectedItem().getText();
			oMdlCommon.setProperty("/oBasicDetails/sTitle", sSelectedItem);
		},

		onFormOfAddressSelect: function (oEvent) {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");

			var sSelectedItem = oEvent.getSource().getSelectedItem().getText();
			var bindingContext = oEvent.getSource().getBindingContext("mCommon");

			oThisController.sSelectedObject = bindingContext.getObject();
			oThisController.sSelectedObject.sFormOfAddress = sSelectedItem;

		},

		onGenderSelect: function (oEvent) {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");

			var sSelectedItem = oEvent.getSource().getSelectedItem().getText();
			oMdlCommon.setProperty("/oBasicDetails/sGender", sSelectedItem);

		},

		showMessage: function (pMessage, pMsgTyp, pHandler) {

			if (pMessage.trim().length === 0) {
				return;
			}

			if (["A", "E", "I", "W"].indexOf(pMsgTyp) === -1) {
				sap.m.MessageToast.show(pMessage);
			} else {
				var sIcon = "";
				var sTitle = "";

				switch (pMsgTyp) {
				case 'W':
					sIcon = "WARNING";
					sTitle = "Warning";

					break;
				case 'E':
					sIcon = "ERROR";
					sTitle = "Error";

					break;
				case 'I':
					sIcon = "INFORMATION";
					sTitle = "Information";
					break;
				case 'A':
					sIcon = "NONE";
					break;
				default:
				}
				MessageBox.show(pMessage, {
					icon: sIcon,
					title: sTitle,
					onClose: pHandler,
					styleClass: "sapUiSizeCompact"
				});
			}
		},

		/**
		 * @purpose Message from Resource Bundle 
		 * @param1 pMessage -- String-Property of Resource Bundle
		 * @param2 aParametrs -- Array-Parameters
		 */
		getMessage: function (pMessage, aParametrs) {
			// read msg from i18n model
			var sMsg = "";
			var oMdlI18n = this.getOwnerComponent().getModel("i18n");
			if (oMdlI18n) {
				this._oBundle = oMdlI18n.getResourceBundle();
			} else {
				this._oBundle = null;
				return sMsg;
			}

			if (aParametrs && aParametrs.length) {
				sMsg = this._oBundle.getText(pMessage, aParametrs);
			} else {
				sMsg = this._oBundle.getText(pMessage);
			}

			return sMsg;
		},

		/**
		 * Convenience method to access the business rule services for value help.
		 * @public
		 * @param 
		 * @returns Open value help dialog based on the custom data defined on the input fields.
		 */

		onValueHelpRequested: function (oEvent) {

			var sInputField = oEvent.getSource().data().inputCustomData,
				oMdlCommon,
				aCols,
				sUrl;
			var oThisController = this;

			var bindingContext = oEvent.getSource().getBindingContext("mCommon");

			if (sInputField === "aTradingPartner") {
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oTradingPartner.cols;
				var sAccountGroupPayload = {
					"RuleServiceId": "e68a197bd23e4364904269f0fb9aed94",
					"Vocabulary": [{
						"TradingPartnerInput": {
							"TradingPartnerInput": ""
						}
					}]
				};
				//Get Label Name

				this.onCallBusinessRule(aCols, sInputField, sAccountGroupPayload);

			}

			if (sInputField === "Department") {
				oThisController.sSelectedObject = bindingContext.getObject();
				oMdlCommon = this.getParentModel("mCommon");

				aCols = oMdlCommon.getData().oDepartment.cols;
				var oDepartmentPayload = {
					"RuleServiceId": "9cc22028b5e54121a93f355ea3c5a1d5",
					"Vocabulary": [{
						"DepartmentInput": {
							"DepartmentInput": ""

						}
					}]
				};
				//Get Label Name

				this.onCallBusinessRule(aCols, sInputField, oDepartmentPayload);

			}

			if (sInputField === "DMEIndicator") {
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oDMEIndicator.cols;
				var oInputData = "/" + "oDMEData";
				this.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputField);
				this.fnCreateFragment(oMdlCommon, aCols, oInputData);

			}
			if (sInputField === "Language") {
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oLanguage.cols;
				oInputData = "/" + "oLanguageData";
				this.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputField);
				this.fnCreateFragment(oMdlCommon, aCols, oInputData);

			}

			if (sInputField === "Function") {
				oThisController.sSelectedObject = bindingContext.getObject();
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oFunction.cols;
				var oFunctionPayload = {
					"RuleServiceId": "20276304da0d4b9b8b43404602e3620f",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				this.onCallBusinessRule(aCols, sInputField, oFunctionPayload);
			}
			if (sInputField === "BankKey") {

				//var bindingPath = bindingContext.getPath();
				oThisController.sSelectedObject = bindingContext.getObject();
				oMdlCommon = this.getParentModel("mCommon");
				var sAddBankCountryKey = oThisController.sSelectedObject.sCountryKey;

				aCols = oMdlCommon.getData().oBankKey.cols;
				var oBankKeyPayload = {
					"RuleServiceId": "822f63901131444d9e2f8b6326c200d0",
					"Vocabulary": [{
						"BankKeyInput": {
							"BankCountryKey": sAddBankCountryKey

						}
					}]
				};
				this.onCallBusinessRule(aCols, sInputField, oBankKeyPayload);
			}

			//@ IFlow Services Search Help
			if (sInputField === "Customer") {
				sUrl = "/Customer";
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oCustomer.cols;
				this.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputField);
				this.fnGetLookupCpiData(sInputField, aCols, sUrl);
			}

			if (sInputField === "AlternativePayee") {
				sUrl = "/Alternative_payee";
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oAlternativePayee.cols;
				this.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputField);
				this.fnGetLookupCpiData(sInputField, aCols, sUrl);
			}
			if (sInputField === "InstructionKey") {
				sUrl = "/Instruction_key";
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oInstructionKey.cols;
				this.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputField);
				this.fnGetLookupCpiData(sInputField, aCols, sUrl);
			}

			if (sInputField === "Country") {
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oCountry.cols;
				var oCountryPayload = {
					"RuleServiceId": "97a27f6b964a4517854e366c21997004",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				this.onCallBusinessRule(aCols, sInputField, oCountryPayload);
			}

			if (sInputField === "Region") {
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oRegion.cols;

				var sCountry = oMdlCommon.getProperty("/oBasicDetails/sCountry");
				if (sCountry) {
					var oRegionPayload = {
						"RuleServiceId": "c96b372aa0f54b9688052c50d54051f5",
						"Vocabulary": [{
							"RegionInput": {
								"CountryKey": sCountry
							}
						}]
					};
					this.onCallBusinessRule(aCols, sInputField, oRegionPayload);
				} else {
					oThisController.showMessage(oThisController.getMessage("REGION_SELECTION_ERROR"), "W");
				}
			}

			if (sInputField === "CountryKey") {
				oThisController.sSelectedObject = bindingContext.getObject();
				oMdlCommon = this.getParentModel("mCommon");
				aCols = oMdlCommon.getData().oCountry.cols;
				var oCountryKeyPayload = {
					"RuleServiceId": "97a27f6b964a4517854e366c21997004",
					"Vocabulary": [{
						"Input": {
							"Input": ""

						}
					}]
				};
				this.onCallBusinessRule(aCols, sInputField, oCountryKeyPayload);
			}

		},

		/**
		 * Convenience method to call business rule API
		 * @public
		 * @param1  oColumns- All columns in the value help dialog table.
		 * @param2  sInputName- Find the selected input field based on the custom input data.
		 * @param3  oPayLoad-  Payload for calling business rule API
		 * @returns  Table row data.
		 */
		onCallBusinessRule: function (oColumns, sInputName, oPayload) {
			var oThisController = this;

			var oMdlCommon = oThisController.getParentModel("mCommon");
			oThisController.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputName);
			oMdlCommon.setProperty("/" + sInputName, []);
			// First get the CSRF token
			$.ajax({
				url: "/comsapVendorOnboarding/bpmrulesruntime/rules-service/v1/rules/xsrf-token",
				method: "GET",
				headers: {
					"X-CSRF-Token": "Fetch"
				},
				success: function (result, xhr, data) {
					var token = data.getResponseHeader("X-CSRF-Token");

					//Then invoke the business rules service via public API
					$.ajax({
						url: "/comsapVendorOnboarding/bpmrulesruntime/rules-service/rest/v2/workingset-rule-services",
						method: "POST",
						contentType: "application/json",
						data: JSON.stringify(oPayload),
						async: false,
						headers: {
							"X-CSRF-Token": token
						},

						success: function (result1, xhr1, data1) {

							var oInputData = "/" + sInputName;
							if (sInputName === "aTradingPartner") {

								oMdlCommon.setProperty(oInputData, result1.Result[0].TradingPartnerList);
							}
							if (sInputName === "Department") {
								oMdlCommon.setProperty(oInputData, result1.Result[0].DepartmentList);
							}
							if (sInputName === "Function") {
								oMdlCommon.setProperty(oInputData, result1.Result[0].FunctionList);
							}

							if (sInputName === "BankKey") {
								oMdlCommon.setProperty(oInputData, result1.Result[0].BankKeyList);
							}
							if (sInputName === "Country") {
								oMdlCommon.setProperty(oInputData, result1.Result[0].CountryList);

							}
							if (sInputName === "Region") {

								if (result1.Result.length === 0) {
									var sCountry = oMdlCommon.getProperty("/oBasicDetails/sCountry");
									var sErrorText = oThisController.getMessage("NO_RESULT_FOUND_REGION");
									MessageBox.error(sErrorText + " " + sCountry + ".");
									return;
								} else {
									oMdlCommon.setProperty(oInputData, result1.Result[0].RegionList);
								}
							}
							if (sInputName === "CountryKey") {
								oMdlCommon.setProperty(oInputData, result1.Result[0].CountryList);
							}

							oThisController.fnCreateFragment(oMdlCommon, oColumns, oInputData);

						},
						error: function (jqXHR, textStatus, errorThrown) {
							oThisController.showMessage(oThisController.getMessage("BUSINESS_RULE_ERROR"), "E");
							//	MessageBox.error("Error occurred while accessing Configure Business Rules.\n Error:" + errorThrown);

						}
					});
				},
				error: function (jqXHR, textStatus, errorThrown) {
					oMdlCommon.setProperty("/oError/serviceError", true);
					oThisController.showMessage(oThisController.getMessage("ACCESS_TOKEN_ERROR"), "E");
					//MessageBox.error("Error occurred while fetching access token.\n Error:" + errorThrown);

				}
			});
		},
		/**
		 * Convenience method to open value help dialog
		 * @public
		 * @param1  oColumns- All columns in the value help dialog table.
		 * @param2  sInputName- Find the selected input field based on the custom input data.
		 * @param3  sUrl-  URL to call the CPI services.
		 * @returns  Open value help dialog.
		 */
		fnGetLookupCpiData: function (sInputName, oColumns, sUrl) {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			oThisController.selectedInput = oMdlCommon.setProperty("/sSelectedInput", sInputName);
			oMdlCommon.setProperty("/" + sInputName, []);
			var url = "/comsapVendorRegistration/CPI_Dest/http" + sUrl;

			$.ajax({
				type: "GET",
				contentType: "application/json",
				url: url,
				dataType: "json",
				success: function (data, textStatus, jqXHR) {

					var oInputData = "/" + sInputName;
					oMdlCommon.setProperty(oInputData, data["RFC_READ_TABLE.Response"].DATA.item);
					oThisController.fnCreateFragment(oMdlCommon, oColumns, oInputData);
				},
				error: function (jqXHR, textStatus, errorThrown) {

					oThisController.showMessage(oThisController.getMessage("CPI_BASIC_SERVICE_ERROR"), "E");
					//MessageBox.error("Error occurred while fetching access token.\n Error:" + errorThrown);

				}

			});
		},
		/**
		 * Convenience method to open value help dialog
		 * @public
		 * @param1  oColumns- All columns in the value help dialog table.
		 * @param2  sInputName- Find the selected input field based on the custom input data.
		 * @param3  oMdlCommon-  'mCommon' common data model.
		 * @returns  Open value help dialog.
		 */
		fnCreateFragment: function (oMdlCommon, oColumns, oInputData) {

			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");
			if (sSelectedInput === "aTradingPartner") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "CompanyCode");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "CompanyName");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "CompanyCode");
				oMdlCommon.setProperty("/oDialog/sTitle", "Trading Partner");

			}

			if (sSelectedInput === "Department") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Department");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Department");
				oMdlCommon.setProperty("/oDialog/sTitle", "Department Key");
			}

			if (sSelectedInput === "DMEIndicator") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Data Medium Exchange Indicator");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Key");
				oMdlCommon.setProperty("/oDialog/sTitle", "Data Medium Exchange Indicator");
			}
			if (sSelectedInput === "Language") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sTitle", "Language Key");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Name");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Key");
			}

			if (sSelectedInput === "Function") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Function");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Function");
				oMdlCommon.setProperty("/oDialog/sTitle", "Function");
			}

			if (sSelectedInput === "BankKey") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Bank Key");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "NameOfBank");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "BankKey");
				oMdlCommon.setProperty("/oDialog/sTitle", "Bank Key");
			}
			if (sSelectedInput === "Customer") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Customer");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "CountryKey");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "CustomerNumber");
				oMdlCommon.setProperty("/oDialog/sTitle", "Customer");
			}
			if (sSelectedInput === "AlternativePayee") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Alternative Payee");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "VendorAccountNumber");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "");
				oMdlCommon.setProperty("/oDialog/sTitle", "Alternative Payee");
			}

			if (sSelectedInput === "InstructionKey") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sFilterLabel", "Instruction Key");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "AdditionalInformation");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "DataMediumExchange");
				oMdlCommon.setProperty("/oDialog/sTitle", "Instruction Key");
			}

			if (sSelectedInput === "Country") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Name");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Country");
				oMdlCommon.setProperty("/oDialog/sTitle", "Country/Region Key");
			}
			if (sSelectedInput === "Region") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Description");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Region");
				oMdlCommon.setProperty("/oDialog/sTitle", "Region Key");
			}

			if (sSelectedInput === "CountryKey") {
				oMdlCommon = this.getParentModel("mCommon");
				oMdlCommon.setProperty("/oDialog/sDialogDes", "Name");
				oMdlCommon.setProperty("/oDialog/sDialogKey", "Country");
				oMdlCommon.setProperty("/oDialog/sTitle", "Country Key");
			}

			this._oBasicSearchField = new SearchField({
				showSearchButton: false
			});

			this._oValueHelpDialog = sap.ui.xmlfragment("com.sap.VendorRegistration.fragments.BusinessValueHelp", this);
			this.getView().addDependent(this._oValueHelpDialog);

			var oFilterBar = this._oValueHelpDialog.getFilterBar();
			//	oFilterBar.setFilterBarExpanded(false);
			oFilterBar.setBasicSearch(this._oBasicSearchField);

			this._oValueHelpDialog.getTableAsync().then(function (oTable) {
				oTable.setModel(oMdlCommon);

				var oNewModel = new JSONModel();
				oNewModel.setData({
					cols: oColumns
				});
				oTable.setModel(oNewModel, "columns");

				if (oTable.bindRows) {
					oTable.bindAggregation("rows", oInputData);
				}

				if (oTable.bindItems) {

					oTable.bindAggregation("items", oInputData, function () {
						return new ColumnListItem({
							cells: oColumns.map(function (column) {
								return new Label({
									text: "{" + column.template + "}"
								});
							})
						});
					});
				}
				this._oValueHelpDialog.update();
			}.bind(this));
			this.closeBusyDialog();
			this._oValueHelpDialog.open();

		},

		/**
		 * Convenience method to select key and description value
		 * @public
		 * @param  oEvent- Get the existing token.
		 * @returns  capture key and description value in token.
		 */

		onValueHelpOkPress: function (oEvent) {

			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var aTokens = oEvent.getParameter("tokens");
			var text = aTokens[0].getText();
			var key = aTokens[0].getKey();
			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");

			if (sSelectedInput === "aTradingPartner") {
				oMdlCommon.setProperty("/oBasicDetails/sTradingPartner", key);
				oMdlCommon.setProperty("/oBasicDetails/sTradingPartnerKey", text);
			}
			if (sSelectedInput === "Department") {
				oThisController.sSelectedObject.sDepartment = key;
				oThisController.sSelectedObject.sDescription = text;
				// oMdlCommon.setProperty("/oBasicDetails/aAddContactPersons/0/sDepartment", key);
				// oMdlCommon.setProperty("/oBasicDetails/aAddContactPersons/0/sDescription", text);
			}
			if (sSelectedInput === "DMEIndicator") {

				if (key === "Default") {
					oMdlCommon.setProperty("/oBasicDetails/sDMEIndicator", "");
					oMdlCommon.setProperty("/oBasicDetails/sDMEIndicatorKey", text);

				} else {
					oMdlCommon.setProperty("/oBasicDetails/sDMEIndicator", key);
					oMdlCommon.setProperty("/oBasicDetails/sDMEIndicatorKey", text);
				}

			}

			if (sSelectedInput === "Language") {
				var sLanguageState = oMdlCommon.getProperty("/sLanguagestate");
				if (sLanguageState === "Error") {
					oMdlCommon.setProperty("/sLanguagestate", "None");
					oMdlCommon.setProperty("/sLanguagestateText", "");
				}
				oMdlCommon.setProperty("/oBasicDetails/sLanguage", key);
				oMdlCommon.setProperty("/oBasicDetails/sLanguageKey", text);
			}

			if (sSelectedInput === "Function") {

				//	oMdlCommon.setProperty("/oBasicDetails/aAddContactPersons/0/sFunction", text);
				oThisController.sSelectedObject.sFunction = key;
				oThisController.sSelectedObject.sFunctionKey = text;

			}
			if (sSelectedInput === "BankKey") {

				//	oMdlCommon.setProperty("/oBasicDetails/aAddBankDetails/0/sBankKey", text);
				oThisController.sSelectedObject.sBankKey = key;
				oThisController.sSelectedObject.sBankKeyTable = text;

			}

			if (sSelectedInput === "Customer") {

				/*	uText = text.substring(0, text.length - 3);
					textUpdated = uText.trim(); */
				var errorExist = oMdlCommon.getProperty("/sCustomerstate");
				if (errorExist === "Error") {

					oMdlCommon.setProperty("/sCustomerstate", "None");
					oMdlCommon.setProperty("/sCustomerstateText", "");
				}

				oMdlCommon.setProperty("/oBasicDetails/sCustomer", key);
				oMdlCommon.setProperty("/oBasicDetails/sCustomerKey", text);
			}

			if (sSelectedInput === "AlternativePayee") {

				errorExist = oMdlCommon.getProperty("/sAlternativePayeestate");
				if (errorExist === "Error") {

					oMdlCommon.setProperty("/sAlternativePayeestate", "None");
					oMdlCommon.setProperty("/sAlternativePayeestateText", "");
				}
				oMdlCommon.setProperty("/oBasicDetails/sAlternativePayee", text);
			}

			if (sSelectedInput === "InstructionKey") {

				oMdlCommon.setProperty("/oBasicDetails/sInstructionKey", key);
				oMdlCommon.setProperty("/oBasicDetails/sInstructionKeyKey", text);

			}
			if (sSelectedInput === "Country") {

				var sCountryState = oMdlCommon.getProperty("/sCountrystate");
				if (sCountryState === "Error") {
					oMdlCommon.setProperty("/sCountrystate", "None");
					oMdlCommon.setProperty("/sCountrystateText", "");
				}
				oMdlCommon.setProperty("/oBasicDetails/sCountry", key);
				oMdlCommon.setProperty("/oBasicDetails/sCountryKey", text);

			}
			if (sSelectedInput === "CountryKey") {
				oThisController.sSelectedObject.sCountryKey = key;
				oThisController.sSelectedObject.sCountryKeyTable = text;
			}
			if (sSelectedInput === "Region") {
				oMdlCommon.setProperty("/oBasicDetails/sRegion", key);
				oMdlCommon.setProperty("/oBasicDetails/sRegionKey", text);
			}
			this._oValueHelpDialog.close();
		},

		/**
		 * Convenience method to close existing value help dialog.
		 * @public
		 * @returns  Set property 'null' for selected key and description.
		 */

		onValueHelpCancelPress: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");

			if (sSelectedInput === "aTradingPartner") {
				oMdlCommon.setProperty("/oBasicDetails/sTradingPartner", "");
			}
			if (sSelectedInput === "Department") {
				oThisController.sSelectedObject.sDepartment = "";
				oThisController.sSelectedObject.sDescription = "";
				// oMdlCommon.setProperty("/oBasicDetails/aAddContactPersons/0/sDepartment", key);
				// oMdlCommon.setProperty("/oBasicDetails/aAddContactPersons/0/sDescription", text);
			}
			if (sSelectedInput === "DMEIndicator") {
				oMdlCommon.setProperty("/oBasicDetails/sDMEIndicator", "");
			}
			if (sSelectedInput === "Language") {
				var sLanguageState = oMdlCommon.getProperty("/sLanguagestate");
				if (sLanguageState === "Error") {
					oMdlCommon.setProperty("/sLanguagestate", "None");
					oMdlCommon.setProperty("/sLanguagestateText", "");
				}
				oMdlCommon.setProperty("/oBasicDetails/sLanguage", "");
				oMdlCommon.setProperty("/oBasicDetails/sLanguageKey", "");
			}

			if (sSelectedInput === "Function") {

				//	oMdlCommon.setProperty("/oBasicDetails/aAddContactPersons/0/sFunction", "");
				oThisController.sSelectedObject.sFunction = "";
			}

			if (sSelectedInput === "BankKey") {
				oThisController.sSelectedObject.sBankKey = "";
			}

			if (sSelectedInput === "Customer") {
				oMdlCommon.setProperty("/oBasicDetails/sCustomer", "");
			}

			if (sSelectedInput === "AlternativePayee") {
				oMdlCommon.setProperty("/oBasicDetails/sAlternativePayee", "");
			}

			if (sSelectedInput === "InstructionKey") {
				oMdlCommon.setProperty("/oBasicDetails/sInstructionKey", "");
				oMdlCommon.setProperty("/oBasicDetails/sInstructionKeyKey", "");
			}

			if (sSelectedInput === "Country") {
				var sCountryState = oMdlCommon.getProperty("/sCountrystate");
				if (sCountryState === "Error") {
					oMdlCommon.setProperty("/sCountrystate", "None");
					oMdlCommon.setProperty("/sCountrystateText", "");
				}
				oMdlCommon.setProperty("/oBasicDetails/sCountry", "");
			}

			if (sSelectedInput === "Region") {

				oMdlCommon.setProperty("/oBasicDetails/sRegion", "");
			}

			if (sSelectedInput === "CountryKey") {

				oThisController.sSelectedObject.sCountryKey = "";
			}

			this._oValueHelpDialog.close();
			oMdlCommon.refresh();
		},
		/**
		 * Convenience method to destroy the existing value help dialog.
		 * @public
		 * @returns  Destroy the value help dialog and set property 'null'
		 */
		onValueHelpAfterClose: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			if (this._oValueHelpDialog) {
				this._oValueHelpDialog.destroy();
				this._oValueHelpDialog = null; // make it falsy so that it can be created next time
			}
			oMdlCommon.refresh();
		},

		/**
		 * Convenience method to filter table data.
		 * @public
		 * @param  oEvent- Get Property 'selectionSet'
		 * @returns  Filter table data based on given values.
		 */
		onFilterBarSearch: function (oEvent) {
			var oMdlCommon = this.getParentModel("mCommon"),
				sSelectedInput = oMdlCommon.getProperty("/sSelectedInput");

			var sSearchQuery = this._oBasicSearchField.getValue(),
				aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getValue()) {

					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);
			if (sSelectedInput === "aTradingPartner") {
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "CompanyName",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CountryKey",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CompanyCode",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Currency",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
			}

			if (sSelectedInput === "Customer") {
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "CustomerNumber",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CountryKey",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
			}

			if (sSelectedInput === "DMEIndicator") {
				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "Key",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})

					],
					and: false
				}));
			}
			if (sSelectedInput === "Department") {

				aFilters.push(new Filter({

					filters: [
						new Filter({
							path: "Department",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));

			}

			if (sSelectedInput === "BankKey") {
				aFilters.push(new Filter({
					filters: [
						new Filter({
							path: "NameOfBank",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "BankKey",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));

			}
			if (sSelectedInput === "Function") {
				aFilters.push(new Filter({
					filters: [
						new Filter({
							path: "Function",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));

			}

			if (sSelectedInput === "AlternativePayee") {
				aFilters.push(new Filter({
					filters: [
						new Filter({
							path: "VendorAccountNumber",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "CountryKey",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
			}

			if (sSelectedInput === "InstructionKey") {
				aFilters.push(new Filter({
					filters: [
						new Filter({
							path: "BankCountryKey",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "PaymentMethod",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "DataMediumExchange",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "AdditionalInformation",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
			}

			if (sSelectedInput === "Country") {
				aFilters.push(new Filter({
					filters: [
						new Filter({
							path: "Country",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Name",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
			}

			if (sSelectedInput === "Region") {
				aFilters.push(new Filter({
					filters: [
						new Filter({
							path: "Region",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Description",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
			}

			if (sSelectedInput === "CountryKey") {
				aFilters.push(new Filter({
					filters: [
						new Filter({
							path: "Country",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Name",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
			}

			if (sSelectedInput === "Language") {
				aFilters.push(new Filter({
					filters: [
						new Filter({
							path: "Key",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						}),
						new Filter({
							path: "Name",
							operator: FilterOperator.Contains,
							value1: sSearchQuery
						})
					],
					and: false
				}));
			}

			this._filterTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterTable: function (oFilter) {
			var oValueHelpDialog = this._oValueHelpDialog;

			oValueHelpDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				oValueHelpDialog.update();
			});
		},

		/**
		 * Convenience method for adding a new row in the Bank Details table
		 * @public
		 * @returns  {Object}- aAddBankDetails Array
		 */
		onAddBankDetails: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var oNewPartner = oMdlCommon.getProperty("/oBasicDetails");
			var oRow = {

				"sBankKey": "",
				"sBankKeyTable": "",
				"sCountryKey": "",
				"sCountryKeyTable": "",
				"sBankAcctNo": "",
				"sBankHolder": ""

			};
			oNewPartner.aAddBankDetails.push(oRow);
			oMdlCommon.setProperty("/oBasicDetails", oNewPartner);
		},
		/**
		 * Convenience method for adding a new row in the Bank Details table
		 * @public
		 * @returns  {Object}- aAddContactPersons Array
		 */
		onAddContactPersons: function () {
			var oThisController = this;
			var oMdlCommon = oThisController.getParentModel("mCommon");
			var oNewPartner = oMdlCommon.getProperty("/oBasicDetails");
			var oRow = {
				"sFormOfAddress": "",
				"sFirstName": "",
				"sContactName": "",
				"sDepartment": "",
				"sDescription": "",
				"sContactPhone": "",
				"sFunction": "",
				"sFunctionKey": ""

			};
			oNewPartner.aAddContactPersons.push(oRow);
			oMdlCommon.setProperty("/oBasicDetails", oNewPartner);
		},

		/**
		 * Convenience method for deleting selected row.
		 * @public
		 * @returns  Remove {Object}- aAddBankDetails Array
		 */

		onHandleBankDetailsDelete: function (oEvent) {
			var oThisController = this;
			oThisController.openBusyDialog();

			var oMdlcommon = oThisController.getParentModel("mCommon");
			var bindingContext = oEvent.getSource().getBindingContext("mCommon");
			var deleteRecord = bindingContext.getObject();
			var aAddBankDetails = oMdlcommon.getProperty("/oBasicDetails/aAddBankDetails");

			if (aAddBankDetails.length > 1) {
				for (var i = 0; i < aAddBankDetails.length; i++) {
					if (aAddBankDetails[i] == deleteRecord) {
						//	pop this._data.Products[i] 
						aAddBankDetails.splice(i, 1); //removing 1 record from i th index.

						oMdlcommon.setProperty("/oBasicDetails/aAddBankDetails", aAddBankDetails);
						oThisController.closeBusyDialog();
						oMdlcommon.refresh();

						break; //quit the loop
					}
				}

			} else {
				oThisController.showMessage(oThisController.getMessage("RESTRICTION"), "I");
				oThisController.closeBusyDialog();
			}

		},

		/**
		 * Convenience method for deleting selected row.
		 * @public
		 * @returns  Remove {Object}- aAddContactPersons Array
		 */

		onHandleContactPersonDelete: function (oEvent) {

			var oThisController = this;
			oThisController.openBusyDialog();

			var oMdlcommon = oThisController.getParentModel("mCommon");
			var bindingContext = oEvent.getSource().getBindingContext("mCommon");
			var deleteRecord = bindingContext.getObject();
			var aAddContactPersons = oMdlcommon.getProperty("/oBasicDetails/aAddContactPersons");

			if (aAddContactPersons.length > 1) {
				for (var i = 0; i < aAddContactPersons.length; i++) {
					if (aAddContactPersons[i] == deleteRecord) {
						//	pop this._data.Products[i] 
						aAddContactPersons.splice(i, 1); //removing 1 record from i th index.

						oMdlcommon.setProperty("/oBasicDetails/aAddContactPersons", aAddContactPersons);
						oThisController.closeBusyDialog();
						oMdlcommon.refresh();

						break; //quit the loop
					}
				}

			} else {
				oThisController.showMessage(oThisController.getMessage("RESTRICTION"), "I");
				oThisController.closeBusyDialog();
			}
		},

		/**
		 * Convenience method to change the 'valueState' & 'valueStateText' property of inputs.
		 * @public
		 * @param  oEvent- Get property 'valueState'
		 * @returns set 'valueState' & 'valueStateText' property of an input.
		 */
		onLiveChange: function (oEvent) {

			var errorExist = oEvent.getSource().getProperty("valueState");
			if (errorExist === "Error") {

				oEvent.getSource().setProperty("valueState", "None");
				oEvent.getSource().setProperty("valueStateText", "");

			}
		}

	});
});