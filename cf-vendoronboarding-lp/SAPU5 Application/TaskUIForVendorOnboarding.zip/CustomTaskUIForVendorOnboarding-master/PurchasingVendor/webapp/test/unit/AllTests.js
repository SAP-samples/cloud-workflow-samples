sap.ui.define([
	"com/sap/PurchasingVendor/test/unit/controller/App.controller"
], function () {
	"use strict";
});