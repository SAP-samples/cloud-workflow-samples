sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/m/BusyDialog",
    "sap/m/MessagePopover",
    "sap/m/MessageItem",
    "sap/m/Token",
    "sap/m/Label",
    "sap/m/ColumnListItem",
    "sap/m/SearchField",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/comp/filterbar/FilterBar",
    "sap/ui/comp/filterbar/FilterGroupItem",
    "sap/m/Input"
],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController, JSONModel, MessageBox, MessageToast, BusyDialog, MessagePopover, MessageItem, Token, Label, ColumnListItem, SearchField,
        Filter, FilterOperator, FilterBar, FilterGroupItem, Input) {
        "use strict";

        return BaseController.extend("sap.ibpm.ReworkPR.controller.App", {
            onInit: function () {
                this.getContentDensityClass();
                this.configureView();
                this.getPurchasingGroupsList();
                this.getPlants(this.getView().getModel().getProperty("/local/ItemNew/MATERIAL"))
            },

            configureView: function () {

                var startupParameters = this.getComponentData().startupParameters;
                var updateButtonText = this.getMessage("UPDATE");
                var deleteButtonText = this.getMessage("DELETE");

                var oModel = this.getModel(),
                    taskInstanceModel = this.getModel("taskInstanceModel"),
                    sSubject = taskInstanceModel.getData().subject;
                this.byId("reworkPageHeader").setObjectTitle(sSubject);

                var oThisController = this;

                /**
                 * UPDATE BUTTON
                 */
                // Implementation for update action
                var oUpdate = {
                    sBtnTxt: updateButtonText,
                    onBtnPressed: function () {
                        oModel.refresh(true);
                        var processContext = oModel.getData();

                        // Call a local method to perform further action
                        oThisController._validateInput(
                            processContext,
                            startupParameters.taskModel.getData().InstanceID,
                            "update"
                        );
                    }
                };

                // Add 'Update' action to the task
                startupParameters.inboxAPI.addAction({
                    // confirm is a positive action
                    action: oUpdate.sBtnTxt,
                    label: oUpdate.sBtnTxt,
                    type: "Accept"
                },
                    // Set the onClick function
                    oUpdate.onBtnPressed);

                /**
                 * DELETE BUTTON
                 */
                // Implementation for delete action
                var oDelete = {
                    sBtnTxt: deleteButtonText,
                    onBtnPressed: function () {
                        oModel.refresh(true);
                        var processContext = oModel.getData();

                        // Call a local method to perform further action
                        oThisController.onProcessRework(
                            processContext,
                            startupParameters.taskModel.getData().InstanceID,
                            "delete"
                        );
                    }
                };

                // Add 'Delete' action to the task
                startupParameters.inboxAPI.addAction({
                    // confirm is a positive action
                    action: oDelete.sBtnTxt,
                    label: oDelete.sBtnTxt,
                    type: "Reject"
                },
                    // Set the onClick function
                    oDelete.onBtnPressed);

            },

            getPurchasingGroupsList: function () {
                // set rulesModel
                var rulesModel = new JSONModel();
                var inputPayload = {
                    'RuleServiceId': 'f06b0ad40c3d434790e888645564ce4c',
                    'RuleServiceRevision': '2008',
                    'Vocabulary': [{ 'SearchValueField': { "SF": '' } }]
                };

                var self = this;

                // First get the CSRF token
                $.ajax({
                    url: self._getRuntimeBaseURL() + "/bpmrulesruntime/xsrf-token",
                    method: "GET",
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {
                        var token = data.getResponseHeader("X-CSRF-Token");

                        //Then invoke the business rules service via public API
                        $.ajax({
                            url: self._getRuntimeBaseURL() + "/bpmrulesruntime/rule-services",
                            method: "POST",
                            contentType: "application/json",
                            data: JSON.stringify(inputPayload),
                            async: false,
                            headers: {
                                "X-CSRF-Token": token
                            },
                            success: function (result1, xhr1, data1) {
                                if (result1 !== null) {
                                    var aPurGroups = result1.Result[0].PurchasingGroupDetails;
                                    rulesModel.setProperty("/purchasingGroups", aPurGroups);
                                    rulesModel.refresh();
                                }
                            }
                        });
                    }
                });
                rulesModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
                this.setModel(rulesModel, "rulesModel");
            },

            searchMaterial: function (sValue, oControl, oController) {
                var oModel = this.getView().getModel("mCommon");
                if (sValue !== "") {
                    sValue = "*" + sValue + "*";
                    var RequestContent = {
                        "BAPI_MATERIAL_GETLIST": {
                            "MAXROWS": "100",
                            "MATNRSELECTION": {
                                "item": {
                                    "SIGN": "I",
                                    "OPTION": "CP",
                                    "MATNR_LOW": sValue,
                                    "MATNR_HIGH": "",
                                    "MATNR_HIGH_EXTERNAL": "",
                                    "MATNR_HIGH_GUID": "",
                                    "MATNR_HIGH_VERSION": "",
                                    "MATNR_LOW_EXTERNAL": "",
                                    "MATNR_LOW_GUID": "",
                                    "MATNR_LOW_VERSION": "",
                                    "MATNR_LOW_LONG": "",
                                    "MATNR_HIGH_LONG": ""
                                }
                            },
                            "MATERIALSHORTDESCSEL": {
                                "item": {
                                    "SIGN": "I",
                                    "OPTION": "CP",
                                    "DESCR_LOW": sValue, /*"sValue" */
                                    "DESCR_HIGH": ""
                                }
                            }
                        }
                    };
                    $.ajax({
                        type: "POST",
                        contentType: "application/json",
                        url: this._getCPIRuntimeBaseURL()+"/PR_MATERIAL_GETLIST",
                        data: JSON.stringify(RequestContent),
                        success: function (result, xhr, data) {
                            var oResponse = JSON.parse(result)["BAPI_MATERIAL_GETLIST.Response"];
                            if (oResponse.MATNRLIST != "") {
                                oModel.setProperty("/materials", oResponse.MATNRLIST.item);
                                // oSearch.suggest(); // if desired
                                MessageToast.show("Search completed successfully");
                            } else {
                                MessageToast.show("No matching data found")
                                oModel.setProperty("/materials", {});
                                // If called by Table (valueHelp); not SearchField
                                if (oControl.mProperties.hasOwnProperty("visibleRowCount")) {
                                    oControl.setNoData("No data");
                                }
                            }
                            // If called by Table (valueHelp); not SearchField
                            if (oControl.mProperties.hasOwnProperty("visibleRowCount")) {
                                oController._oValueHelpDialog.update();
                            }
                            //oControl.getBinding().refresh(); // if usage of suggestionItems
                        },
                        error: function (err) {
                            MessageToast.show("Error searching for materials");
                        }
                    });
                }
                // if usage of suggestionItems
                // this.oSF.getBinding("suggestionItems").filter(aFilters);
                // this.oSF.suggest();
            },

            getPlants: function (sMaterial) {
                var oModel = this.getView().getModel(); // event.getSource().
                var oController = this;
                if (sMaterial !== "") {
                    var RequestContent = {
                        "SLS_LORD_GET_VALUES_WERKS": {
                            "IV_MATNR": sMaterial,
                            "IV_MATNR_LONG": "",
                            "IV_SPART": "",
                            "IV_VKORG": "",
                            "IV_VTWEG": ""
                        }
                    };
                    $.ajax({
                        type: "POST",
                        contentType: "application/json",
                        url: this._getCPIRuntimeBaseURL()+"/SLS_LORD_GET_VALUES_WERKS",
                        data: JSON.stringify(RequestContent),
                        success: function (result, xhr, data) {
                            var oResponse = JSON.parse(result);
                            oModel.setProperty("/plants", oResponse["SLS_LORD_GET_VALUES_WERKS.Response"].ET_HELPVALUE.item);
                        },
                        error: function (err) {
                            MessageToast.show("Error getting material details");
                        }
                    });
                }

            },

            getMaterialDetails: function (event) {
                var oModel = this.getView().getModel();
                var sMaterial = oModel.getProperty("/local/ItemNew/MATERIAL");
                if (sMaterial !== "") {
                    var RequestContent = {
                        "BAPI_MATERIAL_GET_DETAIL": {
                            "MATERIAL": sMaterial,
                            "MATERIAL_EVG": {
                                "MATERIAL_EXT": "",
                                "MATERIAL_VERS": "",
                                "MATERIAL_GUID": ""
                            },
                            "MATERIAL_LONG": "",
                            "PLANT": oModel.getProperty("/local/ItemNew/PLANT"), //0001
                            "VALUATIONAREA": oModel.getProperty("/local/ItemNew/PLANT"), //0001
                            "VALUATIONTYPE": ""
                        }
                    };
                    $.ajax({
                        type: "POST",
                        contentType: "application/json",
                        url: this._getCPIRuntimeBaseURL()+"/PR_MATERIAL_GET_DETAIL",
                        data: JSON.stringify(RequestContent),
                        success: function (result, xhr, data) {
                            var oResponse = JSON.parse(result);
                            var sPurGroupResponded = oResponse["ns0:BAPI_MATERIAL_GET_DETAIL.Response"].MATERIALPLANTDATA.PUR_GROUP;
                            if (sPurGroupResponded !== "") oModel.setProperty("/local/ItemNew/PUR_GROUP", sPurGroupResponded);
                            oModel.setProperty("/local/ItemNew/UNIT", oResponse["ns0:BAPI_MATERIAL_GET_DETAIL.Response"].MATERIAL_GENERAL_DATA.BASE_UOM_ISO);
                            oModel.setProperty("/local/ItemNew/C_AMT_BAPI", parseInt(oResponse["ns0:BAPI_MATERIAL_GET_DETAIL.Response"].MATERIALVALUATIONDATA.STD_PRICE));
                            oModel.setProperty("/local/ItemNew/CURRENCY", oResponse["ns0:BAPI_MATERIAL_GET_DETAIL.Response"].MATERIALVALUATIONDATA.CURRENCY);
                        },
                        error: function (err) {
                            MessageToast.show("Error getting material details");
                        }
                    });
                }
            },

            onValueHelpRequested: function (oEvent) {
                this.fnCreateFragment();
            },

            fnCreateFragment: function () {
                var aCols = this.getView().getModel("mCommon").getData().cols;

                this._oBasicSearchField = new SearchField({
                    showSearchButton: false
                });

                this._oValueHelpDialog = sap.ui.xmlfragment("sap.ibpm.ReworkPR.fragments.BusinessValueHelp", this);
                this.getView().addDependent(this._oValueHelpDialog);

                // Filter Configuration 
                var oFilterBar = this._oValueHelpDialog.getFilterBar();
                oFilterBar.setFilterBarExpanded(false);
                oFilterBar.setBasicSearch(this._oBasicSearchField);

                // Binding  Data to the Table 
                this._oValueHelpDialog.getTableAsync().then(function (oTable) {
                    oTable.setModel(this.getView().getModel("mCommon"));

                    var oNewModel = new JSONModel();
                    oNewModel.setData({
                        cols: aCols
                    });
                    oTable.setModel(oNewModel, "columns");

                    if (oTable.bindRows) {
                        oTable.bindAggregation("rows", "/materials");
                    }

                    if (oTable.bindItems) {

                        oTable.bindAggregation("items", "/materials", function () {
                            return new ColumnListItem({
                                cells: aCols.map(function (column) {
                                    return new Label({
                                        text: "{" + column.template + "}"
                                    });
                                })
                            });
                        });
                    }
                    this._oValueHelpDialog.update();
                }.bind(this));
                // this.closeBusyDialog();  // Todo: if desired
                this._oValueHelpDialog.open();

            },

            onValueHelpOkPress: function (oEvent) {

                var oThisController = this;
                var aTokens = oEvent.getParameter("tokens");
                var text = aTokens[0].getText();
                var key = aTokens[0].getKey();

                this.getView().getModel().setProperty("/local/ItemNew/MATERIAL", key);
                this.getView().getModel().setProperty("/local/ItemNew/SHORT_TEXT", text);

                this.getPlants(key);

                this._oValueHelpDialog.close();
            },

            onValueHelpCancelPress: function () {
                this._oValueHelpDialog.close();
                this.getView().getModel().refresh();
            },

            onValueHelpAfterClose: function () {
                this._oValueHelpDialog.destroy();
            },

            onFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");
                var oValueHelpDialog = this._oValueHelpDialog;
                var oThisController = this;

                oValueHelpDialog.getTableAsync().then(function (oTable) {

                    oThisController.searchMaterial(sSearchQuery, oTable, oThisController);

                });
            },

            _filterTable: function (oFilter) {
                var oValueHelpDialog = this._oValueHelpDialog;

                oValueHelpDialog.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }

                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    oValueHelpDialog.update();
                });
            },

            /**
             * Convenience method for all Input validation errors.
             * @public
             * @returns Validate all the required input fields.
             */
            _validateInput: function (processContext, taskId, sDecision) {

                var errorExist = false,
                    oThisController = this,
                    oModel = oThisController.getModel();

                oThisController.getView().setBusy(true);

                // Checking Line Item Details Fields
                var lineItemFields = [
                    "MATERIAL",
                    "PUR_GROUP",
                    "PURCH_ORG",
                    "PLANT",
                    "QUANTITY",
                    "C_AMT_BAPI"
                ];
                var lineItemValue;
                for (var i = 0; i < lineItemFields.length; i++) {
                    lineItemValue = oModel.getProperty("/local/ItemNew/" + lineItemFields[i]).toString();
                    if (lineItemValue && lineItemValue.trim() && lineItemValue !== "" && lineItemValue !== "undefined" && lineItemValue !==
                        "null") {
                        oModel.setProperty("/" + lineItemFields[i] + "State", "None");
                    } else {
                        errorExist = true;
                        if (lineItemFields[i] === "MATERIAL") {
                            oModel.setProperty("/" + lineItemFields[i] + "StateText", oThisController.getMessage("FIELD_VALIDATION_ERROR_MATERIAL"));
                        }
                        if (lineItemFields[i] === "PUR_GROUP") {
                            oModel.setProperty("/" + lineItemFields[i] + "StateText", oThisController.getMessage("FIELD_VALIDATION_ERROR_PURCH_GROUP"));
                        }
                        if (lineItemFields[i] === "PURCH_ORG") {
                            oModel.setProperty("/" + lineItemFields[i] + "StateText", oThisController.getMessage("FIELD_VALIDATION_ERROR_PURCH_ORG"));
                        }
                        if (lineItemFields[i] === "PLANT") {
                            oModel.setProperty("/" + lineItemFields[i] + "StateText", oThisController.getMessage("FIELD_VALIDATION_ERROR_PLANT"));
                        }
                        if (lineItemFields[i] === "QUANTITY") {
                            oModel.setProperty("/" + lineItemFields[i] + "StateText", oThisController.getMessage("FIELD_VALIDATION_ERROR_QUANTITY"));
                        }
                        if (lineItemFields[i] === "C_AMT_BAPI") {
                            oModel.setProperty("/" + lineItemFields[i] + "StateText", oThisController.getMessage("FIELD_VALIDATION_ERROR_PRICE"));
                        }

                        oModel.setProperty("/" + lineItemFields[i] + "State", "Error");

                    }
                }

                // Checking comment
                var requesterCommentValue = oModel.getProperty("/local/RequestorComment");
                var isReqCommentPresent = requesterCommentValue && requesterCommentValue.trim() && requesterCommentValue !== ""
                    && requesterCommentValue !== "undefined" && requesterCommentValue !== "null";
                if (!isReqCommentPresent) {
                    var reworkCommentsErr = oThisController.getMessage("FIELD_VALIDATION_ERROR_REWORK_COMMENTS")
                    errorExist = true;
                    oModel.setProperty("/RequestorCommentState", "Error");
                    oModel.setProperty("/RequestorCommentStateText", reworkCommentsErr);
                } else {
                    oModel.setProperty("/RequestorCommentState", "None");
                }

                if (errorExist) {
                    var sGenericErrorText = oThisController.getMessage("FIELD_VALIDATION_ERROR_GENERIC");
                    MessageToast.show(sGenericErrorText)
                    oThisController.getView().setBusy(false);
                    return;
                } else {
                    oThisController.onProcessRework(processContext, taskId, sDecision);
                }

            },

            /**
             * Convenience method for removing all required Input validation Error.
             * @public
             * @returns Remove errors from value help dialog.
             */
            onChange: function (oEvent) {
                var oThisController = this;
                var oModel = oThisController.getParentModel();
                var oInput = oEvent.getSource();
                if (oInput.getProperty("value").length > 0 && oInput.getProperty("valueState") === "Error") {
                    oInput.setProperty("valueState", "None");
                    oInput.setProperty("valueStateText", "");
                }

            },

            onProcessRework: function (processContext, taskId, sDecision) {

                this.setBusy(true);

                for (var i in processContext) {
                    if (i === "local") {
                        processContext[i].ItemNew.QUANTITY = parseInt(processContext[i].ItemNew.QUANTITY);
                        processContext[i].ItemNew.C_AMT_BAPI = parseInt(processContext[i].ItemNew.C_AMT_BAPI);
                    }
                }

                var oPayload = {
                    // LineItem: processContext.LineItem,
                    local: processContext.local
                }

                var oThisController = this;

                var token;
                $.ajax({
                    url: oThisController._getRuntimeBaseURL() + "/bpmworkflowruntime/v1/xsrf-token",
                    method: "GET",
                    async: false,
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {
                        token = data.getResponseHeader("X-CSRF-Token");
                        $.ajax({
                            type: "PATCH",
                            contentType: "application/json",
                            headers: {
                                "X-CSRF-Token": token
                            },
                            url: oThisController._getRuntimeBaseURL() + "/bpmworkflowruntime/v1/task-instances/" + taskId,
                            data: JSON.stringify({
                                context: oPayload,
                                decision: sDecision,
                                status: "COMPLETED"
                            }),
                            success: function (result2, xhr2, data2) {
                                oThisController._refreshTask();
                            },
                            error: function (err) {
                                oThisController.setBusy(false);
                                MessageToast.show("Error submiting the request");
                            }
                        });
                    }
                });
            },
            _getRuntimeBaseURL: function () {
                var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
                var appPath = appId.replaceAll(".", "/");
                var appModulePath = jQuery.sap.getModulePath(appPath);

                return appModulePath;
            },

            // Request Inbox to refresh the control once the task is completed
            _refreshTask: function () {
                var taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
                this.getComponentData().startupParameters.inboxAPI.updateTask("NA", taskId);
                this.setBusy(false);
                console.log("task is refreshed");
            },

            _getCPIRuntimeBaseURL: function () {
                var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
                var appPath = appId.replaceAll(".", "/");
                var appModulePath = jQuery.sap.getModulePath(appPath);

                return appModulePath + "/cpidest/http";
            }

        });
    });
