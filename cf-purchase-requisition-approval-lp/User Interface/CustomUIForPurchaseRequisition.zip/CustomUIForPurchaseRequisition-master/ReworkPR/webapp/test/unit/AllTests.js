sap.ui.define([
	"sap/ibpm/ReworkPR/test/unit/controller/App.controller"
], function () {
	"use strict";
});
