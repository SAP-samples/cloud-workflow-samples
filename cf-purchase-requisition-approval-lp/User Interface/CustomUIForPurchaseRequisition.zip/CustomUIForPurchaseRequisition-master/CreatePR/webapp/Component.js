sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "sap/ibpm/CreatePR/model/models"
], function (UIComponent, Device, models) {
    "use strict";

    return UIComponent.extend("sap.ibpm.CreatePR.Component", {

        metadata: {
            manifest: "json"
        },

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
        init: function () {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // enable routing
            this.getRouter().initialize();

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            // set Default-Model
            var oModel = new sap.ui.model.json.JSONModel();
            oModel.attachRequestCompleted(function () {
                var oContext = oModel.getData();
                oContext.item = oContext.BAPI_REQUISITION_CREATE.REQUISITION_ITEMS.item[0];
                oContext.subm = oContext.Request.BAPI_REQUISITION_GETDETAIL.Requestor;
                // Copy initial empty item and break binding
                oModel.setProperty("/templateItem", $.extend({}, oContext.BAPI_REQUISITION_CREATE.REQUISITION_ITEMS.item[0]));
                //bpModel.setData(bpContext);
            });
        }
    });
});