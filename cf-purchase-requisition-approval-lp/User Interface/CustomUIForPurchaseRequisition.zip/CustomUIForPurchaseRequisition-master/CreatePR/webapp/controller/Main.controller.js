sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/SearchField",
    "sap/m/Label",
    "sap/m/ColumnListItem"
], function (Controller, JSONModel, MessageToast, SearchField, Label, ColumnListItem) {
    "use strict";

    return Controller.extend("sap.ibpm.CreatePR.controller.Main", {
        onInit: function () {
            // Get rulesModel for Puchasing Group value help
            this.getView().setModel(this.getOwnerComponent().getModel("rulesModel"), "rulesModel");

            this._setRulesModel();
        },

        _getRuntimeBaseURL: function () {
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = jQuery.sap.getModulePath(appPath);

            return appModulePath;
        },

        _setRulesModel: function () {
            // set rulesModel
            var rulesModel = new sap.ui.model.json.JSONModel();
            var inputPayload = {
                'RuleServiceId': 'f06b0ad40c3d434790e888645564ce4c',
                // 'RuleServiceRevision': 'Draft',
                'RuleServiceRevision': '2008',
                'Vocabulary': [{ 'SearchValueField': { "SF": '' } }]
            };

            var self = this;

            // First get the CSRF token
            $.ajax({
                url: self._getRuntimeBaseURL() + "/bpmrulesruntime/xsrf-token",
                method: "GET",
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success: function (result, xhr, data) {
                    var token = data.getResponseHeader("X-CSRF-Token");

                    //Then invoke the business rules service via public API
                    $.ajax({
                        url: self._getRuntimeBaseURL() + "/bpmrulesruntime/rule-services",
                        method: "POST",
                        contentType: "application/json",
                        data: JSON.stringify(inputPayload),
                        async: false,
                        headers: {
                            "X-CSRF-Token": token
                        },
                        success: function (result1, xhr1, data1) {
                            if (result1 !== null) {
                                var aPurGroups = result1.Result[0].PurchasingGroupDetails;
                                rulesModel.setProperty("/purchasingGroups", aPurGroups);
                                rulesModel.refresh();
                            }
                        }
                    });
                }
            });
            rulesModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
            this.getView().setModel(rulesModel, "rulesModel");
        },

        onSuggest: function (event) {
            var sValue = event.getParameter("value"); // suggestValue if SearchField used
            var oSearch = this.getView().byId("searchMaterial");
            this.searchMaterial(sValue, oSearch, this);
        },

        initializeItem: function () {
            // Copy initial empty item and break binding
            var oEmptyItem = $.extend({}, this.getView().getModel().getProperty("/templateItem"));
            this.getView().getModel().setProperty("/item", oEmptyItem);
            // Empty comment (whole PR), not set currently
            //this.getView().getModel().setProperty("/subm/Comment", "");
        },

        searchMaterial: function (sValue, oControl, oController) {
            var oModel = this.getView().getModel();
            if (sValue !== "") {
                sValue = "*" + sValue + "*";
                var RequestContent = {
                    "BAPI_MATERIAL_GETLIST": {
                        "MAXROWS": "100",
                        "MATNRSELECTION": {
                            "item": {
                                "SIGN": "I",
                                "OPTION": "CP",
                                "MATNR_LOW": sValue,
                                "MATNR_HIGH": "",
                                "MATNR_HIGH_EXTERNAL": "",
                                "MATNR_HIGH_GUID": "",
                                "MATNR_HIGH_VERSION": "",
                                "MATNR_LOW_EXTERNAL": "",
                                "MATNR_LOW_GUID": "",
                                "MATNR_LOW_VERSION": "",
                                "MATNR_LOW_LONG": "",
                                "MATNR_HIGH_LONG": ""
                            }
                        },
                        "MATERIALSHORTDESCSEL": {
                            "item": {
                                "SIGN": "I",
                                "OPTION": "CP",
                                "DESCR_LOW": sValue,
                                "DESCR_HIGH": ""
                            }
                        }
                    }
                };
                $.ajax({
                    type: "POST",
                    contentType: "application/json",

                    url: this._getCPIRuntimeBaseURL() + "/PR_MATERIAL_GETLIST",


                    data: JSON.stringify(RequestContent),
                    success: function (result, xhr, data) {
                        var oResponse = JSON.parse(result)["BAPI_MATERIAL_GETLIST.Response"];
                        if (oResponse.MATNRLIST != "") {
                            oModel.setProperty("/materials", oResponse.MATNRLIST.item);
                            // oSearch.suggest(); // if desired
                            MessageToast.show("Search completed successfully");
                        } else {
                            MessageToast.show("No matching data found")
                            oModel.setProperty("/materials", {});
                            // If called by Table (valueHelp); not SearchField
                            if (oControl.mProperties.hasOwnProperty("visibleRowCount")) {
                                oControl.setNoData("No data");
                            }
                        }
                        // If called by Table (valueHelp); not SearchField
                        if (oControl.mProperties.hasOwnProperty("visibleRowCount")) {
                            oController._oValueHelpDialog.update();
                        }
                        //oControl.getBinding().refresh(); // if usage of suggestionItems
                    },
                    error: function (err) {
                        MessageToast.show("Error searching for materials");
                    }
                });
            }
            // if usage of suggestionItems
            // this.oSF.getBinding("suggestionItems").filter(aFilters);
            // this.oSF.suggest();
        },

        getPlants: function (sMaterial) {
            var oModel = this.getView().getModel(); // event.getSource().
            var oController = this;
            if (sMaterial !== "") {
                var RequestContent = {
                    "SLS_LORD_GET_VALUES_WERKS": {
                        "IV_MATNR": sMaterial,
                        "IV_MATNR_LONG": "",
                        "IV_SPART": "",
                        "IV_VKORG": "",
                        "IV_VTWEG": ""
                    }
                };
                $.ajax({
                    type: "POST",
                    contentType: "application/json",
                    url: this._getCPIRuntimeBaseURL() + "/SLS_LORD_GET_VALUES_WERKS",
                    data: JSON.stringify(RequestContent),
                    success: function (result, xhr, data) {
                        var oResponse = JSON.parse(result);
                        oModel.setProperty("/plants", oResponse["SLS_LORD_GET_VALUES_WERKS.Response"].ET_HELPVALUE.item);
                    },
                    error: function (err) {
                        MessageToast.show("Error getting material details");
                    }
                });
            }

        },

        getMaterialDetails: function (event) {
            var oModel = this.getView().getModel();
            var sMaterial = oModel.getProperty("/item/MATERIAL");
            if (sMaterial !== "") {
                var RequestContent = {
                    "BAPI_MATERIAL_GET_DETAIL": {
                        "MATERIAL": sMaterial,
                        "MATERIAL_EVG": {
                            "MATERIAL_EXT": "",
                            "MATERIAL_VERS": "",
                            "MATERIAL_GUID": ""
                        },
                        "MATERIAL_LONG": "",
                        "PLANT": oModel.getProperty("/item/PLANT"), //0001
                        "VALUATIONAREA": oModel.getProperty("/item/PLANT"), //0001
                        "VALUATIONTYPE": ""
                    }
                };
                $.ajax({
                    type: "POST",
                    contentType: "application/json",
                    url: this._getCPIRuntimeBaseURL() + "/PR_MATERIAL_GET_DETAIL",
                    data: JSON.stringify(RequestContent),
                    success: function (result, xhr, data) {
                        var oResponse = JSON.parse(result);
                        var sPurGroupResponded = oResponse["ns0:BAPI_MATERIAL_GET_DETAIL.Response"].MATERIALPLANTDATA.PUR_GROUP;
                        if (sPurGroupResponded !== "") oModel.setProperty("/item/PUR_GROUP", sPurGroupResponded);
                        oModel.setProperty("/item/UNIT", oResponse["ns0:BAPI_MATERIAL_GET_DETAIL.Response"].MATERIAL_GENERAL_DATA.BASE_UOM_ISO);
                        oModel.setProperty("/item/C_AMT_BAPI", oResponse["ns0:BAPI_MATERIAL_GET_DETAIL.Response"].MATERIALVALUATIONDATA.STD_PRICE);
                        oModel.setProperty("/item/CURRENCY", oResponse["ns0:BAPI_MATERIAL_GET_DETAIL.Response"].MATERIALVALUATIONDATA.CURRENCY);
                    },
                    error: function (err) {
                        MessageToast.show("Error getting material details");
                    }
                });
            }
        },

        onValueHelpRequested: function (oEvent) {
            this.fnCreateFragment();
        },

        fnCreateFragment: function () {
            console.log(this.getView().getModel().getData());
            var aCols = this.getView().getModel().getData().cols;

            this._oBasicSearchField = new SearchField({
                showSearchButton: false
            });

            this._oValueHelpDialog = sap.ui.xmlfragment("sap.ibpm.CreatePR.fragments.BusinessValueHelp", this);
            this.getView().addDependent(this._oValueHelpDialog);

            // Filter Configuration 
            var oFilterBar = this._oValueHelpDialog.getFilterBar();
            oFilterBar.setFilterBarExpanded(false);
            oFilterBar.setBasicSearch(this._oBasicSearchField);

            // Binding  Data to the Table 
            this._oValueHelpDialog.getTableAsync().then(function (oTable) {
                oTable.setModel(this.getView().getModel());

                var oNewModel = new JSONModel();
                oNewModel.setData({
                    cols: aCols
                });
                oTable.setModel(oNewModel, "columns");

                if (oTable.bindRows) {
                    oTable.bindAggregation("rows", "/materials");
                }

                if (oTable.bindItems) {

                    oTable.bindAggregation("items", "/materials", function () {
                        return new ColumnListItem({
                            cells: aCols.map(function (column) {
                                return new Label({
                                    text: "{" + column.template + "}"
                                });
                            })
                        });
                    });
                }
                this._oValueHelpDialog.update();
            }.bind(this));
            // this.closeBusyDialog();  // Todo: if desired
            this._oValueHelpDialog.open();

        },

        onValueHelpOkPress: function (oEvent) {

            var oThisController = this;
            var aTokens = oEvent.getParameter("tokens");
            var text = aTokens[0].getText();
            var key = aTokens[0].getKey();

            this.getView().getModel().setProperty("/item/MATERIAL", key);
            this.getView().getModel().setProperty("/item/SHORT_TEXT", text);

            this.getPlants(key);

            this._oValueHelpDialog.close();
        },

        onValueHelpCancelPress: function () {
            this._oValueHelpDialog.close();
            this.getView().getModel().refresh();
        },

        onValueHelpAfterClose: function () {
            this._oValueHelpDialog.destroy();
        },

        onFilterBarSearch: function (oEvent) {
            var sSearchQuery = this._oBasicSearchField.getValue(),
                aSelectionSet = oEvent.getParameter("selectionSet");
            var oValueHelpDialog = this._oValueHelpDialog;
            var oThisController = this;

            oValueHelpDialog.getTableAsync().then(function (oTable) {

                oThisController.searchMaterial(sSearchQuery, oTable, oThisController);

            });
        },

        _filterTable: function (oFilter) {
            var oValueHelpDialog = this._oValueHelpDialog;

            oValueHelpDialog.getTableAsync().then(function (oTable) {
                if (oTable.bindRows) {
                    oTable.getBinding("rows").filter(oFilter);
                }

                if (oTable.bindItems) {
                    oTable.getBinding("items").filter(oFilter);
                }

                oValueHelpDialog.update();
            });
        },

        // Add item to cart/collection (table)
        // ToDo: More input validations, currently just date-check
        addItem: function (evt) {
            var oModel = evt.getSource().getModel();
            var Context = oModel.getData();
            var oItem = Context.item;

            // Prepare check date format
            var sDelDate = this.getView().byId("DTP6").getValue();
            var oDelDate = new Date(sDelDate);

            // Check mandatory fields
            if (oItem.MATERIAL === "" || oItem.C_AMT_BAPI === "" || oItem.PLANT === "") {
                MessageToast.show("Please enter at least material, plant and price");
            } else if (oDelDate == "Invalid Date" && isNaN(sDelDate) || sDelDate === "") {
                // At this point keep regular date + allow input of just numbers (format for API)
                MessageToast.show("Please enter valid date format");
            } else { // Case: valid item input
                oModel.getProperty("/itemsToOrder").push(oItem);
                oModel.refresh();

                this.initializeItem();
            }

        },

        deleteItem: function (oEvent) {
            var sPath = oEvent.getParameter('listItem').getBindingContext().getPath();
            // Get the index of the selected item/row in the array
            var idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));
            this.getView().getModel().getProperty("/itemsToOrder").splice(idx, 1);

            this.getView().getModel().refresh();
        },

        // Create PR (Without csrf-projection / Basic Auth)
        onPost: function (evt) {
            var oModel = evt.getSource().getModel();
            var Context = oModel.getData();

            var aItems = oModel.getProperty("/itemsToOrder");
            // Prepare Request for PR creation
            var RequestContent = {
                BAPI_REQUISITION_CREATE: Context.BAPI_REQUISITION_CREATE
            };
            RequestContent.BAPI_REQUISITION_CREATE.REQUISITION_ITEMS.item = []; //[0] = oItem;
            //RequestContent.BAPI_REQUISITION_CREATE.REQUISITION_ITEMS.item[0].DELIV_DATE = sABAPDate;

            aItems.forEach(oItem => {
                // Format date to format without slashes
                var sDelDate = oItem.DELIV_DATE;
                var sABAPDate;
                var oDelDate = new Date(sDelDate);
                if (oDelDate == "Invalid Date") {   // Already in format of just numbers (cp. check in addItem)
                    sABAPDate = sDelDate;
                } else {
                    var sMonth = (oDelDate.getMonth() + 1).toString();
                    sMonth = sMonth.length != 1 ? sMonth : "0" + sMonth;
                    var sDate = oDelDate.getDate().toString();
                    sDate = sDate.length != 1 ? sDate : "0" + sDate;
                    sABAPDate = "" + oDelDate.getFullYear() + sMonth + sDate;
                }

                oItem.DELIV_DATE = sABAPDate;

                // Add requestor to PR request (assignment in system)
                var sRequestorName = Context.subm.Name;
                oItem.CREATED_BY = sRequestorName;
                oItem.PREQ_NAME = sRequestorName;
                oItem.DOC_TYPE = "NB";
                oItem.REQ_BLOCKED = "3"
                //RequestContent.BAPI_REQUISITION_CREATE.REQUISITION_ITEMS.item[0].PREQ_NAME = sRequestorName;

                RequestContent.BAPI_REQUISITION_CREATE.REQUISITION_ITEMS.item.push(oItem);

            });

            var oController = this;
            $.ajax({
                type: "POST",
                contentType: "application/json",
                url: this._getCPIRuntimeBaseURL() + "/PURCHASE_REQUISITION_CREATE",
                data: JSON.stringify(RequestContent),
                success: function (result, xhr, data) {
                    // Request successfull, but creation could still fail (Type 'E')
                    if (JSON.parse(result).RESPONSE.RETURN.TYPE === "I") {
                        var sRequisitionNumber = JSON.parse(result).RESPONSE.NUMBER;
                        Context.Request.BAPI_REQUISITION_GETDETAIL.NUMBER = sRequisitionNumber;
                        // Context.Request.BAPI_REQUISITION_GETDETAIL.PurchaseRequest = { "DocumentId": sRequisitionNumber};
                        MessageToast.show("Purchase requisition created with number: " + sRequisitionNumber);
                        oController.onSubmit(Context);
                        oModel.setProperty("/itemsToOrder", []);
                        //oController.initializeItem();
                    } else {
                        MessageToast.show("There is a problem creating the order: " + JSON.parse(result).RESPONSE.RETURN.MESSAGE);
                    }
                },
                error: function (err) {
                    MessageToast.show("Error submiting the request");
                }
            });
        },

        // Create PR (With csrf-projection / OAuth); just in basic state (correct csrf-request)
        onPost2: function (evt) {
            var Context = evt.getSource().getModel().getData();
            Context.BAPI_REQUISITION_CREATE.REQUISITION_ITEMS.item[0] = Context.item;
            var RequestContent = {
                BAPI_REQUISITION_CREATE: Context.BAPI_REQUISITION_CREATE
            };
            // First get the CSRF token
            $.ajax({
                url: this._getCPIRuntimeBaseURL() + "/PURCHASE_REQUISITION_CREATE",
                type: "HEAD",
                headers: {
                    "x-csrf-token": "Fetch"
                },
                success: function (result, xhr, data) {
                    var token = result.getResponseHeader("x-csrf-token");
                    $.ajax({
                        type: "POST",
                        contentType: "application/json",
                        url: this._getCPIRuntimeBaseURL() + "/PURCHASE_REQUISITION_CREATE",
                        data: JSON.stringify(RequestContent),
                        headers: {
                            "x-csrf-token": token
                        },
                        success: function (result2, xhr2, data2) {
                            // MessageToast.show("Request submited with success");
                        },
                        error: function (err) {
                            MessageToast.show("Error submiting the request");
                        }
                    });
                },
                error: function (result, xhr, data) {
                    var token = result.getResponseHeader("x-csrf-token");
                    $.ajax({
                        type: "POST",
                        contentType: "application/json",
                        url: this._getCPIRuntimeBaseURL() + "/PURCHASE_REQUISITION_CREATE",
                        data: JSON.stringify(RequestContent),
                        headers: {
                            "x-csrf-token": token
                        },
                        success: function (result2, xhr2, data2) {
                            MessageToast.show("Request submited with success");
                        },
                        error: function (err) {
                            MessageToast.show("Error submiting the request");
                        }
                    });
                }
            });
        },

        _getCPIRuntimeBaseURL: function () {
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = jQuery.sap.getModulePath(appPath);

            return appModulePath + "/cpidest/http";
        },



        // Start Workflow
        onSubmit: function (Context) {
            // var Context = evt.getSource().getModel().getData();
            // Context.Request.BAPI_REQUISITION_GETDETAIL.Requestor = Context.subm;

            // Prepare Start-Context for WF
            var RequestContent = {
                PurchaseRequest: {}
            };
            var sRequisitionNumber = Context.Request.BAPI_REQUISITION_GETDETAIL.NUMBER;
            RequestContent.PurchaseRequest = { "DocumentId": sRequisitionNumber };
            RequestContent.PurchaseRequest.Requestor = Context.subm;
            var token;
            var self = this;
            $.ajax({
                url: self._getRuntimeBaseURL() + "/bpmworkflowruntime/v1/xsrf-token",
                method: "GET",
                async: false,
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success: function (result, xhr, data) {
                    token = data.getResponseHeader("X-CSRF-Token");
                    $.ajax({
                        type: "POST",
                        contentType: "application/json",
                        headers: {
                            "X-CSRF-Token": token
                        },
                        url: self._getRuntimeBaseURL() + "/bpmworkflowruntime/v1/workflow-instances",
                        data: JSON.stringify({
                            // definitionId: "initializepurchaserequisitionapproval.create_line_item_workflow",
                            // definitionId: "createlineitemworkflow",
                            definitionId: "InitializePurchaseRequisitionApprovalProcess",
                            context: RequestContent
                        }),
                        success: function (result2, xhr2, data2) {
                            // MessageToast.show("Workflow started with success");
                        },
                        error: function (err) {
                            MessageToast.show("Error submiting the request");
                        }
                    });
                }
            });
        }

    });
});