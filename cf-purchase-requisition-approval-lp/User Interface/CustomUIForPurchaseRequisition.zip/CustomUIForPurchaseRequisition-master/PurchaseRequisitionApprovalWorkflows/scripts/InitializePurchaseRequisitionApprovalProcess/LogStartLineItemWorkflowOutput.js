
var workflowOutput = $.context.local.WorkflowPayload.Response;
var currentIndex = $.context.local.ItemIndex;

$.context.WorkflowCalls.StartLineItemWorkflow[currentIndex].Output = workflowOutput;