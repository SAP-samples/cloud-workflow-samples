var allItems = $.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ITEMS.item;
var allAccountAssignments = $.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ACCOUNT_ASSIGNMENT.item;
var lineItems = [];
var netAmount = 0;

(Array.isArray(allItems)) ? (lineItems = allItems) : (lineItems.push(allItems));
var i = 0;
$.context.AllItemsDeleted = true;
var AllItemsDeleted = true;
for (i = 0; i < lineItems.length; i++) {
     if(lineItems[i].DELETE_IND !="X") // Items which are deleted
    {
        $.context.AllItemsDeleted = false;
        AllItemsDeleted = false;
        lineItems[i].C_AMT_BAPI = parseFloat(lineItems[i].C_AMT_BAPI);
        lineItems[i].QUANTITY = parseFloat(lineItems[i].QUANTITY);
        netAmount += lineItems[i].C_AMT_BAPI*lineItems[i].QUANTITY;
    }
}

if(!AllItemsDeleted)//!$.context.AllItemsDeleted)
{
    var PRHeaderInfo = {
        "DocumentType": lineItems[0].DOC_TYPE,
        "Value": netAmount
    };


    var rulesPayload = {
        Request: {
        "RuleServiceId": "f475652fc38947ae9c33eeb1fe758704",
        "RuleServiceRevision": "2108",
        "Vocabulary": [ { "PurchaseRequisitionHeader": PRHeaderInfo} ]
    }
    };

    $.context.DeterminePOCreation = rulesPayload;
    // used to create PO Subflow input parameters in the script task
    $.context.PRHeaderInfo = PRHeaderInfo;
}