var LineItem = {
    "Value": $.context.WorkflowPayload.context.NetAmount,
    "DocumentType": $.context.WorkflowPayload.context.DocumentType,
    "PurchasingOrganisation": $.context.WorkflowPayload.context.PurchasingOrg,
    "RequisitionDate": $.context.WorkflowPayload.context.RequisitionDate
};

var rulesPayload = {
    "RuleServiceId": "a71385672eee43898320c350b70aad51",
    "RuleServiceRevision": "2108",
    "Vocabulary": [{ "PurchaseRequisitionHeader": LineItem }]
};

$.context.RulesInputPayload = rulesPayload;