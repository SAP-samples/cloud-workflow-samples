

var LineItem = {
    "NetAmount": $.context.local.WorkflowPayload.context.NetAmount,
    "DocumentType": $.context.local.WorkflowPayload.context.LineItem.DOC_TYPE,
    "MaterialGroup": $.context.local.WorkflowPayload.context.LineItem.MAT_GRP,
    "PurchasingGroup": $.context.local.WorkflowPayload.context.LineItem.PUR_GROUP,
    "Plant": $.context.local.WorkflowPayload.context.LineItem.PLANT,
    "PurchasingOrg": $.context.local.WorkflowPayload.context.LineItem.PURCH_ORG,
    "RequisitionDate": $.context.local.WorkflowPayload.context.LineItem.PREQ_DATE,
    "Currency": $.context.local.WorkflowPayload.context.LineItem.CURRENCY,
    "AccountAssignment": $.context.local.WorkflowPayload.context.AccountAssignment
};

var rulesPayload = {
    "RuleServiceId": "75cb397bbe3a48eea5a1433a023ad4c1",
    "RuleServiceRevision": "2108",
    "Vocabulary": [{ "PurchaseRequistionLineItem": LineItem }]
};

if (!($.context.BusinessRules.DetermineWorkflowTemplateForLineItemApproval)) {
    $.context.BusinessRules.DetermineWorkflowTemplateForLineItemApproval = [];
}

$.context.local.lastDetermineWFTRuleInput = rulesPayload;

var ruleInput = {
    RuleInput: rulesPayload
}
$.context.BusinessRules.DetermineWorkflowTemplateForLineItemApproval.push(ruleInput);