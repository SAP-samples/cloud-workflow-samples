
var resultArray = $.context.DetermineBusinessApprovalRule.Response.Result;

if (resultArray.length > 0) {
    $.context.isBusinessApprovalsNeeded = resultArray[0].ProcurementApproval;
} else {
    $.context.isBusinessApprovalsNeeded = false;
}