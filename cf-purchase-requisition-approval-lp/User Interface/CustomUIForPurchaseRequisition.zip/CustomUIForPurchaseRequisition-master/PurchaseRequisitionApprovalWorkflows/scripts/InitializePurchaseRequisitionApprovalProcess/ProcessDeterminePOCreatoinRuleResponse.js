
var resultArray = $.context.DeterminePOCreation.Response.Result;

if (resultArray.length > 0) {
    $.context.DeterminePOCreation.isPOCreationRequired = resultArray[0].PurchaseOrderCreation;
} else {
    $.context.DeterminePOCreation.isPOCreationRequired = false;
}