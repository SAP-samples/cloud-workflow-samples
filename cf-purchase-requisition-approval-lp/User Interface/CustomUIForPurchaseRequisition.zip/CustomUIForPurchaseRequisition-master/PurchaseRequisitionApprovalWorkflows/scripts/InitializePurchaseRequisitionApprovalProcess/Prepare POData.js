
var workflowPayload={}
workflowPayload.definitionId = "approveandcreatepurchaseorder_leadingworkflow";
workflowPayload={};
workflowPayload.PurchaseRequisition={};


var confirmationMessage = {
  "context": {
      "PurchaseOrderIds" : "",
      "description": "Purchase Order  Created"
  },
  "definitionId": "ConfirmPOCreation",
  "workflowDefinitionId": "InitializePurchaseRequisitionApprovalProcess",
  "businessKey": $.context.PurchaseRequest.DocumentId
};


workflowPayload.PurchaseRequisition.DocumentId =  $.context.PurchaseRequest.DocumentId;
workflowPayload.PurchaseRequisition.DocumentType = $.context.PRHeaderInfo.DocumentType
workflowPayload.PurchaseRequisition.TotalNetValue = $.context.PRHeaderInfo.Value;
workflowPayload.PurchaseRequisition.POConfirmation = confirmationMessage;
workflowPayload.History= [];
workflowPayload.Status="";
$.context.POCreationWorkflowPayload= workflowPayload;

