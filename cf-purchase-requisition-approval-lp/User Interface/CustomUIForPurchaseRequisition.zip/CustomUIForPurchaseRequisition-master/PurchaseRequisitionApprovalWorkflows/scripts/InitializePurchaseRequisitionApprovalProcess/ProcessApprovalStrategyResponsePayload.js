var resultArray = $.context.BusinessRules.PurchaseRequisitionApprovalStrategy.RuleOutput.Result;

if (resultArray.length > 0) {
    $.context.local.ApprovalStrategy = resultArray[0].ApprovalStrategy.ApprovalStrategy;
} else {
    $.context.local.ApprovalStrategy = "";
}