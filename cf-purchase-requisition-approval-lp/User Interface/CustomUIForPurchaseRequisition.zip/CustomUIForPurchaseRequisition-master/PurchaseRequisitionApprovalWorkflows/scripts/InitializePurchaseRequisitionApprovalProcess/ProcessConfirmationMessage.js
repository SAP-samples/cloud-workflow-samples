
var lineItemsConfirmed = 0;

if ($.context.LineItemsConfirmed) {
    lineItemsConfirmed = $.context.LineItemsConfirmed;
}

lineItemsConfirmed += 1;

$.context.LineItemsConfirmed = lineItemsConfirmed;

if ($.context.LineItemsConfirmed == $.context.LineItemCount) {
    $.context.allLineItemsApproved = true;
} else {
    $.context.allLineItemsApproved = false;
}

var itemCount = $.context.WorkflowCalls.StartLineItemWorkflow.length;
for(var i = 0; i< itemCount;i++)
{
   if($.context.WorkflowCalls.StartLineItemWorkflow[i].Input.context.LineItem.PREQ_ITEM == $.context.LineItemConfirmation.itemId)
     $.context.WorkflowCalls.StartLineItemWorkflow[i].confirmationMessage = $.context.LineItemConfirmation
}
