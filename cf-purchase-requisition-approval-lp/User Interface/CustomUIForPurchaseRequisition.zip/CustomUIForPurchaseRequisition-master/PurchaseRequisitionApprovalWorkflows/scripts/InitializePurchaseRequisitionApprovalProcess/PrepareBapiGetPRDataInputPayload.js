$.context.local = {};

var prGetDetailsPayload = {
    "BAPI_REQUISITION_GETDETAIL": {
        "NUMBER": $.context.PurchaseRequest.DocumentId
    }
}

$.context.BAPICalls = {};
$.context.BAPICalls.BAPI_REQUISITION_GETDETAIL = {};

$.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Request = prGetDetailsPayload;