var itemIndex = $.context.local.ItemIndex;
var itemListSize = null;
var allItems = $.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ITEMS.item;
var allAccountAssignments = $.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ACCOUNT_ASSIGNMENT.item;
var lineItems = [];
var accountAssignment = {};
var accountAssignmentsList = [];
var lineItemAccountAssignments = [];

if (itemIndex === undefined) {
    itemIndex = -1;
}
itemIndex += 1;

(Array.isArray(allItems)) ? (lineItems = allItems) : (lineItems.push(allItems));
itemListSize = lineItems.length - 1;

$.context.LineItemCount = lineItems.length;

if (allAccountAssignments != null) {
    (Array.isArray(allAccountAssignments)) ? (accountAssignmentsList = allAccountAssignments) : (accountAssignmentsList.push(allAccountAssignments));
    var i = 0;
    for (i = 0; i < accountAssignmentsList.length; i++) {
        if (accountAssignmentsList[i].PREQ_ITEM === lineItems[itemIndex].PREQ_ITEM) {
            lineItemAccountAssignments.push(accountAssignmentsList[i]);
        }
    }
}
lineItems[itemIndex].AccountAssignments = lineItemAccountAssignments;
lineItems[itemIndex].C_AMT_BAPI = parseFloat(lineItems[itemIndex].C_AMT_BAPI);
lineItems[itemIndex].QUANTITY = parseFloat(lineItems[itemIndex].QUANTITY);
var netAmount = lineItems[itemIndex].QUANTITY * lineItems[itemIndex].C_AMT_BAPI;

var WFBackendConfig = "";
if (lineItems[itemIndex].REQ_BLOCKED == "3") {
    WFBackendConfig = "RB";
} else {
    WFBackendConfig = "RS";
}

var businessKey = lineItems[itemIndex].PREQ_NO + " " + lineItems[itemIndex].PREQ_ITEM;

var Item = {
    BusinessKey: businessKey,
    LineItem: lineItems[itemIndex],
    NetAmount: netAmount,
    Requestor: $.context.PurchaseRequest.Requestor,
    DocumentId: $.context.PurchaseRequest.DocumentId,
    ApprovalSteps: [],
    ConfirmationMessage: {},
    RequestDetails: {
        AccountAssignment: accountAssignment,
        workflowTerminated: false,
        WFBackendConfig: WFBackendConfig,
    }
};

var lineItem = {
    definitionId: "",
    PRDeliveryDate: $.context.local.PRDeliveryDate,
    context: Item
};

$.context.local.WorkflowPayload = lineItem;

if (itemIndex === itemListSize) {
    $.context.local.isLastItem = true;
} else {
    $.context.local.isLastItem = false;
}
$.context.local.ItemIndex = itemIndex;