 var allItems = $.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ITEMS.item;
var allAccountAssignments = $.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ACCOUNT_ASSIGNMENT.item;
var lineItems = [];
var accountAssignmentsList = [];
var netAmount = 0;
var headerItems = [];

(Array.isArray(allItems)) ? (lineItems = allItems) : (lineItems.push(allItems));
var i = 0;
$.context.AllItemsDeleted = true;
for (i = 0; i < lineItems.length; i++) {
    if(lineItems[i].DELETE_IND !="X") // Items which are not deleted      //lineItems.splice(i,1);
    {
        $.context.AllItemsDeleted = false;
        lineItems[i].C_AMT_BAPI = parseFloat(lineItems[i].C_AMT_BAPI);
        lineItems[i].QUANTITY = parseFloat(lineItems[i].QUANTITY);
        netAmount += lineItems[i].C_AMT_BAPI*lineItems[i].QUANTITY;
        headerItems.push(lineItems[i]);
    }
 
}
if(headerItems.length >0) // skip if no items for approval
{
    $.context.PurchaseRequest.NetAmount = netAmount;
    (Array.isArray(allAccountAssignments) && allAccountAssignments.length > 0) ? (accountAssignmentsList = allAccountAssignments) : (accountAssignmentsList.push(allAccountAssignments));

    var WFBackendConfig = "";
    if (lineItems[0].REQ_BLOCKED == "3") {
        WFBackendConfig = "RB";
    } else {
        WFBackendConfig = "RS";
    }

    var Item = {
        BusinessKey: $.context.PurchaseRequest.DocumentId,
        ItemsCurrent : headerItems,
        DocumentId: $.context.PurchaseRequest.DocumentId,
        // AccountAssignment : accountAssignmentsList,
        // workflowTerminated : false,
        NetAmount : netAmount,
        DocumentType : headerItems[0].DOC_TYPE,
        PurchasingOrg : headerItems[0].PURCH_ORG,
        RequisitionDate : headerItems[0].PREQ_DATE,
        Requestor : $.context.PurchaseRequest.Requestor,
        PRDeliveryDate : $.context.PRDeliveryDate,
        ConfirmationMessage: {},
        AllComments: [],
        RequestDetails: {
            AccountAssignment: accountAssignmentsList,
            workflowTerminated: false,
            WFBackendConfig: WFBackendConfig,
        }    
        // RequestDetails: {
        //     AccountAssignment: accountAssignmentsList,
        //     workflowTerminated: false,
        //     WFBackendConfig: WFBackendConfig,
        // }
    };

    var lineItem = {
            definitionId: "",
            context: Item
    };

    $.context.WorkflowPayload = lineItem;

    var commentsArray= [];
    $.context.ApproverComments = commentsArray;
    $.context.Step = {};

    delete $.context.Request;
    delete $.context.Response;
    delete $.context.ApprovalStrategyRule;
}
