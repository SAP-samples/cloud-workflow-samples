var allItems = $.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ITEMS.item;
var lineItems = [];

(Array.isArray(allItems)) ? (lineItems = allItems) : (lineItems.push(allItems));

//get latest delivery date
var d1 = Date.parse(lineItems[0].DELIV_DATE);
var deliveryDate = Date.parse(lineItems[0].DELIV_DATE);
var latestDate = lineItems[0].DELIV_DATE;

var i = 0;
var netAmount = 0;
for (i = 0; i < lineItems.length; i++) {
    d1 = Date.parse(lineItems[i].DELIV_DATE);
    if (d1 > deliveryDate) {
        deliveryDate = d1;
        latestDate = lineItems[i].DELIV_DATE;
    }
    lineItems[i].C_AMT_BAPI = parseFloat(lineItems[i].C_AMT_BAPI);
    lineItems[i].QUANTITY = parseFloat(lineItems[i].QUANTITY);
	netAmount += lineItems[i].C_AMT_BAPI*lineItems[i].QUANTITY;
}
$.context.local.PRDeliveryDate = latestDate;
$.context.PurchaseRequest.NetAmount = netAmount;

var PurchaseRequisitionHeader = {
    "DocumentType": lineItems[0].DOC_TYPE,
    "PurchasingOrganisation": lineItems[0].PURCH_ORG,
    "RequisitionDate": lineItems[0].PREQ_DATE
};

var rulesPayload = {
    "RuleServiceId": "34b459aa873345429d894f4ac8f0b968",
    "RuleServiceRevision": "2108",
    "Vocabulary": [{ "PurchaseRequisitionHeader": PurchaseRequisitionHeader }]
};

if (!($.context.BusinessRules)) {
    $.context.BusinessRules = {};
}

if (!($.context.BusinessRules.PurchaseRequisitionApprovalStrategy)) {
    $.context.BusinessRules.PurchaseRequisitionApprovalStrategy = {};
}

$.context.BusinessRules.PurchaseRequisitionApprovalStrategy.RuleInput = rulesPayload;