var resultArray = $.context.local.lastDetermineWFTRuleOutput.Result;

if (resultArray.length > 0) {
    $.context.local.WorkflowPayload.definitionId = resultArray[0].WorkflowTemplate.workflowDefinitionId;
    $.context.local.WorkflowPayload.context.RequestDetails.ITResponsibleGroupName = resultArray[0].WorkflowTemplate.ITResponsibleGroupName;
    $.context.local.WorkflowPayload.context.RequestDetails.ITResponsibleGroupEmail = resultArray[0].WorkflowTemplate.ITResponsibleGroupEmail;
}

var currentIndex = $.context.local.ItemIndex;

$.context.BusinessRules.DetermineWorkflowTemplateForLineItemApproval[currentIndex].RuleOutput = resultArray;

if (!($.context.WorkflowCalls)) {
    $.context.WorkflowCalls = {};
}

if (!($.context.WorkflowCalls.StartLineItemWorkflow)) {
    $.context.WorkflowCalls.StartLineItemWorkflow = [];
   }

var workflowInput = {
    Input: $.context.local.WorkflowPayload
}

$.context.WorkflowCalls.StartLineItemWorkflow.push(workflowInput);
