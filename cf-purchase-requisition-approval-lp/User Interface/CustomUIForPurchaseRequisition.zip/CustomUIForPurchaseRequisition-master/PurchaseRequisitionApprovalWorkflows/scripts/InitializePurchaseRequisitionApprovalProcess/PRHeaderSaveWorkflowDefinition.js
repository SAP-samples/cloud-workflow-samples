var resultArray = $.context.ApprovalWorkflow.Result;

if (resultArray.length > 0) {
    $.context.WorkflowPayload.definitionId = resultArray[0].WorkflowTemplate.workflowDefinitionId;
    $.context.WorkflowPayload.context.RequestDetails.ITResponsibleGroupName = resultArray[0].WorkflowTemplate.ITResponsibleGroupName;
    $.context.WorkflowPayload.context.RequestDetails.ITResponsibleGroupEmail = resultArray[0].WorkflowTemplate.ITResponsibleGroupEmail;
}
var commentsArray= [];
$.context.ApproverComments = commentsArray;

$.context.Step = {};