var allItems = $.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ITEMS.item;
var allAccountAssignments = $.context.BAPICalls.BAPI_REQUISITION_GETDETAIL.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ACCOUNT_ASSIGNMENT.item;
var lineItems = [];
var netAmount = 0;

(Array.isArray(allItems)) ? (lineItems = allItems) : (lineItems.push(allItems));
var i = 0;
for (i = 0; i < lineItems.length; i++) {
    lineItems[i].C_AMT_BAPI = parseFloat(lineItems[i].C_AMT_BAPI);
    lineItems[i].QUANTITY = parseFloat(lineItems[i].QUANTITY);
	netAmount += lineItems[i].C_AMT_BAPI*lineItems[i].QUANTITY;
}

var prHeaderInfo = {
    "DocumentType": lineItems[0].DOC_TYPE,
    "Value": netAmount
};


var rulesPayload = {
    Request: {
    "RuleServiceId": "6f38a97780d24208842f0034845b9e2b",
	"RuleServiceRevision": "2108",
	"Vocabulary": [ { "PurchaseRequisitionHeader": prHeaderInfo} ]
}
};

$.context.DetermineBusinessApprovalRule = rulesPayload;