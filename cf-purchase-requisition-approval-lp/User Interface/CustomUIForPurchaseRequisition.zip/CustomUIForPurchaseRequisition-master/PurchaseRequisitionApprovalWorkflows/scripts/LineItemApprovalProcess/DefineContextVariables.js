var currentApprovalStepIndex = $.context.ApprovalProcessDetails.ApprovalStepIndex;
$.context.StepName = $.context.ApprovalProcessDetails.ApprovalSteps[currentApprovalStepIndex].StepName;
$.context.RoleName = $.context.ApprovalProcessDetails.ApprovalSteps[currentApprovalStepIndex].RoleName;

if (currentApprovalStepIndex === $.context.ApprovalProcessDetails.ApprovalSteps.length - 1) {
    $.context.ApprovalProcessDetails.isLastApprovalStep = true;
} else {
    $.context.ApprovalProcessDetails.isLastApprovalStep = false;
}

$.context.ApprovalProcessDetails.ApprovalStepIndex += 1