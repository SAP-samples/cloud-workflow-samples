var aApprovalSteps = [];

var oCostCenterOwnerApprovalStep = {
    StepName: "CostCenterOwner",
    RoleName: "Cost Center Owner"
}
aApprovalSteps.push(oCostCenterOwnerApprovalStep);

var oGPOApprovalStep = {
    StepName: "GPO",
    RoleName: "GPO"
}
aApprovalSteps.push(oGPOApprovalStep);

$.context.ApprovalProcessDetails = {
    ApprovalSteps: aApprovalSteps,
    ApprovalStepIndex: 0
};

$.context.ApprovalSteps = [];