sap.ui.define([
	"sap/ibpm/ProcessValidationError/test/unit/controller/App.controller"
], function () {
	"use strict";
});
