sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/m/BusyDialog",
    "sap/m/MessagePopover",
    "sap/m/MessageItem",
    "sap/m/Token",
    "sap/m/Label",
    "sap/m/ColumnListItem",
    "sap/m/SearchField",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/comp/filterbar/FilterBar",
    "sap/ui/comp/filterbar/FilterGroupItem",
    "sap/m/Input"
],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    // @ts-ignore
    function (BaseController, JSONModel, MessageBox, MessageToast, BusyDialog, MessagePopover, MessageItem, Token, Label, ColumnListItem, SearchField,
        // @ts-ignore
        Filter, FilterOperator, FilterBar, FilterGroupItem, Input) {
        "use strict";

        return BaseController.extend("sap.ibpm.ApprovePR.controller.App", {
            onInit: function () {
                this.getContentDensityClass();
                this.configureView();
            },

            configureView: function () {

                var startupParameters = this.getComponentData().startupParameters;
                var approveButtonText = this.getMessage("APPROVE");
                var rejectButtonText = this.getMessage("REJECT");

                var oModel = this.getModel(),
                    taskInstanceModel = this.getModel("taskInstanceModel"),
                    sSubject = taskInstanceModel.getData().subject;
                this.byId("approvePageHeader").setObjectTitle(sSubject);

                var oThisController = this;

                /**
                 * APPROVE BUTTON
                 */
                // Implementation for update action
                var oApprove = {
                    sBtnTxt: approveButtonText,
                    onBtnPressed: function () {
                        oModel.refresh(true);
                        var processContext = oModel.getData();

                        // Call a local method to perform further action
                        oThisController._validateInput(
                            processContext,
                            startupParameters.taskModel.getData().InstanceID,
                            "approve"
                        );
                    }
                };

                // Add 'Update' action to the task
                startupParameters.inboxAPI.addAction({
                    // confirm is a positive action
                    action: oApprove.sBtnTxt,
                    label: oApprove.sBtnTxt,
                    type: "Accept"
                },
                    // Set the onClick function
                    oApprove.onBtnPressed);

                /**
                 * REJECT BUTTON
                 */
                // Implementation for reject action
                var oReject = {
                    sBtnTxt: rejectButtonText,
                    onBtnPressed: function () {
                        oModel.refresh(true);
                        var processContext = oModel.getData();

                        // Call a local method to perform further action
                        // oThisController.onProcessComplete(
                        //     processContext,
                        //     startupParameters.taskModel.getData().InstanceID,
                        //     "reject"
                        // );
                        oThisController._validateInput(
                                processContext,
                                startupParameters.taskModel.getData().InstanceID,
                                "reject"
                        );                        
                    }
                };

                // Add 'Reject' action to the task
                startupParameters.inboxAPI.addAction({
                    // confirm is a positive action
                    action: oReject.sBtnTxt,
                    label: oReject.sBtnTxt,
                    type: "Reject"
                },
                    // Set the onClick function
                    oReject.onBtnPressed);

            },
            
            /**
             * Convenience method for all Input validation errors.
             * @public
             * @returns Validate all the required input fields.
             */
            _validateInput: function (processContext, taskId, sDecision) {

                var errorExist = false,
                    oThisController = this,
                    oModel = oThisController.getModel();

                oThisController.getView().setBusy(true);

              
                // Checking comment
                var approverCommentValue = oModel.getProperty("/local/ApproverComment");
                var isAppCommentPresent = approverCommentValue && approverCommentValue.trim() && approverCommentValue !== ""
                    && approverCommentValue !== "undefined" && approverCommentValue !== "null";
                if (!isAppCommentPresent) {
                    var approveCommentsErr = oThisController.getMessage("FIELD_VALIDATION_APPROVER_COMMENTS")
                    errorExist = true;
                    oModel.setProperty("/ApproverCommentState", "Error");
                    oModel.setProperty("/ApproverCommentStateText", approveCommentsErr);
                } else {
                    oModel.setProperty("/ApproverCommentState", "None");
                }

                if (errorExist) {
                    var sGenericErrorText = oThisController.getMessage("FIELD_VALIDATION_ERROR_GENERIC");
                    MessageToast.show(sGenericErrorText)
                    oThisController.getView().setBusy(false);
                    return;
                } else {
                    oThisController.onProcessComplete(processContext, taskId, sDecision);
                }

            },

            /**
             * Convenience method for removing all required Input validation Error.
             * @public
             * @returns Remove errors from value help dialog.
             */
            onChange: function (oEvent) {
                var oThisController = this;
                // @ts-ignore
                var oModel = oThisController.getParentModel();
                var oInput = oEvent.getSource();
                if (oInput.getProperty("value").length > 0 && oInput.getProperty("valueState") === "Error") {
                    oInput.setProperty("valueState", "None");
                    oInput.setProperty("valueStateText", "");
                }

            },

            onProcessComplete: function (processContext, taskId, sDecision) {

                this.setBusy(true);

           
                var oPayload = {
                    // LineItem: processContext.LineItem,
                    local: processContext.local
                }

                var oThisController = this;

                var token;
                // @ts-ignore
                $.ajax({
                    url: oThisController._getRuntimeBaseURL() + "/bpmworkflowruntime/v1/xsrf-token",
                    method: "GET",
                    async: false,
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    // @ts-ignore
                    success: function (result, xhr, data) {
                        token = data.getResponseHeader("X-CSRF-Token");
                        // @ts-ignore
                        $.ajax({
                            type: "PATCH",
                            contentType: "application/json",
                            headers: {
                                "X-CSRF-Token": token
                            },
                            url: oThisController._getRuntimeBaseURL() + "/bpmworkflowruntime/v1/task-instances/" + taskId,
                            data: JSON.stringify({
                                context: oPayload,
                                decision: sDecision,
                                status: "COMPLETED"
                            }),
                            // @ts-ignore
                            success: function (result2, xhr2, data2) {
                                oThisController._refreshTask();
                            },
                            // @ts-ignore
                            error: function (err) {
                                oThisController.setBusy(false);
                                MessageToast.show("Error submiting the request");
                            }
                        });
                    }
                });
            },
            _getRuntimeBaseURL: function () {
                var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
                var appPath = appId.replaceAll(".", "/");
                // @ts-ignore
                var appModulePath = jQuery.sap.getModulePath(appPath);

                return appModulePath;
            },

            // Request Inbox to refresh the control once the task is completed
            _refreshTask: function () {
                var taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
                this.getComponentData().startupParameters.inboxAPI.updateTask("NA", taskId);
                this.setBusy(false);
                console.log("task is refreshed");
            }
        
            

        });
    });
