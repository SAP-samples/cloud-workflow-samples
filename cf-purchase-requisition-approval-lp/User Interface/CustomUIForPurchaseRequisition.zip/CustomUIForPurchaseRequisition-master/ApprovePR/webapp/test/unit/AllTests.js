sap.ui.define([
	"sap/ibpm/ApprovePR/test/unit/controller/App.view.controller"
], function () {
	"use strict";
});
