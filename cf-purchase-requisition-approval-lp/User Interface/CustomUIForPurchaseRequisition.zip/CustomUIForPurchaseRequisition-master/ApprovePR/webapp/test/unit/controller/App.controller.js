/*global QUnit*/

sap.ui.define([
	"sap/ibpm/ApprovePR/controller/App.controller"
], function (Controller) {
	"use strict";

	QUnit.module("App.view Controller");

	QUnit.test("I should test the App.view controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
