var resultArray = $.context.ApprovalStrategyRule.Response.Result;

if (resultArray.length > 0) {
    $.context.ApprovalStrategy = resultArray[0].ApprovalStrategy.ApprovalStrategy;
} else {
    $.context.ApprovalStrategy = "";
}