
 var allItems = $.context.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ITEMS.item;
var allAccountAssignments = $.context.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ACCOUNT_ASSIGNMENT.item;
var lineItems = [];
var accountAssignmentsList = [];
var netAmount = 0;

(Array.isArray(allItems)) ? (lineItems = allItems) : (lineItems.push(allItems));
var i = 0;
for (i = 0; i < lineItems.length; i++) {
	netAmount += parseFloat(lineItems[i].C_AMT_BAPI)*parseFloat(lineItems[i].QUANTITY);
}

(Array.isArray(allAccountAssignments) && allAccountAssignments.length > 0) ? (accountAssignmentsList = allAccountAssignments) : (accountAssignmentsList.push(allAccountAssignments));

var WFBackendConfig = "";
if (lineItems[0].REQ_BLOCKED == "3") {
    WFBackendConfig = "RB";
} else {
    WFBackendConfig = "RS";
}

var Item = {
    ItemsCurrent : lineItems,
    documentId: $.context.PurchaseRequest.DocumentId,
    AccountAssignment : accountAssignmentsList,
    workflowTerminated : false,
    NetAmount : netAmount,
    WFBackendConfig: WFBackendConfig,
	DocumentType : lineItems[0].DOC_TYPE,
	PurchasingOrg : lineItems[0].PURCH_ORG,
	RequisitionDate : lineItems[0].PREQ_DATE,
    Requestor : $.context.PurchaseRequest.Requestor,
    PRDeliveryDate : $.context.PRDeliveryDate
};

var lineItem = {
		definitionId: "",
		context: Item
};

$.context.WorkflowPayload = lineItem;

var commentsArray= [];
$.context.ApproverComments = commentsArray;
$.context.Step = {};

delete $.context.Request;
delete $.context.Response;
delete $.context.ApprovalStrategyRule;
