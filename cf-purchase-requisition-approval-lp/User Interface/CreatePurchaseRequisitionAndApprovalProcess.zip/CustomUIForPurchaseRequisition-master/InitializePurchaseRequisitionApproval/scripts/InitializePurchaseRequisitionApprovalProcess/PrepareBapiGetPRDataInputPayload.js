var prGetDetailsPayload = {
    "BAPI_REQUISITION_GETDETAIL": {
        "NUMBER": $.context.PurchaseRequest.DocumentId
    }    
}
$.context.Request = prGetDetailsPayload;