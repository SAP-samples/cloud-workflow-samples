var itemIndex = $.context.ItemIndex;
var itemListSize = null;
var allItems = $.context.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ITEMS.item;
var allAccountAssignments = $.context.Response.BAPI_REQUISITION_GETDETAIL_RESPONSE.REQUISITION_ACCOUNT_ASSIGNMENT.item;
var lineItems = [];
var accountAssignment = {};
var accountAssignmentsList = [];

if(itemIndex === undefined)
{
    itemIndex = -1;
}
itemIndex += 1;

(Array.isArray(allItems)) ? (lineItems = allItems) : (lineItems.push(allItems));
itemListSize = lineItems.length - 1;

if (allAccountAssignments != null) {
    (Array.isArray(allAccountAssignments)) ? (accountAssignmentsList = allAccountAssignments) : (accountAssignmentsList.push(allAccountAssignments));
    var i = 0;
    for (i = 0; i < accountAssignmentsList.length; i++) {
        if (accountAssignmentsList[i].PREQ_ITEM === lineItems[itemIndex].PREQ_ITEM) {
            accountAssignment.CostCenter = accountAssignmentsList[i].COST_CTR;
        }
    }
}


var price = parseFloat(lineItems[itemIndex].C_AMT_BAPI);
var quantity = parseFloat(lineItems[itemIndex].QUANTITY);
var netAmount = quantity * price;

var WFBackendConfig = "";
if (lineItems[itemIndex].REQ_BLOCKED == "3") {
    WFBackendConfig = "RB";
} else {
    WFBackendConfig = "RS";
}

var businessKey = lineItems[itemIndex].PREQ_NO + " " + lineItems[itemIndex].PREQ_ITEM;

var Item = {
    Item : lineItems[itemIndex],
    AccountAssignment : accountAssignment,
    workflowTerminated : false,
    NetAmount : netAmount,
    Requestor : $.context.PurchaseRequest.Requestor,
    WFBackendConfig: WFBackendConfig,
    documentId: businessKey,
    BusinessKey: businessKey
};

var lineItem = {
        definitionId: "",
        PRDeliveryDate: $.context.PRDeliveryDate,
		context: Item
};

$.context.WorkflowPayload = lineItem;

if (itemIndex === itemListSize) {
	$.context.isLastItem = true;
} else {
	$.context.isLastItem = false;
}
$.context.ItemIndex = itemIndex;