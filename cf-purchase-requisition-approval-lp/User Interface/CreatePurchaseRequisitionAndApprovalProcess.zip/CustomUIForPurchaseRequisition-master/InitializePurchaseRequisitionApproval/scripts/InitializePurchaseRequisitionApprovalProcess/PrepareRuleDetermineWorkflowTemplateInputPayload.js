

var LineItem= {
    "NetAmount":$.context.WorkflowPayload.context.NetAmount,
	"DocumentType": $.context.WorkflowPayload.context.Item.DOC_TYPE,
	"MaterialGroup": $.context.WorkflowPayload.context.Item.MAT_GRP,
	"PurchasingGroup": $.context.WorkflowPayload.context.Item.PUR_GROUP,
	"Plant": $.context.WorkflowPayload.context.Item.PLANT,
    "PurchasingOrg": $.context.WorkflowPayload.context.Item.PURCH_ORG,
    "RequisitionDate": $.context.WorkflowPayload.context.Item.PREQ_DATE,
    "Currency": $.context.WorkflowPayload.context.Item.CURRENCY,
    "AccountAssignment": $.context.WorkflowPayload.context.AccountAssignment
};

var rulesPayload = {
    "RuleServiceId": "75cb397bbe3a48eea5a1433a023ad4c1",
	"RuleServiceRevision": "2008",
	"Vocabulary": [ { "PurchaseRequistionLineItem": LineItem} ]
};

$.context.RulesInputPayload = rulesPayload;