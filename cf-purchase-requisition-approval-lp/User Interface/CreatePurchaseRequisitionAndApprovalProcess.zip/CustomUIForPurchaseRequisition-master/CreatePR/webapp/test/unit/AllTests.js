sap.ui.define([
	"sap/ibpm/CreatePR/test/unit/controller/Main.controller"
], function () {
	"use strict";
});