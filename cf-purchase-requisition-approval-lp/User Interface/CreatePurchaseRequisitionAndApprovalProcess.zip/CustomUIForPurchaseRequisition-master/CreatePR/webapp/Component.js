sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/ibpm/CreatePR/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("sap.ibpm.CreatePR.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			// set Default-Model
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.attachRequestCompleted(function () {
				var oContext = oModel.getData();
				oContext.item = oContext.BAPI_REQUISITION_CREATE.REQUISITION_ITEMS.item[0];
                oContext.subm = oContext.Request.BAPI_REQUISITION_GETDETAIL.Requestor;
                // Copy initial empty item and break binding
                oModel.setProperty("/templateItem", $.extend({},oContext.BAPI_REQUISITION_CREATE.REQUISITION_ITEMS.item[0]));
				//bpModel.setData(bpContext);
            });
            
			//DEV:		oModel.loadData("model/PR_StartApproval.json");					
			oModel.loadData("../sapibpmCreatePR/model/PR_StartApproval.json");
			this.setModel(oModel);
			
			// set rulesModel
			var rulesModel = new sap.ui.model.json.JSONModel();
			var inputPayload = {
			  	'RuleServiceId': 'f06b0ad40c3d434790e888645564ce4c',
			  	'RuleServiceRevision': 'Draft',
			  	'Vocabulary': [{'SearchValueField':{"SF":''}}]
            };

			// First get the CSRF token
			$.ajax({
			    url: "/sapibpmCreatePR/bpmrulesruntime/xsrf-token",
			    method: "GET",
			    headers: {
			      "X-CSRF-Token": "Fetch"
			    },
			    success: function(result, xhr, data) {
			      var token = data.getResponseHeader("X-CSRF-Token");
			       
			       //Then invoke the business rules service via public API
			       $.ajax({
			           url: "/sapibpmCreatePR/bpmrulesruntime/rule-services",
			           method: "POST",
			           contentType: "application/json",
			           data: JSON.stringify(inputPayload),
			           async: false,
			           headers: {
			             "X-CSRF-Token": token
			           },
			           success: function(result1, xhr1, data1) {
			               if (result1 !== null) {
                               var aPurGroups = result1.Result[0].PurchasingGroupDetails;
                               rulesModel.setProperty("/purchasingGroups", aPurGroups);
                               rulesModel.refresh();
			               }
			           }
			       });
			    }
			});		
			rulesModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.setModel(rulesModel, "rulesModel");
		}
	});
});