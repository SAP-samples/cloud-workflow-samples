
var itemOld = {};
var itemNew = {};

if ($.context.WorkflowContext.ItemData.ItemNew === undefined) {
    itemOld = $.context.WorkflowContext.Item;
    itemNew = $.context.WorkflowContext.Item;
} else {
    itemOld = $.context.WorkflowContext.ItemData.ItemOld;
    itemNew = $.context.WorkflowContext.ItemData.ItemNew;
}
itemNew.REQ_BLOCKED = " ";

var requisitionBapiChangeData = {
	"Request": {
		"ItemData" : {
			"ItemOld": itemOld,
			"ItemNew": itemNew
		}		
	}
};

$.context.RequisitionBapiChangeData = requisitionBapiChangeData;


var workflowCancelData = {
	"status" : "CANCELED"
};
$.context.WorkflowCancelRequest = workflowCancelData;