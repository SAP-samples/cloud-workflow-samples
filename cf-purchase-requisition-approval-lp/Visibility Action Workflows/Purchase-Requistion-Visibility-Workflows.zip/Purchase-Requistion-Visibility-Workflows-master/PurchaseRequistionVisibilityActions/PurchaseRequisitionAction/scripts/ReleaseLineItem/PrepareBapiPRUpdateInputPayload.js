

if ($.context.WorkflowContext.ItemNew === undefined) {
    $.context.WorkflowContext.ItemNew = $.context.WorkflowContext.Item;
}
$.context.WorkflowContext.ItemNew.REQ_BLOCKED = " ";

var requisitionBapiChangeData = {
	"Request": {
		"ItemData" : {
			"ItemOld": $.context.WorkflowContext.Item,
			"ItemNew": $.context.WorkflowContext.ItemNew
		}		
	}
};

$.context.RequisitionBapiChangeData = requisitionBapiChangeData;


var workflowCancelData = {
	"status" : "CANCELED"
};
$.context.WorkflowCancelRequest = workflowCancelData;