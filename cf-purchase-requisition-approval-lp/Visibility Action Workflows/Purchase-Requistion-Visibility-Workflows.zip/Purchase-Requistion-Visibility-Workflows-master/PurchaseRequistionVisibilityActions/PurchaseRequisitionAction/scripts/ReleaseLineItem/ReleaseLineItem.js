
var requisitionBapiReleaseData = {
	"Request" : {
        "BAPI_REQUISITION_RELEASE" : {
            ITEM : $.context.WorkflowContext.Item.PREQ_ITEM,
            NO_COMMIT_WORK : "",
            NUMBER : $.context.WorkflowContext.Item.PREQ_NO,
            REL_CODE : "EX",
            USE_EXCEPTIONS : ""
        }
    }
};

$.context.RequisitionBapiReleaseData = requisitionBapiReleaseData;

var workflowCancelData = {
	"status" : "CANCELED"
};
$.context.WorkflowCancelRequest = workflowCancelData;