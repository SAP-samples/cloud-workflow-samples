var item = {};

if ($.context.WorkflowContext.ItemData.ItemNew === undefined) {
    item = $.context.WorkflowContext.Item;
} else {
    item = $.context.WorkflowContext.ItemData.ItemNew;
}

var requisitionBapiReleaseData = {
	"Request" : {
        "BAPI_REQUISITION_RELEASE" : {
            ITEM : item.PREQ_ITEM,
            NO_COMMIT_WORK : "",
            NUMBER : item.PREQ_NO,
            REL_CODE : "EX",
            USE_EXCEPTIONS : ""
        }
    }
};

$.context.WorkflowContext.Item = item;

$.context.RequisitionBapiReleaseData = requisitionBapiReleaseData;

var workflowCancelData = {
	"status" : "CANCELED"
};
$.context.WorkflowCancelRequest = workflowCancelData;