var item = {};
var isHeader = false;
var context = {};

if ($.context.WorkflowContext.ItemData === undefined) {
    if ($.context.WorkflowContext.Item === undefined) {
        if ($.context.WorkflowContext.ItemsCurrent === undefined) {
            throw new Error("Item data not defined in the workflow context");
        } else {
            isHeader = true;
            item = $.context.WorkflowContext.ItemsCurrent[0];
        }
    } else {
        item = $.context.WorkflowContext.Item;
    }
} else {
    item = $.context.WorkflowContext.ItemData.ItemNew;
}

if (isHeader) {
    context = {
        ItemsCurrent: $.context.WorkflowContext.ItemsCurrent,
        documentId: $.context.WorkflowContext.documentId,
        AccountAssignment: $.context.WorkflowContext.AccountAssignment,
        workflowTerminated: $.context.WorkflowContext.workflowTerminated,
        NetAmount: $.context.WorkflowContext.NetAmount,
        WFBackendConfig: $.context.WorkflowContext.WFBackendConfig,
        DocumentType: $.context.WorkflowContext.DocumentType,
        PurchasingOrg: $.context.WorkflowContext.PurchasingOrg,
        RequisitionDate: $.context.WorkflowContext.RequisitionDate,
        Requestor: $.context.WorkflowContext.Requestor,
        PRDeliveryDate: $.context.WorkflowContext.PRDeliveryDate
    };
} else {
    context = {
        Item: item,
        AccountAssignment: $.context.WorkflowContext.AccountAssignment,
        workflowTerminated: false,
        NetAmount: $.context.WorkflowContext.NetAmount,
        Requestor: $.context.WorkflowContext.Requestor,
        WFBackendConfig: $.context.WorkflowContext.WFBackendConfig,
        documentId: $.context.WorkflowContext.documentId,
        BusinessKey: $.context.WorkflowContext.BusinessKey
    };
}


var startWorkflowContext = {
    definitionId: $.context.WorkflowInstanceId.definitionId,
    context: context
};

$.context.NewWorkflowContext = startWorkflowContext;

var workflowCancelData = {
    "status": "CANCELED"
};
$.context.WorkflowCancelRequest = workflowCancelData;