var context = $.context.WorkflowContext;

var startWorkflowContext = {
    definitionId: $.context.WorkflowInstanceId.definitionId,
    context: context
};

$.context.NewWorkflowContext = startWorkflowContext;

var workflowCancelData = {
    "status": "CANCELED"
};
$.context.WorkflowCancelRequest = workflowCancelData;