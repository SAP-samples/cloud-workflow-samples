var item = {};

if ($.context.WorkflowContext.ItemData.ItemNew === undefined) {
    if ($.context.WorkflowContext.Item === undefined) {
        throw new Error("Item data not defined in the workflow context");
    } else {
        item = $.context.WorkflowContext.Item;
    }
} else {
    item = $.context.WorkflowContext.ItemData.ItemNew;
}

var requisitionBapiDeleteRequestData = {
	"Request" : {
		"BAPI_REQUISITION_DELETE": {
            // NUMBER: $.context.WorkflowContext.Item.PREQ_NO,
            NUMBER: item.PREQ_NO,
	        REQUISITION_ITEMS_TO_DELETE: {
	            item: {
                    // PREQ_ITEM: $.context.WorkflowContext.Item.PREQ_ITEM,
                    PREQ_ITEM: item.PREQ_ITEM,
                    DELETE_IND: "X"
	            }
	        }
		}
	}
};

$.context.RequisitionBapiDeleteData = requisitionBapiDeleteRequestData;
$.context.workflowTerminated = true;

var workflowCancelData = {
	"status" : "CANCELED"
};
$.context.WorkflowCancelRequest = workflowCancelData;