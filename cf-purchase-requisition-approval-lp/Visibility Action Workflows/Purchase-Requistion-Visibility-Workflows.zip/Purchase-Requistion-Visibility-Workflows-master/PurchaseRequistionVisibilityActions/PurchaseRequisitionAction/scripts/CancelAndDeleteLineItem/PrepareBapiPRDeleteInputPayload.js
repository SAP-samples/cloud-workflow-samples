var requisitionBapiDeleteRequestData = {
	"Request" : {
		"BAPI_REQUISITION_DELETE": {
		    NUMBER: $.context.WorkflowContext.Item.PREQ_NO,
	        REQUISITION_ITEMS_TO_DELETE: {
	            item: {
                    PREQ_ITEM: $.context.WorkflowContext.Item.PREQ_ITEM,
                    DELETE_IND: "X"
	            }
	        }
		}
	}
};

$.context.RequisitionBapiDeleteData = requisitionBapiDeleteRequestData;
$.context.workflowTerminated = true;

var workflowCancelData = {
	"status" : "CANCELED"
};
$.context.WorkflowCancelRequest = workflowCancelData;