if (!$.context.ItemNew) {
    $.context.ItemNew = $.context.WorkflowContext.LineItem;
}