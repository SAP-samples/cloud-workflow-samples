sap.ui.define(["sap/m/MessageToast", "sap/ui/core/mvc/Controller", "sap/ui/core/Fragment", 
"sap/ui/model/Filter", "sap/ui/model/FilterOperator", "sap/m/BusyDialog", "sap/m/MessageBox"], function(MessageToast, Controller, Fragment, 
    Filter, FilterOperator, BusyDialog, MessageBox) {
                "use strict";
                return Controller.extend("com.sap.cp.dpa.ManagePurchaseInfoRecord.controller.Master", {
                    initialLoad: 0,
                    loader: new sap.m.BusyDialog(),
                    onInit: function() {
                        this.getView().setModel(this.getOwnerComponent().getModel("iModel"), "iModel");
                        this.getView().getModel("iModel").setProperty("/list", {});
                        this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this)
                    },
                    getRouter: function() {
                        return sap.ui.core.UIComponent.getRouterFor(this)
                    },
                    onRouteMatched: function(event) {
                        if (event.getParameter("name") == "Master") {
                            this.getView().byId("idBtnChange").setProperty("enabled", false);
                            this.getView().byId("idPurchaseInfoTable").removeSelections();
                            this.getView().getModel("iModel").refresh(true)
                        }
                    },
                    onAfterRendering: function() {
                        var user = sap.ushell.Container.getService("UserInfo");
                        var name = user.getUser().getEmail();
                        name = name.split("@");
                        name = name[0];
                        var userDetails = {
                            id:name,
                            email:user.getUser().getEmail(),
                            name: user.getUser().getFullName(),
                            UserId: user.getId()
                        }
                        this.getView().getModel("iModel").setProperty("/user", userDetails);
                    },
                    handleValueHelpMaterial: function(material) {
                        this.loader.open();
                        var data = JSON.stringify({
                            Requester: {
                                UserId: this.getView().getModel("iModel").getProperty("/user/id")
                            },
                            Material: material,
                            MaxRows: 100
                        });
                        var sUrl = this._getCPIRuntimeBaseURL() + "/MaterialSearch";
                        $.ajax({
                            url: sUrl,
                            method: "POST",
                            async: false,
                            contentType: "application/json",
                            headers: {},
                            data: data,
                            success: function(res) {
                                this.getView().getModel("iModel").setProperty("/MaterialList", {});
                                if (res.root != "") {
                                    this.getView().getModel("iModel").setProperty("/MaterialList", res.root.Result.length == undefined ? {
                                        0: res.root.Result
                                    } : res.root.Result);
                                    this.getView().getModel("iModel").setProperty("/MaterialListCount",res.root.Result.length == undefined ?
                                        0 : res.root.Result.length);
                                    this.getView().getModel("iModel").refresh(true)
                                } else {
                                    MessageToast.show("No matching data found")
                                    this.getView().getModel("iModel").setProperty("/MaterialList", {});
                                    this.getView().getModel("iModel").setProperty("/MaterialListCount", 0);
                                    this._valueHelpDialogM.setNoDataText("No data")
                                    this.getView().getModel("iModel").refresh(true)
                                }
                                this.loader.close();
                            }
                            .bind(this),
                            error : function(res){
                                this.getView().getModel("iModel").setProperty("/MaterialList", {});
                                this.getView().getModel("iModel").setProperty("/MaterialListCount", 0);
                                this._valueHelpDialogM.setNoDataText("No data")
                                this.getView().getModel("iModel").refresh(true)
                                this.loader.close();

                                    MessageBox.error("Internal Server Error. Please contact your administrator")
                            }.bind(this)
                        })
                    },
                    handleValueHelpM: function(oItem) {
                        this.getView().getModel("iModel").setProperty("/MaterialList", {});
                        this.getView().getModel("iModel").setProperty("/MaterialListCount", 0);
                        this.getView().getModel("iModel").refresh(true)
                        if (!this._valueHelpDialogM) {
                            this._valueHelpDialogM = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.Material", this);
                            this.getView().addDependent(this._valueHelpDialogM)
                        }
                        this._valueHelpDialogM.open();
                        this._valueHelpDialogM.setNoDataText("Please enter value for search");
                    },
                    handleValueHelpSearchMaterial: function(oItem) {
                        var val = oItem.getParameter("value");
                        if(val != ""){
                            this.handleValueHelpMaterial("*"+val+"*");
                        }else{
                            MessageToast.show("Please enter value for search");
                            return;
                        }
                    },
                    _handleValueHelpMClose: function(oItem) {
                        var item = oItem.getParameter("selectedItem");
                        if (item) {
                            var itemEle = this.getView().byId("idInputMaterial");
                            itemEle.setValue(item.getTitle())
                        }
                    },
                    
                    handleValueHelpVendor: function(id,name) {
                        this.loader.open();
                        var data = JSON.stringify({
                            Requester: {
                                UserId: this.getView().getModel("iModel").getProperty("/user/id")
                            },
                            Vendor: id,
                            Name1: name
                        });
                        var sUrl = this._getCPIRuntimeBaseURL() + "/VendorSearch";
                        $.ajax({
                            url: sUrl,
                            method: "POST",
                            async: false,
                            contentType: "application/json",
                            headers: {},
                            data: data,
                            success: function(res) {
                                this.getView().getModel("iModel").setProperty("/VendorList", {});
                               
                                if (res.root != "") {
                                    this.getView().getModel("iModel").setProperty("/VendorList", res.root.Result.length == undefined ? {
                                        0: res.root.Result
                                    } : res.root.Result);
                                    this.getView().getModel("iModel").setProperty("/VendorListCount",res.root.Result.length == undefined ?
                                        0 : res.root.Result.length);
                                    this.getView().getModel("iModel").refresh(true)
                                } else {
                                    if(id != ""){
                                        name = id;
                                        id="";
                                        this.handleValueHelpVendor(id,name)
                                    }else{
                                        this.getView().getModel("iModel").setProperty("/VendorListCount", 0);
                                        this._valueHelpDialogV.setNoDataText("No data")
                                        MessageToast.show("No matching data found")
                                    }
                                    this.getView().getModel("iModel").refresh(true)
                                }
                                this.loader.close();
                            }
                            .bind(this),
                            error : function(res){
                                this.getView().getModel("iModel").setProperty("/VendorList", {});
                                this.getView().getModel("iModel").setProperty("/VendorListCount", 0);
                                this._valueHelpDialogV.setNoDataText("No data")
                                this.getView().getModel("iModel").refresh(true)
                                this.loader.close();
 
                                MessageBox.error("Internal Server Error. Please contact your administrator")
                            }.bind(this)
                        })
                    },
                    handleValueHelpV: function(oItem) {
                        this.getView().getModel("iModel").setProperty("/VendorList", {});
                        this.getView().getModel("iModel").setProperty("/VendorListCount", 0);
                        this.getView().getModel("iModel").refresh(true)
                         if (!this._valueHelpDialogV) {
                            this._valueHelpDialogV = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.Vendor", this);
                            this.getView().addDependent(this._valueHelpDialogV)
                        }
                        this._valueHelpDialogV.open()
                        this._valueHelpDialogV.setNoDataText("Please enter value for search");
                    },
                    handleValueHelpSearchVendor: function(oItem) {
                         var val = oItem.getParameter("value");
                         if(val != ""){
                            this.handleValueHelpVendor("*"+val+"*","");
                         }else{
                             MessageToast.show("Please enter search input");
                             return;
                         }
                    },
                    _handleValueHelpVClose: function(oItem) {
                        var eItem = oItem.getParameter("selectedItem");
                        if (eItem) {
                            var item = this.getView().byId("idInputVendor");
                            item.setValue(eItem.getTitle())
                        }
                    },
                    handleValueHelpMaterialGroup: function(id) {
                        this.loader.open();
                        var data = JSON.stringify({
                            Requester: {
                                UserId: this.getView().getModel("iModel").getProperty("/user/id")
                            },
                            MaterialGroup: ""
                        });
                        var sUrl = this._getCPIRuntimeBaseURL() + "/MaterialGroup";
                        $.ajax({
                            url: sUrl,
                            method: "POST",
                            async: false,
                            contentType: "application/json",
                            headers: {},
                            data: data,
                            success: function(res) {
                                var formatData = {};
                                if (res.root != "") {
                                for (var i = 0; i < res.root.Result.length; i++) {
                                    formatData[res.root.Result[i].MaterialGroup] = res.root.Result[i].Description
                                }
                                this.getView().getModel("iModel").setProperty("/FormattedMaterialGroupList", formatData);
                                this.getView().getModel("iModel").setProperty("/MaterialGroupList", res.root.Result);
                            } else { MessageToast.show("No matching data found") }
                                this.loader.close();
                            }
                            .bind(this),
                            error : function(res){
                                this.getView().getModel("iModel").setProperty("/FormattedMaterialGroupList", {});
                                this.getView().getModel("iModel").setProperty("/MaterialGroupList", {});
                                this.getView().getModel("iModel").refresh(true);
                                this.loader.close();
                                MessageBox.error("Internal Server Error. Please contact your administrator");
                            }.bind(this)
                        })
                    },
                    handleValueHelpMG: function(oItem) {
                        this.getView().getModel("iModel").setProperty("/FormattedMaterialGroupList", {});
                        this.getView().getModel("iModel").setProperty("/MaterialGroupList", {});
                        this.getView().getModel("iModel").setProperty("/MaterialGroupListCount", 0);
                        this.getView().getModel("iModel").refresh(true);
                        if (!this._valueHelpDialogMG) {
                            this._valueHelpDialogMG = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.MaterialGroup", this);
                            this.getView().addDependent(this._valueHelpDialogMG)
                        }
                        this._valueHelpDialogMG.open()
                        this._valueHelpDialogMG.setNoDataText("Please enter value for search")
                    },
                    handleValueHelpSearchMaterialGroup: function(eItem) {
                        var val = eItem.getParameter("value");
                        if(val != ""){
                            this.handleValueHelpMaterialGroup("");
                        }else{
                            MessageToast.show("Please enter search input");
                            return;
                        }
                        if(val.includes("*",0)){
                            val = val.split("*");
                            var valLength = val.length;
                            var preLength = 0;
                            var cval = "";
                            for(var i = 0; i < valLength; i++){
                                if(val[i] != ""){
                                    var currLength = val[i].length;
                                    if(preLength == 0){
                                        preLength = currLength;
                                        cval = val[i]
                                    }else{
                                        if(currLength > preLength){
                                            preLength = currLength;
                                            cval = val[i]
                                        }
                                    }
                                }
                            }
                            val = cval;
                        }                            
                        var filter = [new Filter("MaterialGroup",FilterOperator.Contains,val), new Filter("Description",FilterOperator.Contains,val)];
                        var nFilter = new Filter(filter,false);
                        eItem.getSource().getBinding("items").filter([nFilter])
                        if(eItem.getSource().getBinding("items").iLength == 0){
                            this._valueHelpDialogMG.setNoDataText("No data");
                            MessageToast.show("No matching data found")
                        }
                        this.getView().getModel("iModel").setProperty("/MaterialGroupListCount", eItem.getSource().getBinding("items").iLength);
                    },
                    _handleValueHelpMGClose: function(eItem) {
                        var tItem = eItem.getParameter("selectedItem");
                        if (tItem) {
                            var item = this.getView().byId("idInputMatGroup");
                            item.setValue(tItem.getTitle())
                        }
                        eItem.getSource().getBinding("items").filter([])
                    },
                    handleValueHelpPurchaseOrganization: function(eId) {
                        this.loader.open();
                        var data = JSON.stringify({
                            Requester: {
                                UserId: this.getView().getModel("iModel").getProperty("/user/id")
                            },
                            PurchaseOrganization: ""
                        });
                        var sUrl = this._getCPIRuntimeBaseURL() + "/PurchaseOrganization";
                        $.ajax({
                            url: sUrl,
                            method: "POST",
                            async: false,
                            contentType: "application/json",
                            headers: {},
                            data: data,
                            success: function(eRes) {
                                var tFormat = {};
                                if (eRes.root != "") {
                                for (var a = 0; a < eRes.root.Result.length; a++) {
                                    tFormat[eRes.root.Result[a].PurchaseOrganization] = eRes.root.Result[a].Description
                                }
                                this.getView().getModel("iModel").setProperty("/FormattedPurOrgList", tFormat);
                                this.getView().getModel("iModel").setProperty("/PurOrgList", eRes.root.Result);
                            } else {MessageToast.show("No matching data found")}
                                this.loader.close();   
                            }
                            .bind(this),
                            error : function(res){
                                this.getView().getModel("iModel").setProperty("/FormattedPurOrgList", {});
                                this.getView().getModel("iModel").setProperty("/PurOrgList", {});
                                this.getView().getModel("iModel").refresh(true)
                                this.loader.close();

                                MessageBox.error("Internal Server Error. Please contact your administrator")
                                
                            }.bind(this)
                        })
                    },
                    handleValueHelpPO: function(eItem) {
                        this.getView().getModel("iModel").setProperty("/FormattedPurOrgList", {});
                        this.getView().getModel("iModel").setProperty("/PurOrgList", {});
                        this.getView().getModel("iModel").setProperty("/PurOrgListCount", 0);
                        this.getView().getModel("iModel").refresh(true)
                        if (!this._valueHelpDialogPO) {
                            this._valueHelpDialogPO = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.PurchaseOrganization", this);
                            this.getView().addDependent(this._valueHelpDialogPO)
                        }
                        this._valueHelpDialogPO.open()
                        this._valueHelpDialogPO.setNoDataText("Please enter value for search");
                    },
                    handleValueHelpSearchPurchaseOrganization: function(eItem) {
                        var tVal = eItem.getParameter("value");
                        if(tVal != ""){
                            this.handleValueHelpPurchaseOrganization("");
                        }else{
                            MessageToast.show("Please enter search input");
                            return;
                        }
                        if(tVal.includes("*",0)){
                            tVal = tVal.split("*");
                            var valLength = tVal.length;
                            var preLength = 0;
                            var cval = "";
                            for(var i = 0; i < valLength; i++){
                                if(tVal[i] != ""){
                                    var currLength = tVal[i].length;
                                    if(preLength == 0){
                                        preLength = currLength;
                                        cval = tVal[i]
                                    }else{
                                        if(currLength > preLength){
                                            preLength = currLength;
                                            cval = tVal[i]
                                        }
                                    }
                                }
                            }
                            tVal = cval;
                        }
                        var aFilter = [new Filter("PurchaseOrganization",FilterOperator.Contains,tVal), new Filter("Description",FilterOperator.Contains,tVal)];
                        var nFilter = new Filter(aFilter,false);
                        eItem.getSource().getBinding("items").filter([nFilter])
                        if(eItem.getSource().getBinding("items").iLength == 0){
                            this._valueHelpDialogPO.setNoDataText("No data");
                            MessageToast.show("No matching data found")
                        }
                        this.getView().getModel("iModel").setProperty("/PurOrgListCount", eItem.getSource().getBinding("items").iLength);
                    },
                    _handleValueHelpPOClose: function(eItem) {
                        var tItem = eItem.getParameter("selectedItem");
                        if (tItem) {
                            var aItem = this.getView().byId("idInputPurOrg");
                            aItem.setValue(tItem.getTitle())
                        }
                        eItem.getSource().getBinding("items").filter([])
                    },
                    onSearch: function() {
                        this._startInstance()
                    },
                    _startInstance: function() {
                        this.loader.open();
                        var eModel = this.getView().getModel("iModel");
                        var tData = this.prepareData();
                        var sUrl = this._getCPIRuntimeBaseURL() + "/PIRDisplay";
                        if (tData != undefined) {
                            var aData = JSON.stringify(tData);
                            $.ajax({
                                url: sUrl,
                                method: "POST",
                                async: false,
                                contentType: "application/json",
                                headers: {},
                                data: aData,
                                success: $.proxy(function(eRes) {
                                    var list = [];
                                    this.getView().byId("idBtnChange").setProperty("enabled", false);
                                    this.getView().byId("idPurchaseInfoTable").removeSelections();
                                    this.getView().getModel("iModel").setProperty("/list", {});
                                    if(eRes.root != ""){
                                        if(eRes.root.InfoRecord_PurchOrg != undefined){
                                            if(eRes.root.InfoRecord_General != undefined){
                                                if(eRes.root.InfoRecord_PurchOrg.length != undefined){
                                                    for(var i = 0; i < eRes.root.InfoRecord_PurchOrg.length; i++){
                                                        if(eRes.root.InfoRecord_General.length != undefined){
                                                            for(var v = 0; v < eRes.root.InfoRecord_General.length; v++){
                                                                if(eRes.root.InfoRecord_PurchOrg[i].Info_Rec == eRes.root.InfoRecord_General[v].Info_Rec){
                                                                    if(eRes.root.InfoRecord_General[v].Material != ""){
                                                                        if(eRes.root.InfoRecord_PurchOrg[i].Plant != ""){
                                                                            var format = {Info_Rec: eRes.root.InfoRecord_PurchOrg[i].Info_Rec,
                                                                                Material: eRes.root.InfoRecord_General[v].Material,
                                                                                Vendor: eRes.root.InfoRecord_General[v].Vendor,
                                                                                MaterialGroup: eRes.root.InfoRecord_General[v].MaterialGroup,
                                                                                Unit: eRes.root.InfoRecord_General[v].Unit,
                                                                                PlannedDelTime: eRes.root.InfoRecord_PurchOrg[i].PlannedDelTime,
                                                                                Plant: eRes.root.InfoRecord_PurchOrg[i].Plant,
                                                                                PurInfoCat: eRes.root.InfoRecord_PurchOrg[i].PurInfoCat,
                                                                                PurchaseGroup: eRes.root.InfoRecord_PurchOrg[i].PurchaseGroup,
                                                                                PurhOrg: eRes.root.InfoRecord_PurchOrg[i].PurhOrg,
                                                                                StandardQuantity: eRes.root.InfoRecord_PurchOrg[i].StandardQuantity,
                                                                                Currency: eRes.root.InfoRecord_PurchOrg[i].Currency,
                                                                                PriceUnit: eRes.root.InfoRecord_PurchOrg[i].PriceUnit
                                                                            }                             
                                                                                list.push(format);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }else{
                                                            if(eRes.root.InfoRecord_PurchOrg[i].Info_Rec == eRes.root.InfoRecord_General.Info_Rec){
                                                                if(eRes.root.InfoRecord_General.Material != ""){
                                                                    if(eRes.root.InfoRecord_PurchOrg[i].Plant != ""){
                                                                        var format = {Info_Rec: eRes.root.InfoRecord_PurchOrg[i].Info_Rec,
                                                                            Material: eRes.root.InfoRecord_General.Material,
                                                                            Vendor: eRes.root.InfoRecord_General.Vendor,
                                                                            MaterialGroup: eRes.root.InfoRecord_General.MaterialGroup,
                                                                            Unit: eRes.root.InfoRecord_General.Unit,
                                                                            PlannedDelTime: eRes.root.InfoRecord_PurchOrg[i].PlannedDelTime,
                                                                            Plant: eRes.root.InfoRecord_PurchOrg[i].Plant,
                                                                            PurInfoCat: eRes.root.InfoRecord_PurchOrg[i].PurInfoCat,
                                                                            PurchaseGroup: eRes.root.InfoRecord_PurchOrg[i].PurchaseGroup,
                                                                            PurhOrg: eRes.root.InfoRecord_PurchOrg[i].PurhOrg,
                                                                            StandardQuantity: eRes.root.InfoRecord_PurchOrg[i].StandardQuantity,
                                                                            Currency: eRes.root.InfoRecord_PurchOrg[i].Currency,
                                                                            PriceUnit: eRes.root.InfoRecord_PurchOrg[i].PriceUnit
                                                                        }                             
                                                                            list.push(format);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }else{
                                                    if(eRes.root.InfoRecord_General.length != undefined){
                                                        for(var v = 0; v < eRes.root.InfoRecord_General.length; v++){
                                                            if(eRes.root.InfoRecord_PurchOrg.Info_Rec == eRes.root.InfoRecord_General[v].Info_Rec){
                                                                if(eRes.root.InfoRecord_General[v].Material != ""){
                                                                    if(eRes.root.InfoRecord_PurchOrg.Plant != ""){
                                                                        var format = {Info_Rec: eRes.root.InfoRecord_PurchOrg.Info_Rec,
                                                                            Material: eRes.root.InfoRecord_General[v].Material,
                                                                            Vendor: eRes.root.InfoRecord_General[v].Vendor,
                                                                            MaterialGroup: eRes.root.InfoRecord_General[v].MaterialGroup,
                                                                            Unit: eRes.root.InfoRecord_General[v].Unit,
                                                                            PlannedDelTime: eRes.root.InfoRecord_PurchOrg.PlannedDelTime,
                                                                            Plant: eRes.root.InfoRecord_PurchOrg.Plant,
                                                                            PurInfoCat: eRes.root.InfoRecord_PurchOrg.PurInfoCat,
                                                                            PurchaseGroup: eRes.root.InfoRecord_PurchOrg.PurchaseGroup,
                                                                            PurhOrg: eRes.root.InfoRecord_PurchOrg.PurhOrg,
                                                                            StandardQuantity: eRes.root.InfoRecord_PurchOrg.StandardQuantity,
                                                                            Currency: eRes.root.InfoRecord_PurchOrg.Currency,
                                                                            PriceUnit: eRes.root.InfoRecord_PurchOrg.PriceUnit
                                                                        }                             
                                                                            list.push(format);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }else{
                                                        if(eRes.root.InfoRecord_PurchOrg.Info_Rec == eRes.root.InfoRecord_General.Info_Rec){
                                                            if(eRes.root.InfoRecord_General.Material != ""){
                                                                if(eRes.root.InfoRecord_PurchOrg.Plant != ""){
                                                                    var format = {Info_Rec: eRes.root.InfoRecord_PurchOrg.Info_Rec,
                                                                        Material: eRes.root.InfoRecord_General.Material,
                                                                        Vendor: eRes.root.InfoRecord_General.Vendor,
                                                                        MaterialGroup: eRes.root.InfoRecord_General.MaterialGroup,
                                                                        Unit: eRes.root.InfoRecord_General.Unit,
                                                                        PlannedDelTime: eRes.root.InfoRecord_PurchOrg.PlannedDelTime,
                                                                        Plant: eRes.root.InfoRecord_PurchOrg.Plant,
                                                                        PurInfoCat: eRes.root.InfoRecord_PurchOrg.PurInfoCat,
                                                                        PurchaseGroup: eRes.root.InfoRecord_PurchOrg.PurchaseGroup,
                                                                        PurhOrg: eRes.root.InfoRecord_PurchOrg.PurhOrg,
                                                                        StandardQuantity: eRes.root.InfoRecord_PurchOrg.StandardQuantity,
                                                                        Currency: eRes.root.InfoRecord_PurchOrg.Currency,
                                                                        PriceUnit: eRes.root.InfoRecord_PurchOrg.PriceUnit
                                                                    }                             
                                                                        list.push(format);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if(list.length == 0){
                                        MessageToast.show("No Record Found")
                                    }
                                    this.getView().getModel("iModel").setProperty("/list/PIRList", list);
                                    this.loader.close();
                                }).bind(this),
                                error : function(res){
                                    this.getView().getModel("iModel").setProperty("/list", {});
                                    this.getView().getModel("iModel").refresh(true)
                                    this.loader.close();

                                    MessageBox.error("Internal Server Error. Please contact your administrator")
                                }.bind(this)
                            })
                        }
                    },
                    onItemSelect: function(eEvent) {
                        this.getView().getModel("iModel").setProperty("/selItem", {});
                        this.getView().getModel("iModel").setProperty("/selItem", this.getView().getModel("iModel").getProperty(this.getView().byId("idPurchaseInfoTable").getSelectedItem().getBindingContextPath()));
                        this.getView().byId("idBtnChange").setProperty("enabled", true)
                    },
                    prepareData: function() {
                        var tData = {
                            Requester: {
                                UserId: this.getView().getModel("iModel").getProperty("/user/id"),
                                RequestType: "Display"
                            },
                            PIR_Criteria: {
                                Material: this.getView().byId("idInputMaterial").getValue(),
                                MatGroup: this.getView().byId("idInputMatGroup").getValue(),
                                Vendor: this.getView().byId("idInputVendor").getValue(),
                                PurhOrg: this.getView().byId("idInputPurOrg").getValue(),
                                PurInfoCat: this.getView().byId("idInputPurInfoCat").getSelectedKey()
                            }
                        };
                        var aFlag = 1;
                        for (let[eKey,iVal] of Object.entries(tData.PIR_Criteria)) {
                            if (iVal == "") {
                                aFlag = 0
                            } else {
                                aFlag = 1;
                                break;
                            }
                        }
                        if (aFlag) {
                            return tData
                        } else {
                            MessageToast.show("Please enter one search criteria!")
                        }
                    },
                    navToCreatePurchaseInfoRecord: function() {
                        this.getOwnerComponent().getRouter().navTo("CreatePurchaseInfoRecord")
                    },
                    navToChangePurchaseInfoRecord: function(eEvent) {
                        setTimeout(function () {
                        this.handleValueHelpMaterialGroup("");
                        this.handleValueHelpPurchaseOrganization("");
                        }.bind(this), 100)
                        this.getOwnerComponent().getRouter().navTo("ChangePurchaseInfoRecord")
                    },
                    navToDisplay: function(eEvent) {
                        setTimeout(function () {
                        this.handleValueHelpMaterialGroup("");
                        this.handleValueHelpPurchaseOrganization("");
                        }.bind(this),100)
                        this.getView().getModel("iModel").setProperty("/selItem", {});
                        this.getView().getModel("iModel").setProperty("/selItem", this.getView().getModel("iModel").getProperty(eEvent.getSource().getBindingContextPath()));
                        this.getOwnerComponent().getRouter().navTo("DisplayPurchaseInfoRecord")
                    },
                    _getCPIRuntimeBaseURL: function () {
                        var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
                        var appPath = appId.replaceAll(".", "/");
                        var appModulePath = jQuery.sap.getModulePath(appPath);

                       return appModulePath + "/CPI/http";
                    },
                    formatInfoRec: function(eVal) {
                        switch (eVal) {
                        case "0":
                            return "Standard";
                            break;
                        case "2":
                            return "Consignment";
                            break;
                        case "3":
                            return "Subcontracting";
                            break;
                        case "P":
                            return "Pipeline";
                            break
                        }
                    }
                })
            });
