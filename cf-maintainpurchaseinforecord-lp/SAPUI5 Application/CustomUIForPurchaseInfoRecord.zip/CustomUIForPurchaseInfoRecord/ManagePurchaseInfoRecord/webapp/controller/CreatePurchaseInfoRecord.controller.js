sap.ui.define(["sap/m/MessageToast", "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History", "sap/ui/model/Filter", "sap/ui/model/FilterOperator",
    "sap/m/MessageBox", 'sap/m/MessageItem',
    'sap/m/MessagePopover', "sap/ui/core/Fragment", "sap/m/BusyDialog", "sap/m/Dialog","sap/ui/layout/HorizontalLayout"], function (MessageToast, Controller, History, Filter,
         FilterOperator, MessageBox, MessageItem, MessagePopover, Fragment, BusyDialog, Dialog, HorizontalLayout) {
        "use strict";
        return Controller.extend("com.sap.cp.dpa.ManagePurchaseInfoRecord.controller.CreatePurchaseInfoRecord", {
            defaultTabKey: "General",
            selectedTabkey: "",
            form: ["Material", "MaterialGroup", "Vendor", "PurchaseOrganization", "Plant", "PurchaseInfoCategory", "PurchaseGroup", "PlannedDeliveryTime", "StandardQuantity", "Price", "Currency", "PriceUnit", "OrderUnit", "ValidFrom", "ValidTo"],
            loader: new sap.m.BusyDialog(),
            editFlag: 0,
            handleValueHelpMaterial: function (eVal) {
                // this.loader.open();
                var tData = JSON.stringify({
                    Requester: {
                        UserId: this.getView().getModel("iModel").getProperty("/user/id")
                    },
                    Material: eVal,
                    MaxRows: 100
                });
                var sUrl = this._getCPIRuntimeBaseURL() + "/MaterialSearch";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {},
                    data: tData,
                    success: function (eRes) {
                        this.getView().getModel("iModel").setProperty("/MatDes", "");
                        this.getView().getModel("iModel").setProperty("/MaterialList", {});
                        if (eRes.root != "") {
                            this.getView().getModel("iModel").setProperty("/MaterialList", eRes.root.Result.length == undefined ? {
                                0: eRes.root.Result
                            } : eRes.root.Result);
                            this.getView().getModel("iModel").setProperty("/MaterialListCount",eRes.root.Result.length == undefined ?
                                0 : eRes.root.Result.length);
                            this.getView().getModel("iModel").setProperty("/MatDes", eRes.root.Result.length == undefined ? eRes.root.Result.Matl_Desc : "");
                            this.getView().getModel("iModel").refresh(true)
                        } else {
                            this.getView().getModel("iModel").setProperty("/MaterialList", {});
                            this.getView().getModel("iModel").setProperty("/MaterialListCount", 0);
                            if(this._valueHelpDialogM){
                                this._valueHelpDialogM.setNoDataText("No data")
                                MessageToast.show("No matching data found")
                            }
                            this.getView().getModel("iModel").refresh(true)
                        }
                    }
                        .bind(this),
                        error : function(res){
                                this.getView().getModel("iModel").setProperty("/MatDes", "");
                                this.getView().getModel("iModel").setProperty("/MaterialList", {});
                                this.getView().getModel("iModel").setProperty("/MaterialListCount", 0);
                                this._valueHelpDialogM.setNoDataText("No data")
                                this.getView().getModel("iModel").refresh(true)
                                MessageBox.error("Internal Server Error. Please contact your administrator")
                            }.bind(this)
                })
            },
            handleValueHelpM: function (tItem) {
                this.getView().getModel("iModel").setProperty("/MatDes", "");
                this.getView().getModel("iModel").setProperty("/MaterialList", {});
                this.getView().getModel("iModel").setProperty("/MaterialListCount", 0);
                this.getView().getModel("iModel").refresh(true)
                if (!this._valueHelpDialogM) {
                    this._valueHelpDialogM = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.Material", this);
                    this.getView().addDependent(this._valueHelpDialogM)
                }
                this._valueHelpDialogM.open();
                this._valueHelpDialogM.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchMaterial: function (eItem) {
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                    this.handleValueHelpMaterial("*"+tVal+"*");
                }else{
                    MessageToast.show("Please enter search input");
                    return;
                }
            },
            _handleValueHelpMClose: function (eItem) {
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("Material");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                    this.getView().byId("MaterialDesc").setText(tItem.getDescription());
                }
            },
            handleValueHelpVendor: function (aVendor, bName) {
                var tData = JSON.stringify({
                    Requester: {
                        UserId: this.getView().getModel("iModel").getProperty("/user/id")
                    },
                    Vendor: aVendor,
                    Name1: bName
                });
                var sUrl = this._getCPIRuntimeBaseURL() + "/VendorSearch"; 
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {},
                    data: tData,
                    success: function (eRes) {
                        this.getView().getModel("iModel").setProperty("/VenDes", "");
                        this.getView().getModel("iModel").setProperty("/VendorList", {});
                        if (eRes.root != "") {
                            this.getView().getModel("iModel").setProperty("/VendorList", eRes.root.Result.length == undefined ? {
                                0: eRes.root.Result
                            } : eRes.root.Result);
                            this.getView().getModel("iModel").setProperty("/VendorListCount",eRes.root.Result.length == undefined ?
                                    0 : eRes.root.Result.length);
                            this.getView().getModel("iModel").setProperty("/VenDes", eRes.root.Result.length == undefined ? eRes.root.Result.Name1 : "");
                            this.getView().getModel("iModel").refresh(true)
                        } else {
                            if(aVendor != ""){
                                bName = aVendor;
                                aVendor="";
                                this.handleValueHelpVendor(aVendor,bName)
                            }else{
                                this.getView().getModel("iModel").setProperty("/VendorListCount", 0);
                                if (this._valueHelpDialogV) {
                                    this._valueHelpDialogV.setNoDataText("No data")
                                    MessageToast.show("No matching data found")
                                }
                            }
                            this.getView().getModel("iModel").refresh(true)
                        }
                    }
                        .bind(this),
                        error : function(res){
                                this.getView().getModel("iModel").setProperty("/VenDes", "");
                                this.getView().getModel("iModel").setProperty("/VendorList", {});
                                this.getView().getModel("iModel").setProperty("/VendorListCount", 0);
                                this._valueHelpDialogV.setNoDataText("No data")
                                this.getView().getModel("iModel").refresh(true);
                                MessageBox.error("Internal Server Error. Please contact your administrator")
                            }.bind(this)
                })
            },
            handleValueHelpV: function (tItem) {
                this.getView().getModel("iModel").setProperty("/VenDes", "");
                this.getView().getModel("iModel").setProperty("/VendorList", {});
                this.getView().getModel("iModel").setProperty("/VendorListCount", 0);
                this.getView().getModel("iModel").refresh(true);
                if (!this._valueHelpDialogV) {
                    this._valueHelpDialogV = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.Vendor", this);
                    this.getView().addDependent(this._valueHelpDialogV)
                }
                this._valueHelpDialogV.open();
                this._valueHelpDialogV.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchVendor: function (eItem) {
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                    this.handleValueHelpVendor("*"+tVal+"*","");
                }else{
                    MessageToast.show("Please enter search input");
                    return;
                }
            },
            _handleValueHelpVClose: function (eItem) {
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("Vendor");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                    this.getView().byId("VendorDesc").setText(tItem.getDescription());
                }
            },
            handleValueHelpMaterialGroup: function(id) {
                var data = JSON.stringify({
                    Requester: {
                        UserId: this.getView().getModel("iModel").getProperty("/user/id")
                    },
                    MaterialGroup: ""
                });
                var sUrl = this._getCPIRuntimeBaseURL() + "/MaterialGroup";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {},
                    data: data,
                    success: function(res) {
                        var formatData = {};
                        if (res.root != "") {
                        for (var i = 0; i < res.root.Result.length; i++) {
                            formatData[res.root.Result[i].MaterialGroup] = res.root.Result[i].Description
                        }
                        this.getView().getModel("iModel").setProperty("/FormattedMaterialGroupList", formatData);
                        this.getView().getModel("iModel").setProperty("/MaterialGroupList", res.root.Result);
                    } else {MessageToast.show("No data found")}
                    }
                    .bind(this),
                    error : function(res){
                        this.getView().getModel("iModel").setProperty("/FormattedMaterialGroupList", {});
                        this.getView().getModel("iModel").setProperty("/MaterialGroupList", {});
                        this.getView().getModel("iModel").refresh(true);
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                    }.bind(this)
                })
            },
            handleValueHelpMG: function (eItem) {
                this.getView().getModel("iModel").setProperty("/FormattedMaterialGroupList", {});
                this.getView().getModel("iModel").setProperty("/MaterialGroupList", {});
                this.getView().getModel("iModel").setProperty("/MaterialGroupListCount", 0);
                this.getView().getModel("iModel").refresh(true);
                if (!this._valueHelpDialogMG) {
                    this._valueHelpDialogMG = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.MaterialGroup", this);
                    this.getView().addDependent(this._valueHelpDialogMG)
                }
                this._valueHelpDialogMG.open();
                this._valueHelpDialogMG.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchMaterialGroup: function (eItem) {
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                    this.handleValueHelpMaterialGroup("");
                }else{
                    MessageToast.show("Please enter value for search");
                    return;
                }
                if(tVal.includes("*",0)){
                    tVal = tVal.split("*");
                    var valLength = tVal.length;
                    var preLength = 0;
                    var cval = "";
                    for(var i = 0; i < valLength; i++){
                        if(tVal[i] != ""){
                            var currLength = tVal[i].length;
                            if(preLength == 0){
                                preLength = currLength;
                                cval = tVal[i]
                            }else{
                                if(currLength > preLength){
                                    preLength = currLength;
                                    cval = tVal[i]
                                }
                            }
                        }
                    }
                    tVal = cval;
                }
                var aFilter = [new Filter("MaterialGroup", FilterOperator.Contains, tVal), new Filter("Description", FilterOperator.Contains, tVal)];
                var nFilter = new Filter(aFilter, false);
                eItem.getSource().getBinding("items").filter([nFilter]);
                if(eItem.getSource().getBinding("items").iLength == 0){
                    this._valueHelpDialogMG.setNoDataText("No data");
                    MessageToast.show("No matching data found");
                }
                this.getView().getModel("iModel").setProperty("/MaterialGroupListCount", eItem.getSource().getBinding("items").iLength);
            },
            _handleValueHelpMGClose: function (eItem) {
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("MaterialGroup");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                    this.getView().byId("MaterialGroupDesc").setText(tItem.getDescription())
                }
                eItem.getSource().getBinding("items").filter([])
            },
            handleValueHelpPurchaseOrganization: function (eVal) {
                var tData = JSON.stringify({
                    Requester: {
                        UserId: this.getView().getModel("iModel").getProperty("/user/id")
                    },
                    PurchaseOrganization: ""
                });
                var sUrl = this._getCPIRuntimeBaseURL() + "/PurchaseOrganization";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {},
                    data: tData,
                    success: function (eRes) {
                        var tFormat = {};
                        if (eRes.root != "") {
                        for (var a = 0; a < eRes.root.Result.length; a++) {
                            tFormat[eRes.root.Result[a].PurchaseOrganization] = eRes.root.Result[a].Description
                        }
                        this.getView().getModel("iModel").setProperty("/FormattedPurOrgList", tFormat);
                        this.getView().getModel("iModel").setProperty("/PurOrgList", eRes.root.Result);
                    } else {MessageToast.show("No data found")}
                }
                        .bind(this),
                        error : function(res){
                                this.getView().getModel("iModel").setProperty("/FormattedPurOrgList", {});
                                this.getView().getModel("iModel").setProperty("/PurOrgList", {});
                                this.getView().getModel("iModel").refresh(true);
                                MessageBox.error("Internal Server Error. Please contact your administrator")
                            }.bind(this)
                })
            },
            handleValueHelpPO: function (eItem) {
                this.getView().getModel("iModel").setProperty("/FormattedPurOrgList", {});
                this.getView().getModel("iModel").setProperty("/PurOrgList", {});
                this.getView().getModel("iModel").setProperty("/PurOrgListCount", 0);
                this.getView().getModel("iModel").refresh(true);
                if (!this._valueHelpDialogPO) {
                    this._valueHelpDialogPO = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.PurchaseOrganization", this);
                    this.getView().addDependent(this._valueHelpDialogPO)
                }
                this._valueHelpDialogPO.open();
                this._valueHelpDialogPO.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchPurchaseOrganization: function (eItem) {
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                    this.handleValueHelpPurchaseOrganization("");
                }else{
                    MessageToast.show("Please enter value for search");
                    return;
                }
                if(tVal.includes("*",0)){
                    tVal = tVal.split("*");
                    var valLength = tVal.length;
                    var preLength = 0;
                    var cval = "";
                    for(var i = 0; i < valLength; i++){
                        if(tVal[i] != ""){
                            var currLength = tVal[i].length;
                            if(preLength == 0){
                                preLength = currLength;
                                cval = tVal[i]
                            }else{
                                if(currLength > preLength){
                                    preLength = currLength;
                                    cval = tVal[i]
                                }
                            }
                        }
                    }
                    tVal = cval;
                }
                var aFilter = [new Filter("PurchaseOrganization", FilterOperator.Contains, tVal), new Filter("Description", FilterOperator.Contains, tVal)];
                var nFilter = new Filter(aFilter, false);
                eItem.getSource().getBinding("items").filter([nFilter])
                if(eItem.getSource().getBinding("items").iLength == 0){
                    this._valueHelpDialogPO.setNoDataText("No data");
                    MessageToast.show("No matching data found")
                }
                this.getView().getModel("iModel").setProperty("/PurOrgListCount", eItem.getSource().getBinding("items").iLength);
            },
            _handleValueHelpPOClose: function (eItem) {
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("PurchaseOrganization");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                    this.getView().byId("PurchaseOrganizationDesc").setText(tItem.getDescription())
                }
                eItem.getSource().getBinding("items").filter([])
            },
            handleValueHelpPurchaseGroup: function (eItem) {
                var tData = JSON.stringify({
                    Requester: {
                        UserId: this.getView().getModel("iModel").getProperty("/user/id")
                    },
                    PurchaseGroup: ""
                });
                var sUrl = this._getCPIRuntimeBaseURL() + "/PurchaseGroup";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {},
                    data: tData,
                    success: $.proxy(function (eRes) {
                        var tFormat = {};
                        if (eRes.root != "") {
                        for (var a = 0; a < eRes.root.Result.length; a++) {
                            tFormat[eRes.root.Result[a].PurchaseGroup] = eRes.root.Result[a].Description
                        }
                        this.getView().getModel("iModel").setProperty("/FormattedPurGrpList", tFormat)
                        this.getView().getModel("iModel").setProperty("/PurGrpList", eRes.root.Result); 
                    } else {MessageToast.show("No data found")}
                    }).bind(this),
                    error : function(res){
                            this.getView().getModel("iModel").setProperty("/FormattedPurGrpList", {});
                            this.getView().getModel("iModel").setProperty("/PurGrpList", {});
                            this.getView().getModel("iModel").refresh(true);
                            MessageBox.error("Internal Server Error. Please contact your administrator")
                        }.bind(this)
                })
            },
            handleValueHelpPG: function (eItem) {
                this.getView().getModel("iModel").setProperty("/FormattedPurGrpList", {});
                this.getView().getModel("iModel").setProperty("/PurGrpList", {});
                this.getView().getModel("iModel").setProperty("/PurGrpListCount", 0);
                this.getView().getModel("iModel").refresh(true);
                if (!this._valueHelpDialogPG) {
                    this._valueHelpDialogPG = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.PurchaseGroup", this);
                    this.getView().addDependent(this._valueHelpDialogPG)
                }
                this._valueHelpDialogPG.open();
                this._valueHelpDialogPG.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchPurchaseGroup: function (eItem) {
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                    this.handleValueHelpPurchaseGroup("");
                }else{
                    MessageToast.show("Please enter search input");
                    return;
                }
                if(tVal.includes("*",0)){
                    tVal = tVal.split("*");
                    var valLength = tVal.length;
                    var preLength = 0;
                    var cval = "";
                    for(var i = 0; i < valLength; i++){
                        if(tVal[i] != ""){
                            var currLength = tVal[i].length;
                            if(preLength == 0){
                                preLength = currLength;
                                cval = tVal[i]
                            }else{
                                if(currLength > preLength){
                                    preLength = currLength;
                                    cval = tVal[i]
                                }
                            }
                        }
                    }
                    tVal = cval;
                }
                var aFilter = [new Filter("PurchaseGroup", FilterOperator.Contains, tVal), new Filter("Description", FilterOperator.Contains, tVal)];
                var nFilter = new Filter(aFilter, false);
                eItem.getSource().getBinding("items").filter([nFilter]);
                if(eItem.getSource().getBinding("items").iLength == 0){
                    this._valueHelpDialogPG.setNoDataText("No data");
                    MessageToast.show("No matching data found")
                }
                this.getView().getModel("iModel").setProperty("/PurGrpListCount", eItem.getSource().getBinding("items").iLength);
            },
            _handleValueHelpPGClose: function (eItem) {
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("PurchaseGroup");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                    this.getView().byId("PurchaseGroupDesc").setText(tItem.getDescription())
                }
                eItem.getSource().getBinding("items").filter([])
            },
            handleValueHelpPlantSearch: function (eVal) {
                var tData = JSON.stringify({
                    Requester: {
                        UserId: this.getView().getModel("iModel").getProperty("/user/id")
                    },
                    Plant: ""
                });
                var sUrl = this._getCPIRuntimeBaseURL() + "/PlantSearch";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {},
                    data: tData,
                    success: $.proxy(function (eRes) {
                        var tFormat = {};
                        if (eRes.Result != "") {
                        for (var a = 0; a < eRes.Result.length; a++) {
                            tFormat[eRes.Result[a].Plant] = {
                                Name1: eRes.Result[a].Name1,
                                CompanyCode: eRes.Result[a].CompanyCode
                            }
                        }
                        this.getView().getModel("iModel").setProperty("/FormattedPlantList", tFormat)
                        this.getView().getModel("iModel").setProperty("/PlantList", eRes.Result);
                    } else {MessageToast.show("No data found")}
                    }).bind(this),
                    error : function(res){
                            this.getView().getModel("iModel").setProperty("/FormattedPlantList", {});
                            this.getView().getModel("iModel").setProperty("/PlantList", {});
                            this.getView().getModel("iModel").refresh(true)
                            MessageBox.error("Internal Server Error. Please contact your administrator")
                        }.bind(this)
                })
            },
            handleValueHelpPL: function (eItem) {
                this.getView().getModel("iModel").setProperty("/FormattedPlantList", {});
                this.getView().getModel("iModel").setProperty("/PlantList", {});
                this.getView().getModel("iModel").setProperty("/PlantListCount", 0);
                this.getView().getModel("iModel").refresh(true)
                if (!this._valueHelpDialogPL) {
                    this._valueHelpDialogPL = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.Plant", this);
                    this.getView().addDependent(this._valueHelpDialogPL)
                }
                this._valueHelpDialogPL.open();
                this._valueHelpDialogPL.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchPlant: function (eItem) {
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                    this.handleValueHelpPlantSearch("");
                }else{
                    MessageToast.show("Please enter search input");
                    return;
                }
                if(tVal.includes("*",0)){
                    tVal = tVal.split("*");
                    var valLength = tVal.length;
                    var preLength = 0;
                    var cval = "";
                    for(var i = 0; i < valLength; i++){
                        if(tVal[i] != ""){
                            var currLength = tVal[i].length;
                            if(preLength == 0){
                                preLength = currLength;
                                cval = tVal[i]
                            }else{
                                if(currLength > preLength){
                                    preLength = currLength;
                                    cval = tVal[i]
                                }
                            }
                        }
                    }
                    tVal = cval;
                }
                var aFilter = [new Filter("Plant", FilterOperator.Contains, tVal), new Filter("Name1", FilterOperator.Contains, tVal)];
                var nFilter = new Filter(aFilter, false);
                eItem.getSource().getBinding("items").filter([nFilter]);
                if(eItem.getSource().getBinding("items").iLength == 0){
                    this._valueHelpDialogPL.setNoDataText("No data");
                    MessageToast.show("No matching data found")
                }
                this.getView().getModel("iModel").setProperty("/PlantListCount", eItem.getSource().getBinding("items").iLength);
            },
            _handleValueHelpPLClose: function (eItem) {
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("Plant");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                    this.getView().byId("PlantDesc").setText(tItem.getDescription())
                    var plantDetail = this.getView().getModel("iModel").getProperty("/FormattedPlantList/" + tItem.getTitle());
                    this.getView().byId("CompanyCode").setValue(plantDetail.CompanyCode)
                }
                eItem.getSource().getBinding("items").filter([])
            },
            LiveChange: function(eItem) {
                var tVal = eItem.getParameters().newValue;
                var aId = eItem.getParameters().id;
                aId = aId.split("--");
                if (tVal != "") {
                    this.getView().byId(aId[1]).setValueState("None");
                }
            },
            ValueChange: function (eItem) {
                if(!this.editFlag)
                    this.editFlag = !this.editFlag;
                var input = eItem.getSource();
                if(input && input.setValue){
                    input.setValue(input.getValue().toUpperCase()); 
                }
                var tVal = eItem.getParameters().newValue;
                var aId = eItem.getParameters().id;
                aId = aId.split("--");
                if (tVal != "") {
                    this.getView().byId(aId[1]).setValueState("None");                                        
                }
                if (aId[1] == "Material") {
                    if (tVal != "") {
                                this.handleValueHelpMaterial(tVal);
                                if(tVal.includes("*",0)){
                                    MessageBox.error("No matching record found for Material "+ tVal)
                                    this.getView().byId("MaterialDesc").setText("")
                                }else{
                                    if(this.getView().getModel("iModel").getProperty("/MatDes") == ""){
                                        MessageBox.error("No matching record found for Material "+ tVal)
                                        this.getView().byId("MaterialDesc").setText("")
                                    }else{
                                        this.getView().byId("MaterialDesc").setText(this.getView().getModel("iModel").getProperty("/MatDes"))
                                    }
                                }
                    } else {
                        this.getView().byId("MaterialDesc").setText("")
                    }
                }
                if (aId[1] == "MaterialGroup") {
                    if (tVal != "") {
                        this.handleValueHelpMaterialGroup("");
                            var iVal = "";
                            iVal = this.getView().getModel("iModel").getProperty("/FormattedMaterialGroupList/" + tVal);
                            if (iVal != undefined) {
                                this.getView().byId("MaterialGroupDesc").setText(iVal)
                            } else {
                                MessageBox.error("No matching record found for Material Group "+ tVal)
                                this.getView().byId("MaterialGroupDesc").setText("")
                            }
                       // }
                    } else {
                        this.getView().byId("MaterialGroupDesc").setText("")
                    }
                }
                if (aId[1] == "Vendor") {
                    if (tVal != "") {
                                this.handleValueHelpVendor(tVal,"");
                                if(tVal.includes("*",0)){
                                    MessageBox.error("No matching record found for Vendor "+ tVal)
                                    this.getView().byId("VendorDesc").setText("")
                                }else{
                                    if(this.getView().getModel("iModel").getProperty("/VenDes") == ""){
                                        MessageBox.error("No matching record found for Vendor "+ tVal)
                                        this.getView().byId("VendorDesc").setText("")
                                    }else{
                                        this.getView().byId("VendorDesc").setText(this.getView().getModel("iModel").getProperty("/VenDes"))
                                    }
                                }
                    } else {
                        this.getView().byId("VendorDesc").setText("")
                    }
                }
                if (aId[1] == "PurchaseOrganization") {
                    if (tVal != "") {
                        this.handleValueHelpPurchaseOrganization("");
                            var iVal = "";
                            iVal = this.getView().getModel("iModel").getProperty("/FormattedPurOrgList/" + tVal);
                            if (iVal != undefined) {
                                this.getView().byId("PurchaseOrganizationDesc").setText(iVal)
                            } else {
                                MessageBox.error("Purchasing Organization "+ tVal +" is not found")
                                this.getView().byId("PurchaseOrganizationDesc").setText("")
                            }
                    } else {
                        this.getView().byId("PurchaseOrganizationDesc").setText("")
                    }
                }
                if (aId[1] == "PurchaseGroup") {
                    if (tVal != "") {
                            this.handleValueHelpPurchaseGroup("");
                            var iVal = "";
                            iVal = this.getView().getModel("iModel").getProperty("/FormattedPurGrpList/" + tVal);
                            if (iVal != undefined) {
                                this.getView().byId("PurchaseGroupDesc").setText(iVal)
                            } else {
                                MessageBox.error("Purchasing Group "+ tVal +" is not found")
                                this.getView().byId("PurchaseGroupDesc").setText("")
                            }
                    } else {
                        this.getView().byId("PurchaseGroupDesc").setText("")
                    }
                }
                if (aId[1] == "Plant") {
                    if (tVal != "") {
                            this.handleValueHelpPlantSearch("");
                            var iVal = "";
                            iVal = this.getView().getModel("iModel").getProperty("/FormattedPlantList/" + tVal);
                            if (iVal != undefined) {
                                this.getView().byId("PlantDesc").setText(iVal.Name1);
                                this.getView().byId("CompanyCode").setValue(iVal.CompanyCode)
                            } else {
                                MessageBox.error("Plant "+ tVal +" is not found")
                                this.getView().byId("PlantDesc").setText("");
                                this.getView().byId("CompanyCode").setValue("")
                            }
                    } else {
                        this.getView().byId("PlantDesc").setText("");
                        this.getView().byId("CompanyCode").setValue("")
                    }
                }
            },
            getFormData: function () {
                var eData = [];
                var tData = {
                    RequestId: "Purchase Info Record_Approval_00_001",
                    Title: "Purchase Info Record Data Maintenance",
                    Requester: {
                        Name: this.getView().getModel("iModel").getProperty("/user/name"),
                        Email: this.getView().getModel("iModel").getProperty("/user/email"),
                        UserId: this.getView().getModel("iModel").getProperty("/user/UserId"),
                        Comments: this.getView().getModel("iModel").getProperty("/comment"),
                        Action: "Create"
                    },
                    PurchaseInfoRecordDetails: {}
                };
                this.form.forEach(function (aKey) {
                    if (aKey == "ValidFrom" || aKey == "ValidTo") {
                        var nData = this.dateFormat(this.getView().byId(aKey).getValue(), "yyyyMMdd")
                        tData["PurchaseInfoRecordDetails"][aKey] = nData
                    }
                    if (aKey == "OldPrice" || aKey == "Price" || aKey == "StandardQuantity" || aKey == "PlannedDeliveryTime") {
                        var nData = parseFloat(this.getView().byId(aKey).getValue())
                        tData["PurchaseInfoRecordDetails"][aKey] = nData
                    }
                    if (aKey == "PurchaseInfoCategory") {
                        var nData = this.getView().byId(aKey).getSelectedKey()
                        tData["PurchaseInfoRecordDetails"][aKey] = nData
                    }
                    if (aKey != "ValidFrom" && aKey != "ValidTo" && aKey != "OldPrice" && aKey != "Price" && aKey != "StandardQuantity" 
                    && aKey != "PlannedDeliveryTime"
                        && aKey != "PurchaseInfoCategory") {
                        tData["PurchaseInfoRecordDetails"][aKey] = this.getView().byId(aKey).getValue().toUpperCase();
                    }
                }.bind(this))
                tData["PurchaseInfoRecordDetails"]["PurchaseInfoRecordNum"] = this.getView().byId("PurchaseInfoRecordNum").getValue()
                tData["PurchaseInfoRecordDetails"]["MaterialDesc"] = this.getView().byId("MaterialDesc").getText()
                tData["PurchaseInfoRecordDetails"]["MaterialGroupDesc"] = this.getView().byId("MaterialGroupDesc").getText()
                tData["PurchaseInfoRecordDetails"]["VendorDesc"] = this.getView().byId("VendorDesc").getText()
                tData["PurchaseInfoRecordDetails"]["PurchaseOrganizationDesc"] = this.getView().byId("PurchaseOrganizationDesc").getText()
                tData["PurchaseInfoRecordDetails"]["PlantDesc"] = this.getView().byId("PlantDesc").getText()
                tData["PurchaseInfoRecordDetails"]["PurchaseGroupDesc"] = this.getView().byId("PurchaseGroupDesc").getText()
                tData["PurchaseInfoRecordDetails"]["CompanyCode"] = this.getView().byId("CompanyCode").getValue()
                tData["PurchaseInfoRecordDetails"]["PurchaseInfoCategoryDesc"] = this.getView().byId("PurchaseInfoCategory").getSelectedItem().getText()
                this.getView().getModel("iModel").setProperty("/PurchaseInfoRecordDetails", tData)
            },
            dateFormat: function (eDate, tPattern) {
                var aDate = sap.ui.core.format.DateFormat.getDateInstance({
                    pattern: tPattern
                });
                var iDate = aDate.parse(eDate);
                iDate = aDate.format(iDate);
                return iDate
            },
            getRouter: function () {
                return sap.ui.core.UIComponent.getRouterFor(this)
            },
            Cancel: function () {
                if(this.editFlag){
                    MessageBox.information("There are unsaved changes. Do you still want to navigate?",{
                    title: "Confirmation",
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                    onClose: function (oAction){
                        if(oAction == "YES"){
                            this.getOwnerComponent().getRouter().navTo("Master");
                            this.enableFields();
                        }
                    }.bind(this)  
                })
                }else{
                    this.getOwnerComponent().getRouter().navTo("Master");
                    this.enableFields();
                }
            },
            onInit: function () {
                this.getView().getModel(this.getOwnerComponent().getModel("iModel"), "iModel");
                this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this)
            },
            onRouteMatched: function (eEvent) {
                if (eEvent.getParameter("name") == "CreatePurchaseInfoRecord") {
                     this.editFlag = 0;
                    this.getView().byId("button2").setVisible(false);
                    this.getView().byId("button1").setVisible(true);
                    this.resetValidate();
                    this.enableFields();
                    this.setTab();
                    this.getView().byId("idBtnSave").setEnabled(true)
                }
            },
            setTab: function () {
                this.selectedTabkey = this.defaultTabKey;
                this.getView().byId("idIconTabBarNoIcons").setSelectedKey(this.selectedTabkey)
            },
            onTabChange: function (tEvent) {
                var aMaterial = this.getView().byId("Material").getValue().toUpperCase();
                var iVendor = this.getView().byId("Vendor").getValue().toUpperCase();
                var sPO = this.getView().byId("PurchaseOrganization").getValue().toUpperCase();
                var rPlant = this.getView().byId("Plant").getValue().toUpperCase();
                var oPIC = this.getView().byId("PurchaseInfoCategory").getSelectedKey();
                if (aMaterial != "" && iVendor != "" && sPO != "" && rPlant != "" && oPIC != "") {
                    if (this.selectedTabkey == this.defaultTabKey) {
                        this._AutofillUp(aMaterial, iVendor, sPO, rPlant, oPIC)
                        this.selectedTabkey = tEvent.getParameter("selectedKey");
                    } else {
                        this.selectedTabkey = tEvent.getParameter("selectedKey");
                    }
                } else {
                    this.getView().byId("idIconTabBarNoIcons").setSelectedKey(this.selectedTabkey);
                    MessageToast.show("Please fill all the fields of General Tab first!");
                    if(aMaterial == "" || aMaterial.includes("*",0)){
                        this.getView().byId("Material").setValueState("Error");
                    }else{
                        this.getView().byId("Material").setValueState("None")
                    }
                    if(iVendor == "" || iVendor.includes("*",0)){
                        this.getView().byId("Vendor").setValueState("Error");
                    }else{
                        this.getView().byId("Vendor").setValueState("None")
                    }
                    if(sPO == "" || sPO.includes("*",0)){
                        this.getView().byId("PurchaseOrganization").setValueState("Error");
                    }else{
                        this.getView().byId("PurchaseOrganization").setValueState("None")
                    }
                    if(rPlant == "" || rPlant.includes("*",0)){
                        this.getView().byId("Plant").setValueState("Error");
                    }else{
                        this.getView().byId("Plant").setValueState("None")
                    }
                    if(oPIC == "" || oPIC.includes("*",0)){
                        this.getView().byId("PurchaseInfoCategory").setValueState("Error");
                    }else{
                        this.getView().byId("PurchaseInfoCategory").setValueState("None")
                    }
                }
            },
            _AutofillUp: function (eMaterial, tVendor, aPO, iPlant, sPIC) {
                this.loader.open();
                var oData = {
                    Requester: {
                        UserId: this.getView().getModel("iModel").getProperty("/user/id"),
                        RequestType: "TestRun"
                    },
                    PIR_ChangeData: {
                        Material: eMaterial,
                        Vendor: tVendor,
                        PurchaseOrganization: aPO,
                        Plant: iPlant,
                        PurchaseInfoCategory: sPIC
                    }
                };
                var nData = JSON.stringify(oData);
                var sUrl = this._getCPIRuntimeBaseURL() + "/PIRValidation";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {},
                    data: nData,
                    success: $.proxy(function (eRes) {
                        var message = "";
                        if (eRes.root.Result != "") {
                            this.getView().byId("Currency").setValue(eRes.root.Result.Currency)
                            if (this.getView().byId("Currency").getValue() == "") {
                                this.getView().byId("Currency").setValueState("Error")
                            } else {
                                this.getView().byId("Currency").setValueState("None")
                            }
                            this.getView().byId("OrderUnit").setValue(eRes.root.Result.Unit)
                            if (this.getView().byId("OrderUnit").getValue() == "") {
                                this.getView().byId("OrderUnit").setValueState("Error")
                            } else {
                                this.getView().byId("OrderUnit").setValueState("None")
                            }
                            this.getView().byId("Unit").setValue(eRes.root.Result.Unit)
                        } 
                        this.loader.close();
                    }).bind(this),
                    error : function(res){
                        this.getView().byId("Currency").setValue("");
                        this.getView().byId("OrderUnit").setValue("");
                        this.getView().byId("Unit").setValue("")
                        this.loader.close();
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                    }.bind(this)
                })
            },
            _fetchToken: function () {
                var eToken;
                var sUrl = this._getWorkflowRuntimeBaseURL() + "/xsrf-token";
                $.ajax({
                    url: sUrl,
                    method: "GET",
                    async: false,
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (t, a, i) {
                        eToken = i.getResponseHeader("X-CSRF-Token")
                    }
                });
                return eToken
            },
            Controller: function () {
                this.resetValidate();
                if (this.validate()) {
                    this.getView().getModel("iModel").setProperty("/comment", "")
                    	var oDialog = new Dialog({
                            title: 'Confirm',
                            type: 'Message',
                            content: [
                                new HorizontalLayout({
                                    content: [
                                        new sap.m.Text({ text: 'Are you sure you want to submit?' })
                                    ]
                                }),
                                new sap.m.TextArea('confirmDialogTextarea', {
                                    width: '100%',
                                    placeholder: 'Add note (optional)'
                                })
                            ],
                            beginButton: new sap.m.Button({
                                type: sap.m.ButtonType.Ghost,
                                text: 'Submit',
                                press: function () {
                                    var sText = this.getView().getModel("iModel").setProperty("/comment",
                                        sap.ui.getCore().byId('confirmDialogTextarea').getValue());
                                     var eToken = this._fetchToken();
                                    this._startInstance(eToken)
                                    oDialog.close();
                                }.bind(this)
                            }),
                            endButton: new sap.m.Button({
                                text: 'Cancel',
                                press: function () {
                                    oDialog.close();
                                }
                            }),
                            afterClose: function () {
                                oDialog.destroy();
                            }
                        })
                        oDialog.open();
                }
            },
            _startInstance: function (eToken) {
                this.loader.open();
                this.getFormData();
                var tData = this.getView().getModel("iModel").getProperty("/PurchaseInfoRecordDetails");
                var aData = {
                    Requester: {
                        UserId: this.getView().getModel("iModel").getProperty("/user/id"),
                        RequestType: "TestRun"
                    },
                    PIR_ChangeData: tData.PurchaseInfoRecordDetails
                };
                var iData = JSON.stringify(aData);
                var sUrl = this._getCPIRuntimeBaseURL() + "/CheckPIRValidation";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {},
                    data: iData,
                    success: $.proxy(function (tRes) {
                        var message = "";
                        if (tRes.Result.Type == "E") {
                            MessageBox.information(tRes.Result.Message)
                        } else {
                            if (tRes.Result.Message.length != undefined){
                                for (var i = 0; i<tRes.Result.Message.length; i++) {
                                    if (tRes.Result.Message[i].Type == "E")
                                    {
                                        message += tRes.Result.Message[i].Message + "\n" 
                                    }   
                                }                              
                            }else{
                                if (tRes.Result.Message.Type == "E")
                                {
                                    message += tRes.Result.Message.Message + "\n" 
                                } 
                            }
                            if(message.length > 1){
                                MessageBox.error(message);
                            }else if (tRes.Result.Info_Rec != ""){
                                MessageBox.error("A purchase info record "+tRes.Result.Info_Rec+" already exists with the same data");
                            } else {
                                    var btoken = this._bfetchToken();
                                    this.getWorkflowDef(eToken, btoken);
                            }  
                        }
                        this.loader.close();
                    }).bind(this),
                    error : function(res){
                        //MessageBox.error("An error occured. Please try again");
                        this.loader.close();
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                    }.bind(this)
                })
            },
            _initiateCreate: function (tToken,ProcessVariantId) {
                this.loader.open();
                this.getFormData();
                var aData = this.getView().getModel("iModel").getProperty("/PurchaseInfoRecordDetails");
                var iData = {
                    definitionId: ProcessVariantId,
                    context: aData
                };
                var sData = JSON.stringify(iData);
                var sUrl = this._getWorkflowRuntimeBaseURL() + "/workflow-instances";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {
                        "X-CSRF-Token": tToken
                    },
                    data: sData,
                    success: $.proxy(function (tRes) {
                        this.getView().byId("idBtnSave").setEnabled(false);
                        this.getView().byId("button2").setVisible(true);
                        this.getView().byId("button1").setVisible(false);
                        this.loader.close();
                        MessageToast.show("Workflow for info record creation is triggered")
                    }).bind(this),
                    error : function(res){
                        //MessageBox.error("An error occured. Please try again");
                        this.loader.close();
                        MessageBox.error("Internal Server Error. Please contact your administrator");
                    }.bind(this)
                })
            },
            Close: function(){
                this.getOwnerComponent().getRouter().navTo("Master");
                this.enableFields();
            },
            disableFields: function () {
                this.form.forEach(function (eKey) {
                    if (this.getView().byId(eKey).getProperty("editable"))
                        this.getView().byId(eKey).setProperty("editable", false)
                }
                .bind(this))
            },
            enableFields: function () {
                this.form.forEach(function (eKey) {
                    if (eKey == "PurchaseInfoCategory") {
                        this.getView().byId(eKey).setSelectedKey("0");
                    } else {
                        if (eKey == "PriceUnit") {
                            this.getView().byId(eKey).setValue("1");
                        } else {
                        this.getView().byId(eKey).setValue(""); }
                    }
                    if (!this.getView().byId(eKey).getProperty("editable")) {
                        this.getView().byId(eKey).setProperty("editable", true)
                    }
                }
                .bind(this))
                this.getView().byId("PurchaseInfoRecordNum").setValue("")
                this.getView().byId("MaterialDesc").setText("")
                this.getView().byId("MaterialGroupDesc").setText("")
                this.getView().byId("VendorDesc").setText("")
                this.getView().byId("PurchaseOrganizationDesc").setText("")
                this.getView().byId("PlantDesc").setText("")
                this.getView().byId("PurchaseGroupDesc").setText("")
                this.getView().byId("CompanyCode").setValue("")
            },
            validate: function () {
                var tFlag = 0;
                var errors = [];
                this.getView().getModel("iModel").setProperty("/Errors", {});
                this.form.forEach(function (aKey) {
                    if (aKey != "PurchaseInfoCategory" && aKey != "MaterialGroup") {
                        var iVal = this.getView().byId(aKey).getValue();
                        if (iVal == "") {
                            this.getView().byId(aKey).setValueState("Error");
                            errors.push({ "Key": aKey, "description": "This is a Mandatory Field" })
                            tFlag = 1
                        } else {
                            if(iVal.includes("*",0)){
                                this.getView().byId(aKey).setValueState("Error");
                                errors.push({ "Key": aKey, "description": "Please enter a value without a wildcard" })
                                tFlag = 1
                            }
                            if (aKey == "StandardQuantity") {
                                var sRegex = /^\d{1,9}(\.\d{1,3})?$/;
                                if (!sRegex.test(this.getView().byId(aKey).getValue())) {
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({ "Key": aKey, "description": "Please enter a number from 1 to 999,999,999,999" });
                                    tFlag = 1
                                }
                                if(this.getView().byId(aKey).getValue() == "0"){
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({"Key":aKey,"description":  "Standard Quantity cannot be 0. Please enter a number from 1 to 999,999,999.999"});
                                    tFlag = 1
                                }
                            }
                            if (aKey == "PlannedDeliveryTime") {
                                var sRegex = /^\d{1,3}?$/;
                                if (!sRegex.test(this.getView().byId(aKey).getValue())) {
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({ "Key": aKey, "description": "Please enter a Planned Delivery Time as number of days between 1 and 999" });
                                    tFlag = 1
                                }
                                if(this.getView().byId(aKey).getValue() == "0"){
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({"Key":aKey,"description":  "Planned Delivery Time cannot be 0. Please enter a Planned Delivery Time as number of days between 1 and 999"});
                                    tFlag = 1
                                }
                            }
                            if (aKey == "PriceUnit") {
                                var sRegex = /^\d{1,5}?$/;
                                if (!sRegex.test(this.getView().byId(aKey).getValue())) {
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({ "Key": aKey, "description": "Please enter a Price Unit between 1 and 99999" });
                                    tFlag = 1
                                }
                                if(this.getView().byId(aKey).getValue() == "0"){
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({"Key":aKey,"description":  "Price Unit cannot be 0. Please enter a Price Unit between 1 and 99999"});
                                    tFlag = 1
                                }
                            }
                            if (aKey == "Price") {
                                var sRegex = /^\d{1,9}(\.\d{1,2})?$/;
                                if (!sRegex.test(this.getView().byId(aKey).getValue())) {
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({ "Key": aKey, "description": "Please enter price of material from 1 to 999,999,999.99" });
                                    tFlag = 1
                                }
                                if(this.getView().byId(aKey).getValue() == "0"){
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({"Key":aKey,"description":  "Price cannot be 0. Please enter price of material from 1 to 999,999,999.99"});
                                    tFlag = 1
                                }
                            }
                        }
                    }
                    if (aKey == "ValidTo") {
                        if (this.getView().byId(aKey).getValue() != "") {
                            if (this.getView().byId(aKey).isValidValue()) {
                                if(this.getView().byId("ValidFrom").getValue() != ""){
                                    if (this.dateFormat(this.getView().byId(aKey).getValue(), "yyyyMMdd") < this.dateFormat(this.getView().byId("ValidFrom").getValue(), "yyyyMMdd")) {
                                        this.getView().byId(aKey).setValueState("Error");
                                        errors.push({ "Key": aKey, "description": "Valid To cannot be lower than Valid From" });
                                        tFlag = 1
                                    }
                                }
                            } else {
                                this.getView().byId(aKey).setValueState("Error");
                                errors.push({ "Key": aKey, "description": "Please enter a correct date" });
                                tFlag = 1
                            }
                        }
                    }
                    if (aKey == "ValidFrom") {
                        if (this.getView().byId(aKey).getValue() != "") {
                            if (!this.getView().byId(aKey).isValidValue()) {
                                this.getView().byId(aKey).setValueState("Error");
                                errors.push({ "Key": aKey, "description": "Please enter a correct date" });
                                tFlag = 1
                            }
                        }
                    }
                }
                    .bind(this));
                if (tFlag) {
                    this.getView().getModel("iModel").setProperty("/Errors", errors)
                    this.getView().byId("messagePopoverBtn").setEnabled(true);
                    this.getView().byId("messagePopoverBtn").setVisible(true);
                    if (!this.oMessagePopover) {
                        this.createMessagePopover();
                    }
                    this.getView().getModel("iModel").refresh(true)
                    this.getView().byId("messagePopoverBtn").setType("Reject");
                    setTimeout(function () {
                        this.oMessagePopover.openBy(this.getView().byId("messagePopoverBtn"));
                    }.bind(this), 100);
                    return false
                } else {
                    this.getView().byId("messagePopoverBtn").setType("Default");
                    this.getView().getModel("iModel").refresh(true)
                    this.getView().byId("messagePopoverBtn").setEnabled(false);
                    this.getView().byId("messagePopoverBtn").setVisible(false);
                    return true
                }
            },
            resetValidate: function () {
                this.getView().getModel("iModel").setProperty("/Errors", {});
                this.getView().byId("messagePopoverBtn").setType("Default");
                this.getView().byId("messagePopoverBtn").setEnabled(false);
                this.getView().byId("messagePopoverBtn").setVisible(false);
                this.form.forEach(function (eKey) {
                    this.getView().byId(eKey).setValueState("None");
                }
                    .bind(this))
            },
            handleMessagePopoverPress: function (oEvent) {
                if (!this.oMessagePopover) {
                    this.createMessagePopover();
                }
                this.oMessagePopover.toggle(oEvent.getSource());
            },
            createMessagePopover: function () {
                var oMessageTemplate = new MessageItem({
                    type: 'Error',
                    title: '{iModel>description}',
                    subtitle: '{iModel>Key}'
                });

                this.oMessagePopover = new MessagePopover({
                    items: {
                        path: 'iModel>/Errors',
                        template: oMessageTemplate
                    }
                });
                this.getView().byId("messagePopoverBtn").addDependent(this.oMessagePopover);
            },
         _bfetchToken: function () {
            var btoken;
            var sUrl = this._getRulesRuntimeBaseURL() + "/v1/rules/xsrf-token";
            $.ajax({
                url: sUrl,
                method: "GET",
                async: false,
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success: function (result, xhr, data) {
                    btoken = data.getResponseHeader("X-CSRF-Token");
                },
                error : function(res){
                    //MessageBox.error("An error occured. Please try again");
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            });
            return btoken;
        },
                getWorkflowDef: function (tToken, btoken) {
                    this.loader.open();
                    var hData = JSON.stringify({
                    RuleServiceId: "e021ed25e80b440d92bbab78c0b963db",
                    RuleServiceRevision: "2006",
                    Vocabulary: [{
                        PurchaseInfoRecord: {
                            Action: "Create",
                            Plant: this.getView().getModel('iModel').getProperty("/PurchaseInfoRecordDetails/PurchaseInfoRecordDetails/Plant"),
                            PurchaseOrganization: this.getView().getModel('iModel').getProperty("/PurchaseInfoRecordDetails/PurchaseInfoRecordDetails/PurchaseOrganization"),
                            PurchaseInfoCategory: this.getView().getModel('iModel').getProperty("/PurchaseInfoRecordDetails/PurchaseInfoRecordDetails/PurchaseInfoCategory"),
                            MaterialGroup: this.getView().getModel('iModel').getProperty("/PurchaseInfoRecordDetails/PurchaseInfoRecordDetails/MaterialGroup") ,
                            OldPrice: parseFloat(this.getView().byId("OldPrice").getValue() == "" ? 0 : this.getView().byId("OldPrice").getValue()),
                            NewPrice: parseFloat(this.getView().byId("Price").getValue()),
                            CompanyCode: this.getView().getModel('iModel').getProperty("/PurchaseInfoRecordDetails/PurchaseInfoRecordDetails/CompanyCode") 
                            }
                        }
                    ]
                });
                var sUrl = this._getRulesRuntimeBaseURL() + "/rest/v2/rule-services";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {
                        "X-CSRF-Token": btoken
                    },
                    data: hData,
                    success: $.proxy(function(response){
                        this._checkApprovalStatus(tToken, response.Result[0].ProcessVariantDetails.ProcessVariantId)
                        this.loader.close();
                    }.bind(this)),
                    error : function(res){
                        //MessageBox.error("An error occured. Please try again");
                        this.loader.close();
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                    }.bind(this)
                })
            },
            _checkApprovalStatus: function(token, ProcessVariantId) {
                this.loader.open();
                var data = $.param({
                definitionId: ProcessVariantId,
                status: ["RUNNING", "ERRONEOUS", "SUSPENDED"],
                "attributes.Material": this.getView().byId("Material").getValue(),
                "attributes.Vendor": this.getView().byId("Vendor").getValue(),
                "attributes.PurchaseOrganization": this.getView().byId("PurchaseOrganization").getValue(),
                "attributes.Plant": this.getView().byId("Plant").getValue(),
                "attributes.PurchaseInfoCategory": this.getView().byId("PurchaseInfoCategory").getSelectedKey()
            }, true);
            var sUrl = this._getWorkflowRuntimeBaseURL() + "/workflow-instances";
            $.ajax({
                url: sUrl,
                method: "GET",
                async: false,
                contentType: "application/json",
                headers: {
                    "X-CSRF-Token": token
                },
                data: data,
                success: $.proxy(function (result) {                        
                        if(result != ""){
                            if(result.length >=1){
                                if(result[0].startedBy != undefined){
                                    MessageBox.error("Purchase info record approval with similar data is already initiated by "+result[0].startedBy)
                                }else{
                                    MessageBox.error("Purchase info record approval with similar data is already initiated")
                                }
                            }
                        }else{
                        this.disableFields();
                        this._initiateCreate(token, ProcessVariantId);
                        }
                        this.loader.close();
                }).bind(this),
                error : function(res){
                    //MessageBox.error("An error occured. Please try again");
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                    this.loader.close();
                }.bind(this)
            });
        },
            getCurrency: function(tToken, btoken) {
                var language = window.navigator.language;
                language = language.split("-")
                language = language[0].toUpperCase();
                var currdata = JSON.stringify({
                RuleServiceId: "d885808d318e42b6bb4f38951709e6ea",
                RuleServiceRevision: "2006",
                    Vocabulary: [{ Language: {LanguageKey: language }}]
                        });
                var sUrl = this._getRulesRuntimeBaseURL() + "/rest/v2/rule-services";        
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {
                        "X-CSRF-Token": btoken
                    },
                    data: currdata,
                    success: $.proxy(function(response){
                        if(response.Result.length >= 1){
                            this.getView().getModel("iModel").setProperty("/CurrencyList",response.Result[0].CurrencyList)
                        }
                    }.bind(this)),
                    error : function(res){
                        this.getView().getModel("iModel").setProperty("/CurrencyList", {})
                        this.getView().getModel("iModel").refresh(true)
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                    }.bind(this)
                })
            },
            handleValueHelpCurrency: function (oItem) {
                this.getView().getModel("iModel").setProperty("/CurrencyList", {});
                this.getView().getModel("iModel").setProperty("/CurrencyListCount", 0);
                this.getView().getModel("iModel").refresh(true)
                if (!this._valueHelpDialogCurrency) {
                    this._valueHelpDialogCurrency = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.Currency", this);
                    this.getView().addDependent(this._valueHelpDialogCurrency)
                }
                this._valueHelpDialogCurrency.open();
                this._valueHelpDialogCurrency.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchCurrency: function(eItem){
                var token = this._bfetchToken();
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                    this.getCurrency("",token);
                }else{
                    MessageToast.show("Please enter search input");
                    return;
                }
                if(tVal.includes("*",0)){
                    tVal = tVal.split("*");
                    var valLength = tVal.length;
                    var preLength = 0;
                    var cval = "";
                    for(var i = 0; i < valLength; i++){
                        if(tVal[i] != ""){
                            var currLength = tVal[i].length;
                            if(preLength == 0){
                                preLength = currLength;
                                cval = tVal[i]
                            }else{
                                if(currLength > preLength){
                                    preLength = currLength;
                                    cval = tVal[i]
                                }
                            }
                        }
                    }
                    tVal = cval;
                }
                var aFilter = [new Filter("CurrencyCode", FilterOperator.Contains, tVal), new Filter("CurrencyDescription", FilterOperator.Contains, tVal)];
                var nFilter = new Filter(aFilter, false);
                eItem.getSource().getBinding("items").filter([nFilter]);
                if(eItem.getSource().getBinding("items").iLength == 0){
                    this._valueHelpDialogCurrency.setNoDataText("No data");
                    MessageToast.show("No matching data found");
                }
                this.getView().getModel("iModel").setProperty("/CurrencyListCount", eItem.getSource().getBinding("items").iLength);
            },
            _handleValueHelpCurrencyClose: function(eItem){
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("Currency");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                }
                eItem.getSource().getBinding("items").filter([])
                if(this.getView().byId("Currency").getValue() != ""){
                    this.getView().byId("Currency").setValueState("None")
                }
            },
            getOrderUnit: function(tToken, btoken) {
                var language = window.navigator.language;
                language = language.split("-")
                language = language[0].toUpperCase();
                var currdata = JSON.stringify({
                RuleServiceId: "5a358976212b4976800cfd476ea65262",
                RuleServiceRevision: "2006",
                    Vocabulary: [{ Language: {LanguageKey: language }}]
                        });
                var sUrl = this._getRulesRuntimeBaseURL() + "/rest/v2/rule-services";
                $.ajax({
                    url: sUrl,
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {
                        "X-CSRF-Token": btoken
                    },
                    data: currdata,
                    success: $.proxy(function(response){
                        if(response.Result.length >= 1){
                            this.getView().getModel("iModel").setProperty("/OrderUnitList",response.Result[0].UnitOfMeasurementList)
                        }
                    }.bind(this)),
                    error : function(res){
                        this.getView().getModel("iModel").setProperty("/OrderUnitList", {})
                        this.getView().getModel("iModel").refresh(true)
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                    }.bind(this)
                })
            },
            handleValueHelpOrderUnit: function (oItem) {
                this.getView().getModel("iModel").setProperty("/OrderUnitList", {})
                this.getView().getModel("iModel").setProperty("/OrderUnitListCount", 0);
                this.getView().getModel("iModel").refresh(true)
                if (!this._valueHelpDialogOrderUnit) {
                    this._valueHelpDialogOrderUnit = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.OrderUnit", this);
                    this.getView().addDependent(this._valueHelpDialogOrderUnit)
                }
                this._valueHelpDialogOrderUnit.open();
                this._valueHelpDialogOrderUnit.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchOrderUnit: function(eItem){
                var token = this._bfetchToken();
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                    this.getOrderUnit("",token);
                }else{
                    MessageToast.show("Please enter search input");
                    return;
                }
                if(tVal.includes("*",0)){
                    tVal = tVal.split("*");
                    var valLength = tVal.length;
                    var preLength = 0;
                    var cval = "";
                    for(var i = 0; i < valLength; i++){
                        if(tVal[i] != ""){
                            var currLength = tVal[i].length;
                            if(preLength == 0){
                                preLength = currLength;
                                cval = tVal[i]
                            }else{
                                if(currLength > preLength){
                                    preLength = currLength;
                                    cval = tVal[i]
                                }
                            }
                        }
                    }
                    tVal = cval;
                }
                var aFilter = [new Filter("UnitOfMeasurement", FilterOperator.Contains, tVal), new Filter("Description", FilterOperator.Contains, tVal)];
                var nFilter = new Filter(aFilter, false);
                eItem.getSource().getBinding("items").filter([nFilter]);
                if(eItem.getSource().getBinding("items").iLength == 0){
                    this._valueHelpDialogOrderUnit.setNoDataText("No data");
                    MessageToast.show("No matching data found")
                }
                this.getView().getModel("iModel").setProperty("/OrderUnitListCount", eItem.getSource().getBinding("items").iLength);
            },
            _getCPIRuntimeBaseURL: function () {
              var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
              var appPath = appId.replaceAll(".", "/");
              var appModulePath = jQuery.sap.getModulePath(appPath);

              return appModulePath + "/CPI/http";
            },
            _getWorkflowRuntimeBaseURL: function () {
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = jQuery.sap.getModulePath(appPath);

            return appModulePath + "/bpmworkflowruntime/v1";
            },
            _getRulesRuntimeBaseURL: function () {
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = jQuery.sap.getModulePath(appPath);

            return appModulePath + "/bpmrulesruntime/rules-service";
            },
            _handleValueHelpOrderUnitClose: function(eItem){
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("OrderUnit");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                }
                eItem.getSource().getBinding("items").filter([]);
                if(this.getView().byId("OrderUnit").getValue() != ""){
                    this.getView().byId("OrderUnit").setValueState("None");
                }
            }
        })
    });