sap.ui.define(["sap/m/MessageToast",
    "sap/ui/core/mvc/Controller", "sap/ui/core/routing/History", "sap/m/MessageBox", "sap/m/BusyDialog"
], function (MessageToast, Controller, History, MessageBox, BusyDialog) {
    "use strict";
    return Controller.extend("com.sap.cp.dpa.ManagePurchaseInfoRecord.controller.DisplayPurchaseInfoRecord", {
        defaultTabKey: "General",
        loader: new sap.m.BusyDialog(),
        handleValueHelpMaterial: function(eVal) {
            var tData = JSON.stringify({
                Requester: {
                    UserId: this.getView().getModel("iModel").getProperty("/user/id")
                },
                Material: eVal
            });
            var sUrl = this._getCPIRuntimeBaseURL() + "/MaterialSearch";
            $.ajax({
                url: sUrl,
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {},
                data: tData,
                success: function(eRes) {
                    this.getView().getModel("iModel").setProperty("/MatDes", "");
                    if (eRes.root != "") {
                        setTimeout(function(){
                            this.getView().byId("MaterialDesc").setText(eRes.root.Result.Matl_Desc);
                        }.bind(this), 200);
                    } else {
                        setTimeout(function(){
                            this.getView().byId("MaterialDesc").setText("");
                        }.bind(this), 200);
                    }
                }
                .bind(this),
                error : function(res){
                    this.getView().getModel("iModel").setProperty("/MatDes", "");
                    setTimeout(function(){
                        this.getView().byId("MaterialDesc").setText("");
                    }.bind(this), 200);
                    this.getView().getModel("iModel").refresh(true);
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            })
        },
        handleValueHelpVendor: function(eVal,eName) {
            var tData = JSON.stringify({
                Requester: {
                    UserId: this.getView().getModel("iModel").getProperty("/user/id")
                },
                Vendor: eVal,
                Name1: eName
            });
            var sUrl = this._getCPIRuntimeBaseURL() + "/VendorSearch";
            $.ajax({
                url: sUrl,
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {},
                data: tData,
                success: function(eRes) {
                    this.getView().getModel("iModel").setProperty("/VenDes", "");
                    if (eRes.root != "") {
                        setTimeout(function(){
                            this.getView().byId("VendorDesc").setText(eRes.root.Result.Name1);
                        }.bind(this), 200);
                        
                    } else {
                        setTimeout(function(){
                            this.getView().byId("VendorDesc").setText("");
                        }.bind(this), 200);
                    }
                }
                .bind(this),
                error : function(res){
                    this.getView().getModel("iModel").setProperty("/VenDes", "");
                    setTimeout(function(){
                        this.getView().byId("VendorDesc").setText("");
                    }.bind(this), 200);
                    this.getView().getModel("iModel").refresh(true);
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            })
        },
        handleValueHelpPurchaseGroup: function(eVal) {
            var tData = JSON.stringify({
                Requester: {
                    UserId: this.getView().getModel("iModel").getProperty("/user/id")
                },
                PurchaseGroup: ""
            });
            var sUrl = this._getCPIRuntimeBaseURL() + "/PurchaseGroup";
            $.ajax({
                url: sUrl,
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {},
                data: tData,
                success: $.proxy(function(eRes) {
                    var tFormat = {};
                    if (eRes.root != "") {
                    for (var a = 0; a < eRes.root.Result.length; a++) {
                        tFormat[eRes.root.Result[a].PurchaseGroup] = eRes.root.Result[a].Description
                    }
                    this.getView().getModel("iModel").setProperty("/FormattedPurGrpList", tFormat)
                } else {MessageToast.show("No data found")}
                }).bind(this),
                error : function(res){
                    this.getView().getModel("iModel").setProperty("/FormattedPurGrpList", {});
                    this.getView().getModel("iModel").refresh(true);
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            })
        },
        handleValueHelpPlantSearch: function(eVal) {
            var tData = JSON.stringify({
                Requester: {
                    UserId: this.getView().getModel("iModel").getProperty("/user/id")
                },
                Plant: ""
            });
            var sUrl = this._getCPIRuntimeBaseURL() + "/PlantSearch";
            $.ajax({
                url: sUrl,
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {},
                data: tData,
                success: $.proxy(function(eRes) {
                    var tFormat = {};
                    if (eRes.Result != "") {
                    for (var a = 0; a < eRes.Result.length; a++) {
                        tFormat[eRes.Result[a].Plant] = {
                            Name1: eRes.Result[a].Name1,
                            CompanyCode: eRes.Result[a].CompanyCode
                        }
                    }
                    this.getView().getModel("iModel").setProperty("/FormattedPlantList", tFormat)
                } else {MessageToast.show("No data found")}
                }).bind(this),
                error : function(res){
                    this.getView().getModel("iModel").setProperty("/FormattedPlantList", {});
                    this.getView().getModel("iModel").refresh(true);
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            })
        },
        getRouter: function () {
            return sap.ui.core.UIComponent.getRouterFor(this);
        },
        
        onInit: function () {
            this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
        },
        onRouteMatched: function (event) {
            if (event.getParameter("name") == "DisplayPurchaseInfoRecord") {
                this.handleValueHelpPurchaseGroup("")
                this.handleValueHelpPlantSearch("");
                this._getDeatailsItem();
                this.setTab();
                this.getView().setModel(this.getOwnerComponent().getModel("iModel"), "iModel");
            }
        },
        setTab: function() {
            this.getView().byId("idIconTabBarNoIcons").setSelectedKey(this.defaultTabKey)
        },
        _getDeatailsItem: function () {
            this.loader.open();
            var oModel = this.getView().getModel("iModel");
            var data = this.prepareData();
            var jsondata = JSON.stringify(data);
            var sUrl = this._getCPIRuntimeBaseURL() + "/PIRList";
            $.ajax({
                url: sUrl,
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {
                },
                data: jsondata,
                success: $.proxy(function (result) { 
                    var allData = this.getView().getModel("iModel").getProperty("/selItem");  
                    this.getView().byId("MaterialDesc").setText(allData.Material != ""? this.handleValueHelpMaterial(allData.Material): "");
                    this.getView().byId("MaterialGroupDesc").setText(allData.MaterialGroup != ""? this.getView().getModel("iModel").getProperty("/FormattedMaterialGroupList/"+allData.MaterialGroup) : "");
                    this.getView().byId("VendorDesc").setText(allData.Vendor != ""? this.handleValueHelpVendor(allData.Vendor,"") : "");
                    this.getView().byId("PurchaseOrganizationDesc").setText(allData.PurhOrg != ""? this.getView().getModel("iModel").getProperty("/FormattedPurOrgList/"+allData.PurhOrg) : "");
                    this.getView().byId("PlantDesc").setText(allData.Plant != "" ? this.getView().getModel("iModel").getProperty("/FormattedPlantList/"+allData.Plant).Name1 : "");
                    this.getView().byId("PurchaseGroupDesc").setText(allData.PurchaseGroup != ""? this.getView().getModel("iModel").getProperty("/FormattedPurGrpList/"+allData.PurchaseGroup) : "");
                    this.getView().byId("CompanyCode").setValue(allData.Plant != ""? this.getView().getModel("iModel").getProperty("/FormattedPlantList/"+allData.Plant).CompanyCode : "");                   
                    var d = new Date();
                    var month = d.getMonth()+1;
                    var day = d.getDate();
                    var output = d.getFullYear() +
                        (month<10 ? '0' : '') + month +
                        (day<10 ? '0' : '') + day;
                    if(result.root.Result != ""){
                        if(result.root.Result.PIRList.length == undefined){
                            if(result.root.Result.PIRList.ValidityStartDate <= output && result.root.Result.PIRList.ValidityEndDate >= output){
                                    var allData = this.getView().getModel("iModel").getProperty("/selItem");                        
                                    allData = Object.assign({}, allData, {ValidityStartDate: result.root.Result.PIRList.ValidityStartDate});
                                    allData = Object.assign({}, allData, {ValidityEndDate: result.root.Result.PIRList.ValidityEndDate});
                                    this.getView().getModel("iModel").setProperty("/selItem", allData);
                                    this._getCompleteDetails(result.root.Result.PIRList.CondRecNum);
                                }
                        }else{
                            for(var i = 0; i < result.root.Result.PIRList.length; i++){
                                if(result.root.Result.PIRList[i].ValidityStartDate <= output && result.root.Result.PIRList[i].ValidityEndDate >= output){
                                    var allData = this.getView().getModel("iModel").getProperty("/selItem");                        
                                    allData = Object.assign({}, allData, {ValidityStartDate: result.root.Result.PIRList[i].ValidityStartDate});
                                    allData = Object.assign({}, allData, {ValidityEndDate: result.root.Result.PIRList[i].ValidityEndDate});
                                    this.getView().getModel("iModel").setProperty("/selItem", allData);
                                    this._getCompleteDetails(result.root.Result.PIRList[i].CondRecNum);
                                }
                            }
                        }
                    }
                    this.loader.close();
                }).bind(this),
                error : function(res){
                    //MessageBox.error("An error occured. Please go back try again");
                    this.loader.close();
                    this.getView().byId("MaterialDesc").setText("");
                    this.getView().byId("MaterialGroupDesc").setText("");
                    this.getView().byId("VendorDesc").setText("");
                    this.getView().byId("PurchaseOrganizationDesc").setText("");
                    this.getView().byId("PlantDesc").setText("");
                    this.getView().byId("PurchaseGroupDesc").setText("");
                    this.getView().byId("CompanyCode").setValue("");
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            });
        },
        _getCompleteDetails: function(CondRecNum){
            this.loader.open();
            var data = {
                "Requester": {
                    "UserId": this.getView().getModel("iModel").getProperty("/user/id"),
                    "RequestType": "Display"
                },
                "PIR_Criteria": {
                    "InfoRecNum": CondRecNum
                }
            };
            var jsondata = JSON.stringify(data);
            var sUrl = this._getCPIRuntimeBaseURL() + "/PIRListKONP";
            $.ajax({
                url: sUrl,
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {
                },
                data: jsondata,
                success: $.proxy(function (result) {                    
                    if(result.Result == undefined){
                        var allData = this.getView().getModel("iModel").getProperty("/selItem");                        
                        allData = Object.assign({}, allData, result.root.Result.PIRList);   
                        this.getView().getModel("iModel").setProperty("/selItem", allData);
                        this.getView().getModel("iModel").refresh(true);
                    }
                    this.loader.close();
                }).bind(this),
                error : function(res){
                    //MessageBox.error("An error occured. Please go back try again");
                    this.getView().byId("MaterialDesc").setText("");
                    this.getView().byId("MaterialGroupDesc").setText("");
                    this.getView().byId("VendorDesc").setText("");
                    this.getView().byId("PurchaseOrganizationDesc").setText("");
                    this.getView().byId("PlantDesc").setText("");
                    this.getView().byId("PurchaseGroupDesc").setText("");
                    this.getView().byId("CompanyCode").setValue("");
                    this.loader.close();
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            });
        },  
        _getCPIRuntimeBaseURL: function () {
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = jQuery.sap.getModulePath(appPath);

            return appModulePath + "/CPI/http";
        }, 
        prepareData: function () {
            var data = {
                "Requester": {
                    "UserId": this.getView().getModel("iModel").getProperty("/user/id"),
                    "RequestType": "Display"
                },
                "PIR_Criteria": {
                    "Material": this.getView().getModel('iModel').getProperty("/selItem/Material"),
                    "Vendor": this.getView().getModel('iModel').getProperty("/selItem/Vendor"),
                    "PurhOrg": this.getView().getModel('iModel').getProperty("/selItem/PurhOrg"),
                    "Plant": this.getView().getModel('iModel').getProperty("/selItem/Plant"),
                    "PurInfoCat": this.getView().byId("PurchaseInfoCategory").getSelectedKey()
                }
            };
            return data;
        }
    });
});