sap.ui.define([
	"com/sap/cp/dpa/ManagePurchaseInfoRecord/test/unit/controller/Create.controller"
], function () {
	"use strict";
});