sap.ui.define(["sap/m/MessageToast",
    "sap/ui/core/mvc/Controller", "sap/ui/core/routing/History",'sap/m/MessageItem',
'sap/m/MessagePopover', "sap/m/MessageBox","sap/ui/model/Filter", "sap/ui/model/FilterOperator",
"sap/ui/core/Fragment", "sap/m/BusyDialog", "sap/m/Dialog","sap/ui/layout/HorizontalLayout"
], function (MessageToast, Controller, History, MessageItem, MessagePopover, MessageBox, Filter, FilterOperator,
    Fragment, BusyDialog, Dialog, HorizontalLayout) {
    "use strict";
    return Controller.extend("com.sap.cp.dpa.ManagePurchaseInfoRecord.controller.ChangePurchaseInfoRecord", {
        form: ["Material", "MaterialGroup", "Vendor", "PurchaseOrganization", "Plant", "PurchaseInfoCategory", "PurchaseGroup", "PlannedDeliveryTime", "StandardQuantity", "Price", "Currency", "PriceUnit", "OrderUnit", "ValidFrom", "ValidTo"],
        defaultTabKey: "General",
        loader: new sap.m.BusyDialog(),
        editFlag: 0,
        handleValueHelpMaterial: function(eVal) {
            var tData = JSON.stringify({
                Requester: {
                    UserId: this.getView().getModel("iModel").getProperty("/user/id")
                },
                Material: eVal
            });
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/CPI/http/MaterialSearch",
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {},
                data: tData,
                success: function(eRes) {
                    this.getView().getModel("iModel").setProperty("/MatDes", "");
                    if (eRes.root != "") {
                        setTimeout(function(){
                            this.getView().byId("MaterialDesc").setText(eRes.root.Result.Matl_Desc);
                        }.bind(this), 200);
                    } else {
                        setTimeout(function(){
                            this.getView().byId("MaterialDesc").setText("");
                        }.bind(this), 200);
                    }
                }
                .bind(this),
                error : function(res){
                    this.getView().getModel("iModel").setProperty("/MatDes", "");
                    this.getView().getModel("iModel").refresh(true);
                    setTimeout(function(){
                            this.getView().byId("MaterialDesc").setText("");
                        }.bind(this), 200);
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            })
        },
        handleValueHelpVendor: function(eVal,eName) {
            var tData = JSON.stringify({
                Requester: {
                    UserId: this.getView().getModel("iModel").getProperty("/user/id")
                },
                Vendor: eVal,
                Name1: eName
            });
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/CPI/http/VendorSearch",
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {},
                data: tData,
                success: function(eRes) {
                    this.getView().getModel("iModel").setProperty("/VenDes", "");
                    if (eRes.root != "") {
                        setTimeout(function(){
                            this.getView().byId("VendorDesc").setText(eRes.root.Result.Name1);
                        }.bind(this), 200);
                        
                    } else {
                        setTimeout(function(){
                            this.getView().byId("VendorDesc").setText("");
                        }.bind(this), 200);
                        
                    }
                }
                .bind(this),
                error : function(res){
                    this.getView().getModel("iModel").setProperty("/VenDes", "");
                    this.getView().getModel("iModel").refresh(true)
                    setTimeout(function(){
                            this.getView().byId("VendorDesc").setText("");
                        }.bind(this), 200);
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            })
        },
        handleValueHelpPurchaseGroup: function(eVal) {
            var tData = JSON.stringify({
                Requester: {
                    UserId: this.getView().getModel("iModel").getProperty("/user/id")
                },
                PurchaseGroup: ""
            });
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/CPI/http/PurchaseGroup",
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {},
                data: tData,
                success: $.proxy(function(eRes) {
                    var tFormat = {};
                    if (eRes.root != "") {
                    for (var a = 0; a < eRes.root.Result.length; a++) {
                        tFormat[eRes.root.Result[a].PurchaseGroup] = eRes.root.Result[a].Description
                    }
                    this.getView().getModel("iModel").setProperty("/FormattedPurGrpList", tFormat)
                    this.getView().getModel("iModel").setProperty("/PurGrpList", eRes.root.Result);
                } else {MessageToast.show("No data found")}
                }).bind(this),
                error : function(res){
                    this.getView().getModel("iModel").setProperty("/FormattedPurGrpList", {});
                    this.getView().getModel("iModel").setProperty("/PurGrpList", {});
                    this.getView().getModel("iModel").refresh(true);
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            })
        },
         handleValueHelpPG: function (eItem) {
            this.getView().getModel("iModel").setProperty("/FormattedPurGrpList", {});
            this.getView().getModel("iModel").setProperty("/PurGrpList", {});
            this.getView().getModel("iModel").setProperty("/PurGrpListCount", 0);
            this.getView().getModel("iModel").refresh(true);
            if (!this._valueHelpDialogPG) {
                this._valueHelpDialogPG = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.PurchaseGroup", this);
                this.getView().addDependent(this._valueHelpDialogPG)
            }   
            this._valueHelpDialogPG.open();
            this._valueHelpDialogPG.setNoDataText("Please enter value for search");
        },
        handleValueHelpSearchPurchaseGroup: function (eItem) {
            var tVal = eItem.getParameter("value");
            if(tVal != ""){
                this.handleValueHelpPurchaseGroup("");
            }else{
                MessageToast.show("Please enter search input");
                return;
            }
            if(tVal.includes("*",0)){
                tVal = tVal.split("*");
                var valLength = tVal.length;
                var preLength = 0;
                var cval = "";
                for(var i = 0; i < valLength; i++){
                    if(tVal[i] != ""){
                        var currLength = tVal[i].length;
                        if(preLength == 0){
                            preLength = currLength;
                            cval = tVal[i]
                        }else{
                            if(currLength > preLength){
                                preLength = currLength;
                                cval = tVal[i]
                            }
                        }
                    }
                }
                tVal = cval;
            }
            var aFilter = [new Filter("PurchaseGroup", FilterOperator.Contains, tVal), new Filter("Description", FilterOperator.Contains, tVal)];
            var nFilter = new Filter(aFilter, false);
            eItem.getSource().getBinding("items").filter([nFilter])
            if(eItem.getSource().getBinding("items").iLength == 0){
                this._valueHelpDialogPG.setNoDataText("No data");
                MessageToast.show("No matching data found")
            }
            this.getView().getModel("iModel").setProperty("/PurGrpListCount", eItem.getSource().getBinding("items").iLength);
        },
        _handleValueHelpPGClose: function (eItem) {
            var tItem = eItem.getParameter("selectedItem");
            if (tItem) {
                var aItem = this.getView().byId("PurchaseGroup");
                aItem.setValue(tItem.getTitle())
                aItem.setValueState("None");
                this.getView().byId("PurchaseGroupDesc").setText(tItem.getDescription())
            }
            eItem.getSource().getBinding("items").filter([])
        },
        handleValueHelpPlantSearch: function(eVal) {
            var tData = JSON.stringify({
                Requester: {
                    UserId: this.getView().getModel("iModel").getProperty("/user/id")
                },
                Plant: ""
            });
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/CPI/http/PlantSearch",
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {},
                data: tData,
                success: $.proxy(function(eRes) {
                    var tFormat = {};
                    if (eRes.Result != "") {
                    for (var a = 0; a < eRes.Result.length; a++) {
                        tFormat[eRes.Result[a].Plant] = {
                            Name1: eRes.Result[a].Name1,
                            CompanyCode: eRes.Result[a].CompanyCode
                        }
                    }
                    this.getView().getModel("iModel").setProperty("/FormattedPlantList", tFormat)
                } else {MessageToast.show("No data found")}
                }).bind(this),
                error : function(res){
                    this.getView().getModel("iModel").setProperty("/FormattedPlantList", {});
                    this.getView().getModel("iModel").refresh(true);
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            })
        },
        LiveChange: function(oEvent) {
            if(this.getView().byId("idBtnSave").getEnabled() == false){
                this.getView().byId("idBtnSave").setEnabled(true);
            }
            var value = oEvent.getParameters().newValue;
            var name = oEvent.getParameters().id;
            name = name.split("--");
            if (value != ""){
                this.getView().byId(name[1]).setValueState("None");
            }
            },
        ValueChange: function (oEvent) {
            if(!this.editFlag)
                this.editFlag = !this.editFlag;

            if(this.getView().byId("idBtnSave").getEnabled() == false){
                this.getView().byId("idBtnSave").setEnabled(true);
            }
            var value = oEvent.getParameters().newValue;
            var name = oEvent.getParameters().id;
            name = name.split("--");
            if (value != ""){
                this.getView().byId(name[1]).setValueState("None");
            }
            if (name[1] == "PurchaseGroup") {
                if(value != ""){
                    this.handleValueHelpPurchaseGroup("");
                        var matGrp = "";
                        matGrp = this.getView().getModel("iModel").getProperty("/FormattedPurGrpList/"+value);
                        if(matGrp != undefined){
                            this.getView().byId("PurchaseGroupDesc").setText(matGrp);
                        }else{
                            MessageBox.error("Purchasing Group "+ value +" is not found")
                            this.getView().byId("PurchaseGroupDesc").setText("");
                        }
                }else{
                    this.getView().byId("PurchaseGroupDesc").setText("");
                }
            }
        },
        getFormData: function () {
            var tData = {
                "RequestId": "Purchase Info Record_Approval_00_001",
                "Title": "Purchase Info Record Data Maintenance",
                "Requester": {
                    "Name": this.getView().getModel("iModel").getProperty("/user/name"),
                    "Email": this.getView().getModel("iModel").getProperty("/user/email"),
                    "UserId": this.getView().getModel("iModel").getProperty("/user/UserId"),
                    "Comments": this.getView().getModel("iModel").getProperty("/comment"),
                    "Action": "Change"
                },
                "PurchaseInfoRecordDetails": {}
            };
            this.form.forEach(function(aKey) {
                            if (aKey == "ValidFrom" || aKey == "ValidTo") {
                                var nData = this.dateFormat(this.getView().byId(aKey).getValue(), "yyyyMMdd")
                                tData["PurchaseInfoRecordDetails"][aKey] = nData
                            }
                            if (aKey == "OldPrice" || aKey == "Price" || aKey == "StandardQuantity" || aKey == "PlannedDeliveryTime") {
                                var nData = parseFloat(this.getView().byId(aKey).getValue())
                                tData["PurchaseInfoRecordDetails"][aKey] = nData
                            }
                            if (aKey == "PurchaseInfoCategory") {
                                var nData = this.getView().byId(aKey).getSelectedKey()
                                tData["PurchaseInfoRecordDetails"][aKey] = nData
                            }
                            if(aKey != "ValidFrom" && aKey != "ValidTo" && aKey != "OldPrice" && aKey != "Price" && aKey != "StandardQuantity" && aKey != "PlannedDeliveryTime"
                            && aKey != "PurchaseInfoCategory"){
                                tData["PurchaseInfoRecordDetails"][aKey] = this.getView().byId(aKey).getValue().toUpperCase();
                            }                            
                        }.bind(this))
                        tData["PurchaseInfoRecordDetails"]["PurchaseInfoRecordNum"] = this.getView().byId("PurchaseInfoRecordNum").getValue()
                        tData["PurchaseInfoRecordDetails"]["MaterialDesc"] = this.getView().byId("MaterialDesc").getText()
                        tData["PurchaseInfoRecordDetails"]["MaterialGroupDesc"] = this.getView().byId("MaterialGroupDesc").getText()
                        tData["PurchaseInfoRecordDetails"]["VendorDesc"] = this.getView().byId("VendorDesc").getText()
                        tData["PurchaseInfoRecordDetails"]["PurchaseOrganizationDesc"] = this.getView().byId("PurchaseOrganizationDesc").getText()
                        tData["PurchaseInfoRecordDetails"]["PlantDesc"] = this.getView().byId("PlantDesc").getText()
                        tData["PurchaseInfoRecordDetails"]["PurchaseGroupDesc"] = this.getView().byId("PurchaseGroupDesc").getText()
                        tData["PurchaseInfoRecordDetails"]["CompanyCode"] = this.getView().byId("CompanyCode").getValue()                   
                        tData["PurchaseInfoRecordDetails"]["OldPrice"] = this.getView().byId("OldPrice").getValue()                   
                        tData["PurchaseInfoRecordDetails"]["PurchaseInfoCategoryDesc"] = this.getView().byId("PurchaseInfoCategory").getSelectedItem().getText()         
                        this.getView().getModel("iModel").setProperty("/PurchaseInfoRecordDetails", tData);
        },
        dateFormat: function (date, pattern) {
            var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: pattern
            });
            var formattedDate = dateFormat.parse(date);
            formattedDate = dateFormat.format(formattedDate);
            return formattedDate;
        },
        getRouter: function () {
            return sap.ui.core.UIComponent.getRouterFor(this);
        },
        Cancel: function (oEvent) {
            if(this.editFlag){
                MessageBox.information("There are unsaved changes. Do you still want to navigate?",{
                    title: "Confirmation",
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                    onClose: function (oAction){
                        if(oAction == "YES"){
                            this.getOwnerComponent().getRouter().navTo("Master");
                            this.enableFields();
                        }
                    }.bind(this)
                })
            }else{
                this.getOwnerComponent().getRouter().navTo("Master");
                this.enableFields();
            }
        },
        onInit: function () {
            this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
        },
        onRouteMatched: function (event) {
            if (event.getParameter("name") == "ChangePurchaseInfoRecord") {
                this.editFlag = 0;
                this.getView().byId("button2").setVisible(false);
                this.getView().byId("button1").setVisible(true);
                this.handleValueHelpPurchaseGroup("")
                this.handleValueHelpPlantSearch("");
                this.resetValidate();
                this.enableFields();
                this._getDeatailsItem();
                this.getView().byId("idBtnSave").setEnabled(false);
                this.setTab();
                this.getView().setModel(this.getOwnerComponent().getModel("iModel"), "iModel");
            }
        },
        setTab: function() {
            this.getView().byId("idIconTabBarNoIcons").setSelectedKey(this.defaultTabKey)
        },
        _getDeatailsItem: function () {
            this.loader.open();
            var oModel = this.getView().getModel("iModel");
            var data = this.prepareData();
            var jsondata = JSON.stringify(data);
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/CPI/http/PIRList",
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {
                },
                data: jsondata,
                success: $.proxy(function (result) {  
                    var allData = this.getView().getModel("iModel").getProperty("/selItem");  
                    this.getView().byId("MaterialDesc").setText(allData.Material != ""? this.handleValueHelpMaterial(allData.Material): "");
                    this.getView().byId("MaterialGroupDesc").setText(allData.MaterialGroup != ""? this.getView().getModel("iModel").getProperty("/FormattedMaterialGroupList/"+allData.MaterialGroup) : "");
                    this.getView().byId("VendorDesc").setText(allData.Vendor != ""? this.handleValueHelpVendor(allData.Vendor,"") : "");
                    this.getView().byId("PurchaseOrganizationDesc").setText(allData.PurhOrg != ""? this.getView().getModel("iModel").getProperty("/FormattedPurOrgList/"+allData.PurhOrg) : "");
                    this.getView().byId("PlantDesc").setText(allData.Plant != "" ? this.getView().getModel("iModel").getProperty("/FormattedPlantList/"+allData.Plant).Name1 : "");
                    this.getView().byId("PurchaseGroupDesc").setText(allData.PurchaseGroup != ""? this.getView().getModel("iModel").getProperty("/FormattedPurGrpList/"+allData.PurchaseGroup) : "");
                    this.getView().byId("CompanyCode").setValue(allData.Plant != ""? this.getView().getModel("iModel").getProperty("/FormattedPlantList/"+allData.Plant).CompanyCode : "");                  
                    var d = new Date();
                    var month = d.getMonth()+1;
                    var day = d.getDate();
                    var output = d.getFullYear() +
                        (month<10 ? '0' : '') + month +
                        (day<10 ? '0' : '') + day;
                    if(result.root.Result != ""){
                        if(result.root.Result.PIRList.length == undefined){
                            if(result.root.Result.PIRList.ValidityStartDate <= output && result.root.Result.PIRList.ValidityEndDate >= output){
                                    var allData = this.getView().getModel("iModel").getProperty("/selItem");                        
                                    allData = Object.assign({}, allData, {ValidityStartDate: result.root.Result.PIRList.ValidityStartDate});
                                    allData = Object.assign({}, allData, {ValidityEndDate: result.root.Result.PIRList.ValidityEndDate});
                                    this.getView().getModel("iModel").setProperty("/selItem", allData);
                                    this._getCompleteDetails(result.root.Result.PIRList.CondRecNum);
                                }
                        }else{
                            for(var i = 0; i < result.root.Result.PIRList.length; i++){
                                if(result.root.Result.PIRList[i].ValidityStartDate <= output && result.root.Result.PIRList[i].ValidityEndDate >= output){
                                    var allData = this.getView().getModel("iModel").getProperty("/selItem");                        
                                    allData = Object.assign({}, allData, {ValidityStartDate: result.root.Result.PIRList[i].ValidityStartDate});
                                    allData = Object.assign({}, allData, {ValidityEndDate: result.root.Result.PIRList[i].ValidityEndDate});
                                    this.getView().getModel("iModel").setProperty("/selItem", allData);
                                    this._getCompleteDetails(result.root.Result.PIRList[i].CondRecNum);
                                }
                            }
                        }
                    }
                    this.loader.close();
                }).bind(this),
                error : function(res){
                    //MessageBox.error("An error occured. Please go back try again");
                    this.loader.close();
                    this.getView().byId("MaterialDesc").setText("");
                    this.getView().byId("MaterialGroupDesc").setText("");
                    this.getView().byId("VendorDesc").setText("");
                    this.getView().byId("PurchaseOrganizationDesc").setText("");
                    this.getView().byId("PlantDesc").setText("");
                    this.getView().byId("PurchaseGroupDesc").setText("");
                    this.getView().byId("CompanyCode").setValue("");
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            });
        },
        _getCompleteDetails: function(CondRecNum){
            this.loader.open();
            var data = {
                "Requester": {
                    "UserId": this.getView().getModel("iModel").getProperty("/user/id"),
                    "RequestType": "Display"
                },
                "PIR_Criteria": {
                    "InfoRecNum": CondRecNum
                }
            };
            var jsondata = JSON.stringify(data);
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/CPI/http/PIRListKONP",
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {
                },
                data: jsondata,
                success: $.proxy(function (result) {                    
                    if(result.Result == undefined){
                        var allData = this.getView().getModel("iModel").getProperty("/selItem");                        
                        allData = Object.assign({}, allData, result.root.Result.PIRList);   
                        this.getView().getModel("iModel").setProperty("/selItem", allData);
                        this.getView().getModel("iModel").refresh(true);
                    }
                    this.loader.close();
                }).bind(this),
                error : function(res){
                    //MessageBox.error("An error occured. Please go back try again");
                    this.getView().byId("MaterialDesc").setText("");
                    this.getView().byId("MaterialGroupDesc").setText("");
                    this.getView().byId("VendorDesc").setText("");
                    this.getView().byId("PurchaseOrganizationDesc").setText("");
                    this.getView().byId("PlantDesc").setText("");
                    this.getView().byId("PurchaseGroupDesc").setText("");
                    this.getView().byId("CompanyCode").setValue("");
                    this.loader.close();
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            });
        },
        prepareData: function () {
            var data = {
                "Requester": {
                    "UserId": this.getView().getModel("iModel").getProperty("/user/id"),
                    "RequestType": "Display"
                },
                "PIR_Criteria": {
                    "Material": this.getView().getModel('iModel').getProperty("/selItem/Material"),
                    "Vendor": this.getView().getModel('iModel').getProperty("/selItem/Vendor"),
                    "PurhOrg": this.getView().getModel('iModel').getProperty("/selItem/PurhOrg"),
                    "Plant": this.getView().getModel('iModel').getProperty("/selItem/Plant"),
                    "PurInfoCat": this.getView().byId("PurchaseInfoCategory").getSelectedKey()
                }
            };
            return data;
        },
        _fetchToken: function () {
            var token;
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/bpmworkflowruntime/v1/xsrf-token",
                method: "GET",
                async: false,
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success: function (result, xhr, data) {
                    token = data.getResponseHeader("X-CSRF-Token");
                }
            });
            return token;
        },
        Controller: function () {
            this.resetValidate();
            if (this.validate()) {
                this.getView().getModel("iModel").setProperty("/comment", "")
                var oDialog = new Dialog({
                        title: 'Confirm',
                        type: 'Message',
                        content: [
                            new HorizontalLayout({
                                content: [
                                    new sap.m.Text({ text: 'Are you sure you want to submit?' })
                                ]
                            }),
                            new sap.m.TextArea('confirmDialogTextarea', {
                                width: '100%',
                                placeholder: 'Add note (optional)'
                            })
                        ],
                        beginButton: new sap.m.Button({
                            type: sap.m.ButtonType.Ghost,
                            text: 'Submit',
                            press: function () {
                                var sText = this.getView().getModel("iModel").setProperty("/comment",
                                    sap.ui.getCore().byId('confirmDialogTextarea').getValue());
                                    var eToken = this._fetchToken();
                                this._startInstance(eToken)
                                oDialog.close();
                            }.bind(this)
                        }),
                        endButton: new sap.m.Button({
                            text: 'Cancel',
                            press: function () {
                                oDialog.close();
                            }
                        }),
                        afterClose: function () {
                            oDialog.destroy();
                        }
                    })
                    oDialog.open();                
            }
        },
        _startInstance: function(eToken) {
            this.loader.open();
            this.getFormData();
            var tData = this.getView().getModel("iModel").getProperty("/PurchaseInfoRecordDetails");
            var aData = {
                Requester: {
                    UserId: this.getView().getModel("iModel").getProperty("/user/id"),
                    RequestType: "TestRun"
                },
                PIR_ChangeData: tData.PurchaseInfoRecordDetails
            };
            var iData = JSON.stringify(aData);
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/CPI/http/CheckPIRValidation",
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {},
                data: iData,
                success: $.proxy(function(tRes) {
                    var message = "";
                    if (tRes.Result.Type == "E") {
                        MessageBox.information(tRes.Result.Message)
                    } else{
                        if(tRes.Result.Message.length != undefined){
                            for (var i = 0; i<tRes.Result.Message.length; i++) {
                                if (tRes.Result.Message[i].Type == "E")
                                {
                                    message += tRes.Result.Message[i].Message + "\n" 
                                }
                            }
                        }else{
                            if (tRes.Result.Message.Type == "E")
                            {
                                message += tRes.Result.Message.Message + "\n" 
                            }
                        }
                        if(message.length > 1){
                            MessageBox.error(message);
                        }else{
                            var btoken = this._bfetchToken();
                            this.getWorkflowDef(eToken, btoken);
                        }
                    }
                    this.loader.close();
                }).bind(this),
                error : function(res){
                    //MessageBox.error("An error occured. Please go back try again");
                    this.loader.close();
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            })
        },
        _initiateChange: function (token, ProcessVariantId) {
            this.loader.open();
            this.getFormData();
            var oModel = this.getView().getModel("iModel").getProperty("/PurchaseInfoRecordDetails");
            var data = {
                definitionId: ProcessVariantId,
                context: oModel
            };
            var jsondata = JSON.stringify(data);
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/bpmworkflowruntime/v1/workflow-instances",
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {
                    "X-CSRF-Token": token
                },
                data: jsondata,
                success: $.proxy(function (result) {
                    this.getView().byId("idBtnSave").setEnabled(false);
                    this.getView().byId("button2").setVisible(true);
                    this.getView().byId("button1").setVisible(false);
                    this.loader.close();
                    MessageToast.show("Workflow for info record change is triggered");
                }).bind(this),
                error : function(res){
                    //MessageBox.error("An error occured. Please go back try again");
                    this.loader.close();
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            });
        },
        Close: function(){
            this.getOwnerComponent().getRouter().navTo("Master");
            this.enableFields();
        },
        disableFields: function() {
            this.form.forEach(function(eKey) {
                if (this.getView().byId(eKey).getProperty("editable"))
                    this.getView().byId(eKey).setProperty("editable", false)
            }
            .bind(this))
        },
        enableFields: function() {
            this.form.forEach(function(eKey) {                                      					
                if(eKey != "PurchaseInfoRecordNum" && eKey != "Material" && eKey != "MaterialGroup" 
                    && eKey != "Vendor" && eKey != "PurchaseOrganization" && eKey != "Plant" 
                    && eKey != "PurchaseInfoCategory" && eKey != "CompanyCode" && eKey != "OldPrice"){
                        if (!this.getView().byId(eKey).getProperty("editable")) {
                            this.getView().byId(eKey).setProperty("editable", true)
                        }
                }
            }
            .bind(this)) 
            this.getView().byId("Currency").setProperty("editable", false)
            this.getView().byId("PriceUnit").setProperty("editable", false)
            this.getView().byId("OrderUnit").setProperty("editable", false)

        },
        validate: function() {
            var tFlag = 0;
            var errors=[];
            this.getView().getModel("iModel").setProperty("/Errors",{});
            this.form.forEach(function(aKey) {
                if (aKey != "PurchaseInfoCategory" && aKey != "MaterialGroup") {
                    var iVal = this.getView().byId(aKey).getValue();
                    if (iVal == "") {
                        this.getView().byId(aKey).setValueState("Error");
                            errors.push({"Key":aKey ,"description": "This is a Mandatory Field"})
                        tFlag = 1
                    } else {
                        var iVal = this.getView().byId(aKey).getValue();
                        if(iVal.includes("*",0)){
                            this.getView().byId(aKey).setValueState("Error");
                            errors.push({ "Key": aKey, "description": "Please enter a value without a wildcard" })
                            tFlag = 1
                        }
                        if (aKey == "StandardQuantity") {
                            var sRegex = /^\d{1,9}(\.\d{1,3})?$/;
                            if (!sRegex.test(this.getView().byId(aKey).getValue())) {
                                this.getView().byId(aKey).setValueState("Error");
                                errors.push({"Key":aKey ,"description":  "Please enter standard quantity in number from 1 to 9,999,999,999.999"});
                                tFlag = 1
                            }
                            if(this.getView().byId(aKey).getValue() == "0"){
                                this.getView().byId(aKey).setValueState("Error");
                                errors.push({"Key":aKey,"description":  "Standard Quantity cannot be 0. Please enter standard quantity in number from 1 to 9,999,999,999.999 "});
                                tFlag = 1
                            }
                        }
                        if (aKey == "PlannedDeliveryTime") {
                            var sRegex = /^\d{1,3}?$/;
                            if (!sRegex.test(this.getView().byId(aKey).getValue())) {
                                this.getView().byId(aKey).setValueState("Error");
                                errors.push({"Key":aKey ,"description":  "Please enter a planned delivery time as number of days between 1 and 999"});
                                tFlag = 1
                            }
                            if(this.getView().byId(aKey).getValue() == "0"){
                                this.getView().byId(aKey).setValueState("Error");
                                errors.push({"Key":aKey,"description":  "Planned Delivery Time cannot be 0. Please enter a planned delivery time as number of days between 1 and 999"});
                                tFlag = 1
                            }
                        }
                            if (aKey == "Price") {
                                var sRegex = /^\d{1,9}(\.\d{1,2})?$/;
                                if (!sRegex.test(this.getView().byId(aKey).getValue())) {
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({ "Key": aKey, "description": "Please enter price of material from 1 to 999,999,999.99" });
                                    tFlag = 1
                                }
                                if(this.getView().byId(aKey).getValue() == "0"){
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({"Key":aKey,"description":  "Price cannot be 0. Please enter price of material from 1 to 999,999,999.99"});
                                    tFlag = 1
                                }
                            }
                    }
                }
                if (aKey == "ValidTo") {
                    if (this.getView().byId(aKey).getValue() != "") {
                        if (this.getView().byId(aKey).isValidValue()) {
                            if(this.getView().byId("ValidFrom").getValue() != ""){
                                
                                if (this.dateFormat(this.getView().byId(aKey).getValue(), "YYYYMMdd") < this.dateFormat(this.getView().byId("ValidFrom").getValue(), "YYYYMMdd")) {
                                    this.getView().byId(aKey).setValueState("Error");
                                    errors.push({"Key":aKey,"description":  "Valid To cannot be lower than Valid From"});
                                    tFlag = 1
                                }
                            }
                        } else {
                            this.getView().byId(aKey).setValueState("Error");
                            errors.push({"Key":aKey,"description": "Please enter a correct date"});
                            tFlag = 1
                        }
                    }
                }
                if (aKey == "ValidFrom") {
                    if (this.getView().byId(aKey).getValue() != "") {
                        if (!this.getView().byId(aKey).isValidValue()) {
                            this.getView().byId(aKey).setValueState("Error");
                            errors.push({ "Key": aKey, "description": "Please enter a correct date" });
                            tFlag = 1
                        }
                    }
                }
            }
            .bind(this));
            if (tFlag) {
                this.getView().getModel("iModel").setProperty("/Errors",errors)
                this.getView().byId("messagePopoverBtn").setEnabled(true);
                this.getView().byId("messagePopoverBtn").setVisible(true);
                    if (!this.oMessagePopover) {
                        this.createMessagePopover();
                        
                }
                this.getView().byId("messagePopoverBtn").setType("Reject");
                setTimeout(function(){
                    this.oMessagePopover.openBy(this.getView().byId("messagePopoverBtn"));
                }.bind(this), 100);
                return false
            } else {
                this.getView().byId("messagePopoverBtn").setType("Default");
                this.getView().byId("messagePopoverBtn").setEnabled(false);
                this.getView().byId("messagePopoverBtn").setVisible(false);
                return true
            }
        },
        resetValidate: function() {
            this.getView().getModel("iModel").setProperty("/Errors",{});
            this.getView().byId("messagePopoverBtn").setType("Default");
            this.getView().byId("messagePopoverBtn").setEnabled(false);
            this.getView().byId("messagePopoverBtn").setVisible(false);
            this.form.forEach(function(eKey) {
                this.getView().byId(eKey).setValueState("None")
            }
            .bind(this))
        },
        handleMessagePopoverPress: function(oEvent){
            if (!this.oMessagePopover) {
                this.createMessagePopover();
        }
        this.oMessagePopover.toggle(oEvent.getSource());
        },
        createMessagePopover: function(){
            var oMessageTemplate = new MessageItem({
                        type: 'Error',
                        title: '{iModel>description}',
                        subtitle: '{iModel>Key}'
                    });
                this.oMessagePopover = new MessagePopover({
                    items: {
                        path: 'iModel>/Errors',
                        template: oMessageTemplate
                    }
                });
                this.getView().byId("messagePopoverBtn").addDependent(this.oMessagePopover);
            },
            _bfetchToken: function () {
                var btoken;
                $.ajax({
                    url: "/comsapcpdpaManagePurchaseInfoRecord/bpmrulesruntime/rules-service/v1/rules/xsrf-token",
                    method: "GET",
                    async: false,
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {
                        btoken = data.getResponseHeader("X-CSRF-Token");
                    }
                });
                return btoken;
            },
            getWorkflowDef: function (tToken, btoken) {
                this.loader.open();
            var hData = JSON.stringify({
                RuleServiceId: "e021ed25e80b440d92bbab78c0b963db",
                RuleServiceRevision: "2006",
                Vocabulary: [{
                    PurchaseInfoRecord: {
                        Action: "Change",
                        Plant: this.getView().getModel('iModel').getProperty("/selItem/Plant"),
                        PurchaseOrganization: this.getView().getModel('iModel').getProperty("/selItem/PurhOrg"),
                        PurchaseInfoCategory: this.getView().byId("PurchaseInfoCategory").getSelectedKey(),
                        MaterialGroup: this.getView().byId("MaterialGroup").getValue() ,
                        OldPrice: parseFloat(this.getView().byId("OldPrice").getValue()),
                        NewPrice: parseFloat(this.getView().byId("Price").getValue()),
                        CompanyCode: this.getView().byId("CompanyCode").getValue() 
                        }
                    }
                ]
            });
                $.ajax({
                    url: "/comsapcpdpaManagePurchaseInfoRecord/bpmrulesruntime/rules-service/rest/v2/rule-services",
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {
                        "X-CSRF-Token": btoken
                    },
                    data: hData,
                    success: $.proxy(function(response){
                        this._checkApprovalStatus(tToken, response.Result[0].ProcessVariantDetails.ProcessVariantId)
                        this.loader.close();
                    }.bind(this)),
                    error : function(res){
                        //MessageBox.error("An error occured. Please go back try again");
                        this.loader.close();
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                    }.bind(this)
                })
            },
            _checkApprovalStatus: function(token, ProcessVariantId) {
                this.loader.open();
            var data = $.param({
                definitionId: ProcessVariantId,
                status: ["RUNNING", "ERRONEOUS", "SUSPENDED"],
                "attributes.PurchInfoRecordId": this.getView().byId("PurchaseInfoRecordNum").getValue()
            }, true);
            $.ajax({
                url: "/comsapcpdpaManagePurchaseInfoRecord/bpmworkflowruntime/v1/workflow-instances",
                method: "GET",
                async: false,
                contentType: "application/json",
                headers: {
                    "X-CSRF-Token": token
                },
                data: data,
                success: $.proxy(function (result) {                        
                    if(result != ""){
                        if(result.length >= 1){
                            if(result[0].startedBy != undefined){
                                MessageBox.error("Purchase info record approval with similar data is already initiated by "+result[0].startedBy)
                            }else{
                                MessageBox.error("Purchase info record approval with similar data is already initiated")
                            }
                        }
                    }else{
                        this.disableFields();
                        this._initiateChange(token, ProcessVariantId);
                    }
                    this.loader.close();
                }).bind(this),
                error : function(res){
                    //MessageBox.error("An error occured. Please go back try again");
                    this.loader.close();
                    MessageBox.error("Internal Server Error. Please contact your administrator")
                }.bind(this)
            });
        },  
            getCurrency: function(tToken, btoken) {
                var language = window.navigator.language;
                language = language.split("-")
                language = language[0].toUpperCase();
                var currdata = JSON.stringify({
                RuleServiceId: "d885808d318e42b6bb4f38951709e6ea",
                RuleServiceRevision: "2006",
                    Vocabulary: [{ Language: {LanguageKey: language }}]
                        });
                $.ajax({
                    url: "/comsapcpdpaManagePurchaseInfoRecord/bpmrulesruntime/rules-service/rest/v2/rule-services",
                    //url: "/comsapcpdpaManagePurchaseInfoRecord/bpmrulesruntime/rules-service/rest/v2/workingset-rule-services",
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {
                        "X-CSRF-Token": btoken
                    },
                    data: currdata,
                    success: $.proxy(function(response){
                        if(response.Result.length >= 1){
                            this.getView().getModel("iModel").setProperty("/CurrencyList",response.Result[0].CurrencyList)
                        }
                    }.bind(this)),
                    error : function(res){
                        this.getView().getModel("iModel").setProperty("/CurrencyList", {});
                        this.getView().getModel("iModel").refresh(true);
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                    }.bind(this)
                })
            },
            handleValueHelpCurrency: function (oItem) {
                this.getView().getModel("iModel").setProperty("/CurrencyList", {});
                this.getView().getModel("iModel").setProperty("/CurrencyListCount", 0);
                if (!this._valueHelpDialogCurrency) {
                    this._valueHelpDialogCurrency = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.Currency", this);
                    this.getView().addDependent(this._valueHelpDialogCurrency)
                }
                this._valueHelpDialogCurrency.open();
                this._valueHelpDialogCurrency.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchCurrency: function(eItem){
                var token = this._bfetchToken();
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                     this.getCurrency("",token)
                }else{
                    MessageToast.show("Please enter search input")
                    return;
                }
                if(tVal.includes("*",0)){
                    tVal = tVal.split("*");
                    var valLength = tVal.length;
                    var preLength = 0;
                    var cval = "";
                    for(var i = 0; i < valLength; i++){
                        if(tVal[i] != ""){
                            var currLength = tVal[i].length;
                            if(preLength == 0){
                                preLength = currLength;
                                cval = tVal[i]
                            }else{
                                if(currLength > preLength){
                                    preLength = currLength;
                                    cval = tVal[i]
                                }
                            }
                        }
                    }
                    tVal = cval;
                }
                var aFilter = [new Filter("CurrencyCode", FilterOperator.Contains, tVal), new Filter("CurrencyDescription", FilterOperator.Contains, tVal)];
                var nFilter = new Filter(aFilter, false);
                eItem.getSource().getBinding("items").filter([nFilter])
                if(eItem.getSource().getBinding("items").iLength == 0){
                    this._valueHelpDialogCurrency.setNoDataText("No data");
                    MessageToast.show("No matching data found");
                }
                this.getView().getModel("iModel").setProperty("/CurrencyListCount", eItem.getSource().getBinding("items").iLength);
            },
            _handleValueHelpCurrencyClose: function(eItem){
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("Currency");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                }
                eItem.getSource().getBinding("items").filter([])
                if(this.getView().byId("Currency").getValue() != ""){
                    this.getView().byId("Currency").setValueState("None")
                }
            },
            getOrderUnit: function(tToken, btoken) {
                var language = window.navigator.language;
                language = language.split("-")
                language = language[0].toUpperCase();
                var currdata = JSON.stringify({
                RuleServiceId: "5a358976212b4976800cfd476ea65262",
                RuleServiceRevision: "2006",
                    Vocabulary: [{ Language: {LanguageKey: language }}]
                        });
                $.ajax({
                    url: "/comsapcpdpaManagePurchaseInfoRecord/bpmrulesruntime/rules-service/rest/v2/rule-services",
                    //url: "/comsapcpdpaManagePurchaseInfoRecord/bpmrulesruntime/rules-service/rest/v2/workingset-rule-services",
                    method: "POST",
                    async: false,
                    contentType: "application/json",
                    headers: {
                        "X-CSRF-Token": btoken
                    },
                    data: currdata,
                    success: $.proxy(function(response){
                        if(response.Result.length >= 1){
                            this.getView().getModel("iModel").setProperty("/OrderUnitList",response.Result[0].UnitOfMeasurementList)
                        }
                    }.bind(this)),
                    error : function(res){
                        this.getView().getModel("iModel").setProperty("/OrderUnitList", {});
                        this.getView().getModel("iModel").refresh(true);
                        MessageBox.error("Internal Server Error. Please contact your administrator")
                    }.bind(this)
                })
            },
            handleValueHelpOrderUnit: function (oItem) {
                this.getView().getModel("iModel").setProperty("/OrderUnitList", {})
                this.getView().getModel("iModel").setProperty("/OrderUnitListCount", 0);
                if (!this._valueHelpDialogOrderUnit) {
                    this._valueHelpDialogOrderUnit = sap.ui.xmlfragment("com.sap.cp.dpa.ManagePurchaseInfoRecord.fragments.OrderUnit", this);
                    this.getView().addDependent(this._valueHelpDialogOrderUnit)
                }
                this._valueHelpDialogOrderUnit.open();
                this._valueHelpDialogOrderUnit.setNoDataText("Please enter value for search");
            },
            handleValueHelpSearchOrderUnit: function(eItem){
                var token = this._bfetchToken();
                var tVal = eItem.getParameter("value");
                if(tVal != ""){
                    this.getOrderUnit("",token)
                }else{
                    MessageToast.show("Please enter search input")
                    return;
                }
                if(tVal.includes("*",0)){
                    tVal = tVal.split("*");
                    var valLength = tVal.length;
                    var preLength = 0;
                    var cval = "";
                    for(var i = 0; i < valLength; i++){
                        if(tVal[i] != ""){
                            var currLength = tVal[i].length;
                            if(preLength == 0){
                                preLength = currLength;
                                cval = tVal[i]
                            }else{
                                if(currLength > preLength){
                                    preLength = currLength;
                                    cval = tVal[i]
                                }
                            }
                        }
                    }
                    tVal = cval;
                }
                var aFilter = [new Filter("UnitOfMeasurement", FilterOperator.Contains, tVal), new Filter("Description", FilterOperator.Contains, tVal)];
                var nFilter = new Filter(aFilter, false);
                eItem.getSource().getBinding("items").filter([nFilter])
                if(eItem.getSource().getBinding("items").iLength == 0){
                    this._valueHelpDialogOrderUnit.setNoDataText("No data");
                    MessageToast.show("No matching data found")
                }
                this.getView().getModel("iModel").setProperty("/OrderUnitListCount", eItem.getSource().getBinding("items").iLength);
            },
            _handleValueHelpOrderUnitClose: function(eItem){
                var tItem = eItem.getParameter("selectedItem");
                if (tItem) {
                    var aItem = this.getView().byId("OrderUnit");
                    aItem.setValue(tItem.getTitle())
                    aItem.setValueState("None");
                }
                eItem.getSource().getBinding("items").filter([]);
                if(this.getView().byId("OrderUnit").getValue() != ""){
                    this.getView().byId("OrderUnit").setValueState("None")
                }
            }
    });
});