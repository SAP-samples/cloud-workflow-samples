# CustomUIForPurchaseInfoRecord
Custom UI for Purchase Info Record maintenance - ITC Infotech
