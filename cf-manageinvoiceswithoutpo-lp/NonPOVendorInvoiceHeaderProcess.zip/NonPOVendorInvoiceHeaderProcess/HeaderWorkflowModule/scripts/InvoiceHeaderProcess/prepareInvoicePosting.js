$.context.internal.validation.ERPValidationPayload.headerData.reference = $.context.invoiceDetails.headerDetail.reference;
var items = $.context.invoiceDetails.items;
var accountGl_tab = [];
var invoiceValPayload = $.context.internal.validation.ERPValidationPayload;


//Preparing posting date 
var postingDate = new Date();
$.context.invoiceDetails.headerDetail.postingDate = postingDate.toISOString().slice(0,10).replace(/-/g,"");
var postingDateTemp = postingDate.toISOString().slice(0,10).replace(/-/g,"");
$.context.internal.postingDate = postingDateTemp.substring(6, 8)
            + "." + postingDateTemp.substring(4, 6)
            + "." + postingDateTemp.substring(0, 4);

//Capturing posting date into the invoice header context            
invoiceValPayload.headerData.postingDate = $.context.invoiceDetails.headerDetail.postingDate;   
invoiceValPayload.headerData.headerText =  $.context.invoiceDetails.headerDetail.text;

//Preparing payload to post invoice into SAP ERP
$.context.internal.postInvoicePayload = invoiceValPayload;
