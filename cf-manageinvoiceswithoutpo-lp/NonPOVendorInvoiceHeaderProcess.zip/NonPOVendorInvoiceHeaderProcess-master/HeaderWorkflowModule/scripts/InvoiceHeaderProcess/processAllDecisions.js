var itemgroups = $.context.approval.itemGroups;
$.context.internal.isAllApprove = true;
$.context.internal.approverDeclinedComments = "";
$.context.internal.approverNoteResponsibleComments = "";
var msg = "";

//Determining final decision on basis of all approver decisions
for (var i = 0; i < itemgroups.length; i++) {
    var history = itemgroups[i].history;
    var k = 0;
    for (var k = (history.length - 1); k < history.length; k--) {
        if (history[k].action != "Invoice Request") {
            
            break;
        }
    }
    for (var j = k; j < history.length; j++) {
        if (history[j].action != "approve" && history[j].action != "Invoice Request") {
            $.context.internal.isAllApprove = false;
            if (typeof history[j].comments !== 'undefined' && history[j].action == "decline") {
                if ($.context.internal.approverDeclinedComments === "") {
                    $.context.internal.approverDeclinedComments = history[j].comments + ". ";
                } else {
                    $.context.internal.approverDeclinedComments = $.context.internal.approverDeclinedComments + history[j].comments + ". ";
                }

                //Preparing declined based approver commments for rework task
                msg = "";
                var costCenter = "", porfitCenter = "", businessArea = "", plant = "";
                msg = "Reason for Declination (";
                if (itemgroups[i].costCenter !== "") {
                    costCenter =  "Cost Center: " + itemgroups[i].costCenter;
                }
                if (itemgroups[i].profitCenter !== "") {
                    porfitCenter = "Profit Center: " + itemgroups[i].profitCenter;
                }
                if (itemgroups[i].businessArea !== "") {
                    businessArea = "Business Area: " + itemgroups[i].businessArea;
                }if (itemgroups[i].plant !== "") {
                    plant = "plant: " + itemgroups[i].plant;
                }
                var costObjects = "";
                costObjects = costCenter + " " + porfitCenter + " " + businessArea + " " + plant;
               
                msg = msg + costObjects.trim() +  "): " + history[j].comments;
                var msg1 = {
                    "message": msg
                }
                $.context.internal.reworkReason.push(msg1);
                
            } else if (typeof history[j].comments !== 'undefined' && history[j].action == "rework") {
                if ($.context.internal.approverNoteResponsibleComments === "") {
                    $.context.internal.approverNoteResponsibleComments = history[j].comments + ". ";
                } else {
                    $.context.internal.approverNoteResponsibleComments = $.context.internal.approverNoteResponsibleComments + history[j].comments + ". ";
                }
                //Preparing "Not Responsible" based approver commments for rework task
                msg = "";
                var costCenter = "", porfitCenter = "", businessArea = "", plant = "";
                
                msg = "Not-Responsible Approver Comment (";
                if (itemgroups[i].costCenter !== "") {
                    costCenter =  "Cost Center: " + itemgroups[i].costCenter;
                }
                if (itemgroups[i].profitCenter !== "") {
                    porfitCenter = "Profit Center: " + itemgroups[i].profitCenter;
                }
                if (itemgroups[i].businessArea !== "") {
                    businessArea = "Business Area: " + itemgroups[i].businessArea;
                }if (itemgroups[i].plant !== "") {
                    plant = "plant: " + itemgroups[i].plant;
                }
                var costObjects = "";
                costObjects = costCenter + " " + porfitCenter + " " + businessArea + " " + plant;

                msg = msg + costObjects.trim() + "): " + history[j].comments;
                var msg1 = {
                    "message": msg
                }
                $.context.internal.reworkReason.push(msg1);
            }


        }
    }
}

