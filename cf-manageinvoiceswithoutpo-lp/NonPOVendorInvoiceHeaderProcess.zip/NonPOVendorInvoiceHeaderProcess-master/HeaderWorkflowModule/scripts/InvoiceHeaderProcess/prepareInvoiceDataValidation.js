var approval = { "itemGroups": [] }

//Initializing tax and total amount
if (typeof $.context.invoiceDetails.headerDetail.taxAmount === 'undefined') {
    $.context.invoiceDetails.headerDetail.taxAmount = 0;
    $.context.invoiceDetails.headerDetail.invoiceTotalAmount = $.context.invoiceDetails.headerDetail.invoiceAmount;
}

$.context.approval = approval;
var itemgroups, headerData, itemData, ruleInput, isNonTaxableInvoice = true;

var items = $.context.invoiceDetails.items;
$.context.invoiceDetails.headerDetail.initiator = $.info.startedBy;
//Business RulesService id for invoice validation
var ruleServiceId = "63ef2e92f14e4af1b603249e0018bd1d";
var accountGl_tab = [],
    currencyAmount_tab = [],
    currencyAmount;

$.context.invoiceDetails.headerDetail.requestDate = new Date();

$.context.invoiceDetails.headerDetail.postingDate = new Date().toISOString().slice(0, 10).replace(/-/g, "");;

//prepare internal structure
var internal = {
    "validation": {
        "validationRulesPayload": "",
        "ERPValidationPayload": ""
    }
};
$.context.internal = internal;
$.context.internal.headerInstanceId = $.info.workflowInstanceId;

//Prepare rule validation payload context
$.context.internal.validation.validationRulesPayload = {
    "RuleServiceId": ruleServiceId,
    "Vocabulary": []
};
var headerDetails = $.context.invoiceDetails.headerDetail;

var invDate = headerDetails.invoiceDate.substring(0, 4)
    + "-" + headerDetails.invoiceDate.substring(4, 6)
    + "-" + headerDetails.invoiceDate.substring(6, 8);

//Prepare rule payload for validation
for (var i = 0; i < items.length; i++) {

    $.context.invoiceDetails.items[i].glAccount = $.context.invoiceDetails.items[i].glAccount.replace(/^0+/, '');
    $.context.invoiceDetails.items[i].costCenter = $.context.invoiceDetails.items[i].costCenter.replace(/^0+/, '');
    $.context.invoiceDetails.items[i].profitCenter = $.context.invoiceDetails.items[i].profitCenter.replace(/^0+/, '');
    $.context.invoiceDetails.items[i].internalOrder = $.context.invoiceDetails.items[i].internalOrder.replace(/^0+/, '');
    $.context.invoiceDetails.items[i].itemNumber = i + 1;

    ruleInput = {
        "InvoiceHeaderDetails": {
            "CompanyCode": $.context.invoiceDetails.headerDetail.companyCode,
            "postingDate": invDate,

            "CurrencyKey": $.context.invoiceDetails.headerDetail.currency,
            "PaymentTerms": $.context.invoiceDetails.headerDetail.paymentTerm,
            "PaymentMethod": $.context.invoiceDetails.headerDetail.paymentMethod
        },
        "InvoiceItemDetails": {
            "GLAccount": items[i].glAccount,
            "Plant": items[i].plant,
            "BusinessArea": items[i].businessArea,
            "CostCenter": items[i].costCenter,
            "InternalOrder": items[i].internalOrder,
            "ProfitCenter": items[i].profitCenter,
            "ThresholdInvoiceAmount": items[i].amount

        }
    }
    $.context.internal.validation.validationRulesPayload.Vocabulary.push(ruleInput);

    var itemNo = (items[i].itemNumber + 1);
    var accountGL = {
        "itemAccountNumber": itemNo.toString(),
        "glAccountNo": items[i].glAccount,
        "itemText": items[i].itemText,
        "acctType": "S",
        "companyCode": $.context.invoiceDetails.headerDetail.companyCode,
        "taxCode": items[i].taxCode,
        "vendorNo": $.context.invoiceDetails.headerDetail.vendorNumber,
        "profitCenter": items[i].profitCenter,
        "costCenter": items[i].costCenter,
        "businessArea": items[i].businessArea,
        "plant": items[i].plant,
        "internalOrder": items[i].internalOrder
    }
    accountGl_tab.push(accountGL);


    currencyAmount = {


        "itemAccountNumber": itemNo.toString(),
        "currency": $.context.invoiceDetails.headerDetail.currency,
        "amount": items[i].amount,
        "baseAmount": "",
        "exchangeRate": $.context.invoiceDetails.headerDetail.exchangeRate
    };
    currencyAmount_tab.push(currencyAmount);

    if (items[i].taxCode !== "" && isNonTaxableInvoice === true) {
        isNonTaxableInvoice = false;
    }
}

//Setting indicator for Non-Taxable invoice, if it is 'true' then it is Non-Taxable Invoice 
$.context.internal.isNonTaxableInvoice = isNonTaxableInvoice;

//Calculating fist discount date
var invoiceDate = $.context.invoiceDetails.headerDetail.invoiceDate;
var date = new Date(parseInt(invoiceDate.substring(0, 4)), parseInt(invoiceDate.substring(4, 6)) - 1, parseInt(invoiceDate.substring(6, 8)));
date.setDate(date.getDate() + $.context.invoiceDetails.paymentTerms[0].days);
$.context.invoiceDetails.headerDetail.discountDate = date.toISOString().slice(0, 10).replace(/-/g, "");

//Calculating invoice second discount date
var date1 = new Date(parseInt(invoiceDate.substring(0, 4)), parseInt(invoiceDate.substring(4, 6)) - 1, parseInt(invoiceDate.substring(6, 8)));
date1.setDate(date1.getDate() + $.context.invoiceDetails.paymentTerms[1].days);
$.context.invoiceDetails.headerDetail.secondDiscountDate = date1.toISOString().slice(0, 10).replace(/-/g, "");

//Calculating invoice first discount amount
$.context.invoiceDetails.headerDetail.discounAmount = ($.context.invoiceDetails.headerDetail.invoiceAmount *
    $.context.invoiceDetails.paymentTerms[0].percentageAmount) / 100;

//Calculating invoice second discount amount
$.context.invoiceDetails.headerDetail.secondDiscounAmount = ($.context.invoiceDetails.headerDetail.invoiceAmount *
    $.context.invoiceDetails.paymentTerms[1].percentageAmount) / 100;

//Begin of: Tax Calculation
$.context.internal.taxCalculationPayload = {
    "headerData": {
        "userName": $.context.invoiceDetails.headerDetail.initiator,
        "postingDate": $.context.invoiceDetails.headerDetail.postingDate,
        "documentDate": $.context.invoiceDetails.headerDetail.invoiceDate,
        "companyCode": $.context.invoiceDetails.headerDetail.companyCode,
        "docType": "KR",
        "reference": $.context.invoiceDetails.headerDetail.reference
    },
    "currencyAmount": currencyAmount_tab,
    "accountGL": accountGl_tab

};
//End of: Tax Calculation


//Date formatted(dd.mm.yyyy) invoice date for mail body
$.context.internal.invoiceDate = headerDetails.invoiceDate.substring(6, 8)
    + "." + headerDetails.invoiceDate.substring(4, 6)
    + "." + headerDetails.invoiceDate.substring(0, 4);

//Invoice due days calculation
var invoiceDueDays = "";
var paymentTerms = $.context.invoiceDetails.paymentTerms;
if (paymentTerms[2].days !== 0) {
    invoiceDueDays = paymentTerms[2].days;
} else if (paymentTerms[1].days !== 0) {
    invoiceDueDays = paymentTerms[1].days;
} else {
    invoiceDueDays = paymentTerms[0].days;
}

//Invoice due date calculation
$.context.duedays = invoiceDueDays;
var invoiceDate = $.context.invoiceDetails.headerDetail.invoiceDate;
var date1 = new Date(parseInt(invoiceDate.substring(0, 4)), parseInt(invoiceDate.substring(4, 6)) - 1, parseInt(invoiceDate.substring(6, 8)));
date1.setDate(date1.getDate() + invoiceDueDays);
var invoiceDueDate = date1.toISOString().slice(0, 10);

$.context.invoiceDetails.headerDetail.invoiceDueDate = invoiceDueDate.substring(0, 4)
    + invoiceDueDate.substring(5, 7)
    + invoiceDueDate.substring(8, 10);