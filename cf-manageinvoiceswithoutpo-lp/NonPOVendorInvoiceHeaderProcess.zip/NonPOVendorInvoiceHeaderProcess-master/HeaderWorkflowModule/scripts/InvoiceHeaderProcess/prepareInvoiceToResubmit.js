
var itemGroup = $.context.approval.itemGroups;


if (typeof $.context.rework === 'undefined') {
    $.context.rework = {
        "itemGroups": itemGroup
    };

} else {
    //Capturing all the history content as a reworked context
    var reworkItemGroup = $.context.rework.itemGroups;
    for (var a = 0; a < itemGroup.length; a++) {
        var flag = false;
        for (var j = 0; j < reworkItemGroup.length; j++) {
            if (reworkItemGroup[j].costObject == itemGroup[a].costObject) {
                for (var b = 0; b < itemGroup[a].history; b++) {
                    reworkItemGroup[j].history.push(temGroup[a].history[b]);
                }
                flag = true;
            }
        }
        if (flag == false) {
            reworkItemGroup.push(itemGroup[a]);
        }

    }
    $.context.rework.itemGroups = reworkItemGroup;
}
// Setting default value of Exchange Rate
if ($.context.invoiceDetails.headerDetail.exchangeRate === "") {
    $.context.invoiceDetails.headerDetail.exchangeRate = "0";
}