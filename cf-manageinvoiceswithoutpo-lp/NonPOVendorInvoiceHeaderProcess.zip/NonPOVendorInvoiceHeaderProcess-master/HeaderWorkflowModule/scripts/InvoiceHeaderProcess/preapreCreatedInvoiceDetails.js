//Capturing actual created invoice document number for intiator mail body
var invoiceNumber = $.context.internal.postInvoiceResponse.invoiceNumber;
$.context.internal.invoiceNumber = invoiceNumber.substring(0, 10);
$.context.internal.fiscalYear = invoiceNumber.substring(14, 18);

