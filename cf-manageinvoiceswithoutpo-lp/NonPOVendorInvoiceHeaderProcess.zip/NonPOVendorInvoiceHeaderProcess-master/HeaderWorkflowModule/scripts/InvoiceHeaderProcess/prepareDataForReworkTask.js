//Setting default value of Exchange Rate for approval task
if($.context.invoiceDetails.headerDetail.exchangeRate === "0" || $.context.invoiceDetails.headerDetail.exchangeRate === 0){
    $.context.invoiceDetails.headerDetail.exchangeRate = "";
}