$.context.invoiceDetails.headerDetail.invoiceNumber = $.context.internal.invoiceNumber;
//Clearing workflow internal processing variables from the workflow context
delete $.context.internal, $.context.approvalMsgResponse;