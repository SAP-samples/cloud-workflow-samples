var loopCount = $.context.internal.itemGroupCounter;

//Determining current itemgroup as per loop counter in itemgrouplist
$.context.approval.currentItemGroup = $.context.approval.itemGroups[loopCount];

var headerDetails = $.context.invoiceDetails.headerDetail;
//Rule Service Id for process variant determination payload
var ruleServiceId = "622c4758f8b149b5a6e06f97eb9a665f";
var invDate = headerDetails.invoiceDate.substring(0, 4)
            + "-" + headerDetails.invoiceDate.substring(4, 6)
            + "-" + headerDetails.invoiceDate.substring(6, 8);

//Preparing process variant determination payload            
$.context.internal.processVariantPayload = {
    "RuleServiceId": ruleServiceId,
    "Vocabulary": [
        {
            "InvoiceDetails": {
                "CompanyCode": $.context.invoiceDetails.headerDetail.companyCode,
                // ,
                "InvoiceDate": invDate,
                "CurrencyKey": $.context.invoiceDetails.headerDetail.currency,
                "PaymentTerms": $.context.invoiceDetails.headerDetail.paymentTerm,
                "PaymentMethod": $.context.invoiceDetails.headerDetail.paymentMethod,
                "ExchangeRate": $.context.invoiceDetails.headerDetail.exchangeRate,
                "CostCenter": $.context.approval.currentItemGroup.costCenter,
                "ProfitCenter": $.context.approval.currentItemGroup.profitCenter,
                "InternalOrder": $.context.approval.currentItemGroup.internalOrder
            }
        }
    ]
};

