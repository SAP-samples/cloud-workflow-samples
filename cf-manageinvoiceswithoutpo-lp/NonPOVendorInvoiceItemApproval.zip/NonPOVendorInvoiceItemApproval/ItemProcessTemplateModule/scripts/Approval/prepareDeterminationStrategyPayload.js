//Rules Service Id for approver determination strategy business rules.
var ruleServiceId = "87f396b0ad7f4f3a9ce078270c52e37c";
var ruleServiceRevision = "2011";

//Preparing payload for approver determination strategy
$.context.internal.AppDeterminationStrategyPayload = {
    "RuleServiceId": ruleServiceId,
    "RuleServiceRevision": ruleServiceRevision,
    "Vocabulary": [
        {
            "InvoiceDetails": {
                "CompanyCode": $.context.currentItemGroup.companyCode,
                "CurrencyKey": $.context.currentItemGroup.currency,
                "PaymentTerms": $.context.currentItemGroup.paymentTerm,
                "PaymentMethod": $.context.currentItemGroup.paymentMethod,
                "ExchangeRate": $.context.currentItemGroup.exchangeRate,
                "CostCenter": $.context.currentItemGroup.costCenter,
                "ProfitCenter": $.context.currentItemGroup.profitCenter,
                "BusinessArea": $.context.currentItemGroup.businessArea

            }
        }
    ]
}
