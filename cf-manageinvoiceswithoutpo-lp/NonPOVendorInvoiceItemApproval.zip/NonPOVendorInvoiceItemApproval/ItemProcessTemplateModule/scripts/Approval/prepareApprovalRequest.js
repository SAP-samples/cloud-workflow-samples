if (($.context.internal.determineApproverResponse.Result.length > 0) && ($.context.internal.determineApproverResponse.Result[0].ApproverDetails.IsApprovalRequired === true)) {
    var dueDate, rel = 0;
    var result = $.context.internal.determineApproverResponse.Result;
    
    var dueDuration = result[0].ApproverDetails.TaskDueDuration;
    var timeunit = result[0].ApproverDetails.UnitOfTime;
    $.context.internal.steps.AppReq = true;
    $.context.internal.steps.dueduration = dueDuration;

    if (isNaN(dueDuration) || dueDuration < 0) {
        throw new Error("Value for Duration of DueDate returned from rules need to be a positive number, but was" + timeunit);
    }

    var DateReference = result[0].ApproverDetails.DueDurationReference;
    if (DateReference === 'step') {
        rel = new Date() - new Date($.context.internal.steps.starttime);
    } else if (DateReference === 'Workflow') {
        rel = new Date() - new Date($.context.invoiceDetails.headerDetail.requestDate);
    } else if (DateReference !== 'Task') {
        throw new Error("Value for DueDateReference returned from rule needs to be one of 'Workflow', 'Step' or 'Task', but was" + DateReference);
    }

    if (timeunit == 'Y') {
        var minutes = Math.max(0, Math.round(dueDuration * 365 * 24 * 60)); //converting 'due duration' Year to minute
        rel = Math.max(0, Math.floor(rel / 60 / 1000));                     // convert 'already passed time' to minutes
    } else if (timeunit == 'M') {
        var minutes = Math.max(0, Math.round(dueDuration * 30 * 24 * 60));  //converting 'due duration' Months to minute
        rel = Math.max(0, Math.floor(rel / 60 / 1000));                     // convert 'already passed time' to minutes
    } else if (timeunit == 'D') {
        var minutes = Math.max(0, Math.round(dueDuration * 24 * 60));      //converting 'due duration' Months to minute
        rel = Math.max(0, Math.floor(rel / 60 / 1000));                    // convert 'already passed time' to minutes
    } else if (timeunit == 'h') {
        var minutes = Math.max(0, Math.round(dueDuration * 60));           //converting 'due duration' days to minute
        rel = Math.max(0, Math.floor(rel / 60 / 1000));                    // convert 'already passed time' to minutes
    } else if (timeunit == 'm') {
        var minutes = Math.max(0, Math.round(dueDuration));                //converting 'due duration' days to minute
        rel = Math.max(0, Math.floor(rel / 60 / 1000));                    // convert 'already passed time' to minutes
    }

    minutes -= rel;


    if (minutes < 0) {
        minutes = 0;
    }
    if (isNaN(minutes)) {
        throw new Error("Internal Error calculating Due Date");
    }
    $.context.internal.steps.TaskDueDate = 'PT' + minutes + 'M';


} else {
    $.context.internal.steps.AppReq = false;
}


var responsibleItems = [];
var otherItems = [];
var items = $.context.invoiceDetails.items;
var glAccount, costCenter, profitCenter, taxCode, internalOrder, businessArea, plant;

//Preparing items as per approval task tree table
for (var i = 0; i < items.length; i++) {
        if( items[i].glAccountDesc == ""){
            glAccount = items[i].glAccount;
        } else{
            glAccount = items[i].glAccount + "\n (" + items[i].glAccountDesc + ")"
        }
        if( items[i].costCenterDesc == ""){
            costCenter = items[i].costCenter;
        } else{
            costCenter = items[i].costCenter + "\n (" + items[i].costCenterDesc + ")"
        }
        if( items[i].profitCenterDesc == ""){
            profitCenter = items[i].profitCenter;
        } else{
            profitCenter = items[i].profitCenter + "\n (" + items[i].profitCenterDesc + ")"
        }
        if( items[i].taxCodeDesc == ""){
            taxCode = items[i].taxCode;
        } else{
            taxCode = items[i].taxCode + "\n (" + items[i].taxCodeDesc + ")"
        }
        if( items[i].internalOrderDesc == ""){
            internalOrder = items[i].internalOrder;
        } else{
            internalOrder = items[i].internalOrder + "\n (" + items[i].internalOrderDesc + ")"
        }
        if( items[i].businessAreaDesc == ""){
            businessArea = items[i].businessArea;
        } else{
            businessArea = items[i].businessArea + "\n (" + items[i].businessAreaDesc + ")"
        }
        if( items[i].plant == ""){
            plant = items[i].plant;
        } else{
            plant = items[i].plant + "\n (" + items[i].plantDesc + ")"
        }
        var itemCat = 
                {
                    "name": "",
                    "glAccount": glAccount,
                    "itemText": items[i].itemText,
                    "costCenter": costCenter,
                    "profitCenter": profitCenter,
                    "taxCode":taxCode,
                    "internalOrder": internalOrder,
                    "businessArea": businessArea,
                    "amount": items[i].amount,
                    "currency": $.context.invoiceDetails.headerDetail.currency,
                    "plant": plant
                };
    if (items[i].itemGroupNo === $.context.currentItemGroup.itemGroupNo) {
        responsibleItems.push(itemCat);
    } else {
        otherItems.push(itemCat);
    }
}

//Preparing tree table based json structure for approval task
$.context.approval = {
    "itemTreeTable": {
        "catalog": {
            "items": {
                "categories": [
                    // {
                    //     "name": "Responsible Items",
                    //     "categories": responsibleItems
                    // },
                    // {
                    //     "name": "Other Items",
                    //     "categories": otherItems
                    // }
                ]
            }
        }
    }
}

//Prepare item list for other responsible items into the approval task
if(responsibleItems.length > 0){
    var responsibleCategory = {
        "name": "Responsible Items",
        "categories": responsibleItems
    };
    $.context.approval.itemTreeTable.catalog.items.categories.push(responsibleCategory);
}

//Prepare item list for other items into the approval task
if(otherItems.length > 0){
    var otherItemCategory = {
        "name": "Other Items",
        "categories": otherItems
    };
    $.context.approval.itemTreeTable.catalog.items.categories.push(otherItemCategory);
}

//Setting default value of Exchange Rate for approval task
if($.context.invoiceDetails.headerDetail.exchangeRate === "0" || $.context.invoiceDetails.headerDetail.exchangeRate === 0){
    $.context.invoiceDetails.headerDetail.exchangeRate = "";
}