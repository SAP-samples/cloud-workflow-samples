 var appLevel = "###level###";

//Rules service id for determine approver details
var ruleServiceId = "332987c4ee2a431ea0dcdb7f4c683297";
var ruleServiceRevision = "2011";

//Preparing payload for determine approver details
$.context.internal.determineApproverPayload = {
  "RuleServiceId": ruleServiceId,
  "RuleServiceRevision": ruleServiceRevision,
  "Vocabulary": [
    {
        "InvoiceDetails":{
            "CompanyCode": $.context.currentItemGroup.companyCode,
            "CostCenter": $.context.currentItemGroup.costCenter,
            "ApprovalLevel": appLevel,
            
            "CurrencyKey": $.context.currentItemGroup.currency,
            "PaymentTerms": $.context.currentItemGroup.paymentTerm,
            "PaymentMethod": $.context.currentItemGroup.paymentMethod,
            "GLAccount": $.context.currentItemGroup.glAccount,
            "VendorCode": $.context.invoiceDetails.headerDetail.vendorNumber,
            
            "ExchangeRate": $.context.currentItemGroup.exchangeRate,
            
            "ProfitCenter": $.context.currentItemGroup.profitCenter,
            "BusinessArea" : $.context.currentItemGroup.businessArea,
            "ThresholdInvoiceAmount": $.context.currentItemGroup.amount
            
        } 
    }
  ]
}
