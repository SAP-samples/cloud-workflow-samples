var appLevel = "###level###";
//Prepare internal structure for approval
if (typeof $.context.internal === 'undefined') {
    $.context.internal = {

        "steps": {
            "decision": "",
            "approvalLevel": "",
            "starttime": ""
        },
        "terminate": false,
        "isApproverRequired": false,
        "approver": ""

    };
    $.context.internal.terminate = false;
    $.context.internal.steps.approvalLevel = appLevel;
    //Capturing process step start time
    $.context.internal.steps.starttime = new Date();
}

if ($.context.invoiceDetails.headerDetail.requesterName == null || $.context.invoiceDetails.headerDetail.requesterName == "") {
    $.context.invoiceDetails.headerDetail.requesterName = $.info.startedBy;
}

