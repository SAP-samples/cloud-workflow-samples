
var approverDetails = $.context.internal.determineApproverResponse.Result;
//Processing approver details
if (approverDetails.length !== 0) {
    var isAppRequired = $.context.internal.determineApproverResponse.Result[0].ApproverDetails.IsApprovalRequired;
    $.context.internal.isApproverRequired = isAppRequired;
    if (typeof $.context.internal.determineApproverResponse.Result[0].ApproverDetails.UserId !== 'undefined') {
    var approver = $.context.internal.determineApproverResponse.Result[0].ApproverDetails.UserId;
    $.context.internal.approver = approver;
    }
    if (typeof $.context.internal.determineApproverResponse.Result[0].ApproverDetails.Email !== 'undefined') {
    $.context.internal.approverMail = $.context.internal.determineApproverResponse.Result[0].ApproverDetails.Email;
    }
    if (typeof $.context.internal.determineApproverResponse.Result[0].ApproverDetails.UserGroup !== 'undefined') {
        $.context.internal.approverGroup = $.context.internal.determineApproverResponse.Result[0].ApproverDetails.UserGroup;
    }
}

