var task = $.usertasks['###activity.id:usertask1###'].last;

var appLevel = "###level###";

//Processing approver decision
if ($.context.internal.approvalStatus === 'decline') {
    $.context.internal.approvalStatusText = "Declined";
} else if ($.context.internal.approvalStatus === 'rework') {
    $.context.internal.approvalStatusText = "Not Responsible";
}else if ($.context.internal.approvalStatus === 'Invoice Request') {
    $.context.internal.approvalStatusText = "Invoice Requested";
} else {
    $.context.internal.approvalStatusText = "Approved";
}
var decision;
decision = {
    "userId": task.processor,
    "role": appLevel,
    "action": $.context.internal.approvalStatus,
    "comments": $.context.internal.comments,
    "actionText" : $.context.internal.approvalStatusText
};

if (typeof $.context.history === 'undefined') {
    $.context.history = [];
}

//Pushing current approver decision to the history
$.context.history.push(decision);

//If approver decision is declined or marked as "Not Responsiblle", process step termination indicator will be true
if ($.context.internal.approvalStatus !== "approve") {
    $.context.internal.terminate = true;
}

//Setting default value of Exchange Rate
if($.context.invoiceDetails.headerDetail.exchangeRate === ""){
    $.context.invoiceDetails.headerDetail.exchangeRate = "0";
}