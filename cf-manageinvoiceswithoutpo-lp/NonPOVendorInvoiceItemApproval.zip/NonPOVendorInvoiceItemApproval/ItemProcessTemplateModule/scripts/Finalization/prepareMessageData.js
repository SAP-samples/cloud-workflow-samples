
var currentItemGroup = $.context.currentItemGroup

//Prepaing message payload as a response of completed item workflow to the header workflow
var msgPayload = {
    "context": {
        
        "history": $.context.history,
        "currentItemGroup": currentItemGroup
    },
    "definitionId": "InvoiceApprovalResponseMessage",
    "workflowInstanceId": $.context.headerInstanceId
}
$.context.messagePayload = msgPayload;
var date = $.context.invoiceDetails.headerDetail.invoiceDate;
date = date.substring(0, 4)
    + "-" + date.substring(4, 6)
    + "-" + date.substring(6, 8);
$.context.invoiceDetails.headerDetail.invoiceDate = date;

date = $.context.invoiceDetails.headerDetail.discountDate;
date = date.substring(0, 4)
    + "-" + date.substring(4, 6)
    + "-" + date.substring(6, 8);
$.context.invoiceDetails.headerDetail.discountDate = date;

date = $.context.invoiceDetails.headerDetail.secondDiscountDate;
date = date.substring(0, 4)
    + "-" + date.substring(4, 6)
    + "-" + date.substring(6, 8);
$.context.invoiceDetails.headerDetail.secondDiscountDate = date;


var invoiceDueDays = "";
var paymentTerms = $.context.invoiceDetails.paymentTerms;
if(paymentTerms[2].days !== 0) {
invoiceDueDays = paymentTerms[2].days;
} else if(paymentTerms[1].days !== 0){
    invoiceDueDays = paymentTerms[1].days;
}else{
    invoiceDueDays = paymentTerms[0].days;
}

var invoiceDate = $.context.invoiceDetails.headerDetail.invoiceDate;
var date1 = new Date(parseInt(invoiceDate.substring(0, 4)), parseInt(invoiceDate.substring(4, 6))-1, parseInt(invoiceDate.substring(6, 8)));
date1.setDate(date1.getDate() + invoiceDueDays);
$.context.invoiceDetails.headerDetail.invoiceDueDate = date1.toISOString().slice(0,10);

//Cleaning internal contexts
delete $.context.internal;