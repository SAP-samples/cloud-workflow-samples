sap.ui.define([
	"com/sap/cp/dpa/invwpo/taskUI/test/unit/controller/View1.controller"
], function () {
	"use strict";
});