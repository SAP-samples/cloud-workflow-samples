sap.ui.define([
	"com/sap/cp/dpa/invwpo/StartUI/test/unit/controller/View1.controller"
], function () {
	"use strict";
});