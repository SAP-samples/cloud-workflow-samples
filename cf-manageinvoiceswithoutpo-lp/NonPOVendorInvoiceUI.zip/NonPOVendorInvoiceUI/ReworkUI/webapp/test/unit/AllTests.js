sap.ui.define([
	"com/sap/cp/dpa/invwpo/ReworkUI/test/unit/controller/View1.controller"
], function () {
	"use strict";
});