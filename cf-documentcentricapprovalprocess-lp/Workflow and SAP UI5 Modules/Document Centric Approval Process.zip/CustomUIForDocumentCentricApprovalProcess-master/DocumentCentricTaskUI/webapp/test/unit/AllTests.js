sap.ui.define([
	"com/sap/bpm/DocumentCentricTaskUI/test/unit/controller/App.controller"
], function () {
	"use strict";
});
