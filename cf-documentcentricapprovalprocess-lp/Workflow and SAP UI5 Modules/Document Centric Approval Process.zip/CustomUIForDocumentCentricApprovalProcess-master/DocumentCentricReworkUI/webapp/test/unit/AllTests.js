sap.ui.define([
	"com/sap/bpm/DocumentCentricReworkUI/test/unit/controller/App.controller"
], function () {
	"use strict";
});
