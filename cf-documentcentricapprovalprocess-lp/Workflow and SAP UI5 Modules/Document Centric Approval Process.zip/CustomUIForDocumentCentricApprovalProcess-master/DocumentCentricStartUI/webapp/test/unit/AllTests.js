sap.ui.define([
	"com/sap/bpm/DocumentCentricStartUI/test/unit/controller/App.controller"
], function () {
	"use strict";
});
