//$.context.taskProcessor = $.context.initiator;
var ibn = $.context.alertData.ibn;
ibn = ibn.replace("%252f", "%2f"); // Fix the encode error (if there is)
$.context.alertData.ibn = ibn;