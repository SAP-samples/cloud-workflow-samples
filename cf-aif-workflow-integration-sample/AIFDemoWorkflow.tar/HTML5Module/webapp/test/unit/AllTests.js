sap.ui.define([
	"com/sap/aif/HTML5Module/test/unit/controller/mainview.controller"
], function () {
	"use strict";
});
