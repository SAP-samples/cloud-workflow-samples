sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/sap/aif/HTML5Module/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("com.sap.aif.HTML5Module.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // enable routing
            this.getRouter().initialize();

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            this.setTaskModels();
            var taskId = this.getTaskInstanceID();
            this.getInboxAPI().addAction({
                action: "Restart",
                label: "Restart",
                type: "accept" // (Optional property) Define for positive appearance
            }, function () {
                this._completeTask(taskId, 'R');
            }, this);

            this.getInboxAPI().addAction({
                action: "Cancel",
                label: "Cancel",
                type: "reject" // (Optional property) Define for negative appearance
            }, function () {
                this._completeTask(taskId, "C");
            }, this);
        },
        _completeTask: function (taskId, approvalStatus) {
            var token = this._fetchToken();
            $.ajax({
                // url: "/comsapaifHTML5Module/bpmworkflowruntime/v1/task-instances/" + taskId,
                url: this._getTaskInstancesBaseURL(),
                method: "PATCH",
                contentType: "application/json",
                async: false,
                data: "{\"status\": \"COMPLETED\", \"context\": {\"aifAction\":\"" + approvalStatus + "\"}}",
                headers: {
                    "X-CSRF-Token": token
                }
            });
            // this._patchTaskInstance();
            this._refreshTask(taskId);
        },
        // completeTask: function (approvalStatus) {
        //     this.getModel("context").setProperty("/approved", approvalStatus);
        //     this._patchTaskInstance();
        //     this._refreshTaskList();
        // },
        setTaskModels: function () {
            // set the task model
            var startupParameters = this.getComponentData().startupParameters;
            this.setModel(startupParameters.taskModel, "task");

            // set the task context model
            var taskContextModel = new sap.ui.model.json.JSONModel(this._getTaskInstancesBaseURL() + "/context");
            this.setModel(taskContextModel);
        },

        _getTaskInstancesBaseURL: function () {
            return this._getWorkflowRuntimeBaseURL() + "/task-instances/" + this.getTaskInstanceID();
        },
        _getWorkflowRuntimeBaseURL: function () {
            var appId = this.getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = jQuery.sap.getModulePath(appPath);

            return appModulePath + "/bpmworkflowruntime/v1";
        },

        getTaskInstanceID: function () {
            return this.getModel("task").getData().InstanceID;
        },
        
        getInboxAPI: function () {
            var startupParameters = this.getComponentData().startupParameters;
            return startupParameters.inboxAPI;
        },
        _patchTaskInstance: function () {
            var data = {
                status: "COMPLETED",
                context: this.getModel().getData()
            }

            jQuery.ajax({
                url: this._getTaskInstancesBaseURL(),
                method: "PATCH",
                contentType: "application/json",
                async: false,
                data: JSON.stringify(data),
                headers: {
                    "X-CSRF-Token": this._fetchToken()
                }
            });
        },

        _fetchToken: function () {
            var fetchedToken;

            jQuery.ajax({
                url: this._getWorkflowRuntimeBaseURL() + "/xsrf-token",
                method: "GET",
                async: false,
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success(result, xhr, data) {
                    fetchedToken = data.getResponseHeader("X-CSRF-Token");
                }
            });
            return fetchedToken;
        },

        _refreshTask: function (taskId) {
            this.getInboxAPI().updateTask("NA",  taskId );
        }
    });
});
